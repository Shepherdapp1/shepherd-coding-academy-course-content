# C++ course content 0.1.2 — publish steps

Two files, one repo (`shepherd-coding-academy-course-content`, branch `main`).
No app build, no signature, no installer — lesson content travels separately.

| # | What | Where |
|---|---|---|
| 1 | `shepherd.cpp-levels-01-05-0.1.2.zip` | content repo root |
| 2 | `app-catalog.json` | content repo root (replaces the current one) |

## What changed, and what did not

Diff against the published 0.1.1:

```
manifest.version : 0.1.1 -> 0.1.2
items            : 82 -> 82
changed items    : 1 of 82
  - shepherd.cpp-levels-01-05.lesson.001004 [lesson]
    'Install a C++ Compiler and Type Your First Program'
    -> 'Write and Run Your First Program'
```

That lesson was built around installing MSYS2 and running
`pacman -S mingw-w64-ucrt-x86_64-gcc`, which contradicts an app that supplies its
own compiler. It now teaches the same subject through the app: the four build
stages, writing a complete program, pressing **Run my code**, and reading
diagnostics. All eight of its code examples are byte-identical to before; the
other 51 lessons are untouched.

v0.1.1 stays published and unchanged. Learners who already have it keep it; the
newer version is offered on **Check for courses**.

## Verified before handing over

- `validate_course_zip.py` → PASSED (no errors).
- Catalog parses with the app's own `parse_catalog`: `requires_toolchains`
  `('cpp-llvm-mingw',)`, language `C++`, module `programming-languages`.
- Only one item differs from 0.1.1.
- 366 C++ code blocks intact.

```
size_bytes  115716
sha256      bc6051879a102cd3116739196210c1a3c8c40c086c5a29ece756de14630e4c51
```

## Steps

1. https://github.com/Shepherdapp1/shepherd-coding-academy-course-content
   → **Add file ▾ → Upload files** → upload `shepherd.cpp-levels-01-05-0.1.2.zip`
   → commit `C++ course 0.1.2: rewrite the compiler-install lesson`.
2. Same repo → open `app-catalog.json` → ✏️ → replace the whole file with the
   `app-catalog.json` next to this document → commit
   `Publish C++ course 0.1.2`.
3. In the app: **Subjects & languages → Check for courses**. The C++ row should
   offer **v0.1.2**. Install it (the compiler is already present, so it is
   reused — no 250 MB download).
4. Open the course → lesson **"Write and Run Your First Program"**. Check:
   - the text never mentions MSYS2, pacman, g++ or a terminal;
   - **Run example** builds and prints `Hello, C++!`;
   - the three self-checks show clickable options and hide the answer until
     **Check my answer**.

## If something is wrong

The zip's hash is what the app checks, so a failed install means the uploaded
bytes differ from the ones above. Re-upload the file from this folder rather than
re-zipping it, then confirm the raw URL while signed out:

```
curl -sI https://raw.githubusercontent.com/Shepherdapp1/shepherd-coding-academy-course-content/main/shepherd.cpp-levels-01-05-0.1.2.zip
```
