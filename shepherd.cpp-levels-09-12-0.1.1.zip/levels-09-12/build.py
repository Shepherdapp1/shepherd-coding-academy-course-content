"""Build the Level 9 batch of shepherd.cpp-levels-09-12."""
import json
from pathlib import Path

CID = "shepherd.cpp-levels-09-12"
VERSION = "0.1.1"


def quiz(question, options, correct, explanation):
    payload = {"question": question, "options": options,
               "correct_index": correct, "explanation": explanation}
    return {"kind": "explanation", "text": "SHEPHERD_QUIZ_V1:" + json.dumps(payload, ensure_ascii=False)}


def exp(text):
    return {"kind": "explanation", "text": text}


def dfn(term, text):
    return {"kind": "definition", "term": term, "text": text}


def code(source, expected, language="cpp", standard="c++17"):
    """A code block. NOTE: the app's schema has no "standard" field on a block,
    so it is accepted here and ignored; the lesson carries the standard in its
    extensions as org.shepherd.cpp-standard."""
    block = {"kind": "code", "language": language,
             "code": source, "expected_output": expected}
    return block


def steps(items):
    return {"kind": "steps", "steps": items}


CHALLENGE = exp("Guided coding challenge\n\nThe example above is short on purpose. "
                "Write the same template yourself, with your own type and value.")

lessons = []
n = 0


def lesson(topic_no, title, summary, objectives, body, standard="C++17"):
    global n
    n += 1
    lessons.append((topic_no, {
        "id": f"{CID}.lesson.9{n:04d}",
        "kind": "lesson",
        "title": title,
        "revision": 1,
        "summary": summary,
        "objectives": objectives,
        "difficulty": "intermediate",
        "estimated_minutes": 25,
        "extensions": {"org.shepherd.cpp-standard": standard},
        "body": body,
    }))


# ---------------------------------------------------------------- 9.1
lesson(1, "Why Templates Exist",
       "Write one algorithm that works for int, double and text instead of three copies.",
       ["Explain the duplication problem that templates solve.",
        "Write your first function template.",
        "Describe what the compiler does when you call one."],
       [exp("The duplication problem\n\n"
            "Before templates, printing the larger of two values meant writing the same "
            "function several times: once for int, once for double, once for std::string. "
            "The bodies were identical and only the types changed. Every copy was another "
            "place to fix a bug.\n\n"
            "A template is a function or class written against a type you do not name yet. "
            "You write the algorithm once and leave the type as a parameter.\n\n"
            "The compiler produces real code for each type you actually use. Nothing is "
            "decided at run time, and there is no performance cost for the flexibility."),
        dfn("Template", "A function or class written with a type parameter that the "
                        "compiler fills in for each call."),
        dfn("Instantiation", "The compiler's act of generating a concrete version of a "
                             "template for one specific type."),
        exp("The smallest useful template\n\n"
            "A type parameter is declared with the keyword template and the word "
            "typename. The compiler works out the type from the argument you pass.\n\n"
            "The call larger(3, 7) instantiates larger<int>, and larger(2.5, 1.5) "
            "instantiates larger<double>. Two functions, one piece of source."),
        code('#include <iostream>\n\n'
             'template <typename T>\n'
             'T larger(T a, T b) {\n'
             '    return (a > b) ? a : b;\n'
             '}\n\n'
             'int main() {\n'
             '    std::cout << larger(3, 7) << "\\n";\n'
             '    std::cout << larger(2.5, 1.5) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "7\n2.5"),
        exp("What the compiler did\n\n"
            "It read the template, saw two calls, and generated two ordinary functions. "
            "The output is identical to what three hand-written copies would produce.\n\n"
            "Because each call produces a real function, a template must compile "
            "correctly for the types you use. A template that only works for numbers "
            "fails when you pass text, and the error names the exact line inside the "
            "template."),
        code('#include <iostream>\n#include <string>\n\n'
             'template <typename T>\n'
             'T larger(T a, T b) {\n'
             '    return (a > b) ? a : b;\n'
             '}\n\n'
             'int main() {\n'
             '    std::string first = "apple";\n'
             '    std::string second = "banana";\n'
             '    std::cout << larger(first, second) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "banana"),
        quiz("Which statement about templates is correct?",
             ["They run the same code for every type at run time",
              "The compiler generates a version for each type actually used",
              "They only work with numbers",
              "They always make a program slower"],
             1, "Each type you use causes the compiler to generate its own version of the template."),
        ])

# ---------------------------------------------------------------- 9.2
lesson(1, "Function Templates and Type Deduction",
       "Let the compiler work out types, and take control when it guesses wrong.",
       ["Use two type parameters in one template.",
        "Explain how the compiler deduces a type argument.",
        "Force a specific type with explicit arguments."],
       [exp("Deduction\n\n"
            "When you call a function template, the compiler matches the declared "
            "parameters against the arguments and works out the type. This is the same "
            "rule that lets auto work: it is called template argument deduction.\n\n"
            "Deduction is literal. If one argument is an int and the other a double, "
            "the compiler cannot make T both at once and stops with an error rather "
            "than silently converting.\n\n"
            "You can force a type by naming it in angle brackets, which is also how you "
            "convert both arguments to a common type."),
        dfn("Explicit type argument", "Naming the type yourself, as in larger<double>(3, 7)."),
        exp("Two type parameters and the mismatch\n\n"
            "Declaring two parameters, T and U, lets the arguments differ. The return "
            "type still has to be chosen, so a common type is named explicitly.\n\n"
            "Writing larger of an int and a double fails until you say which type you "
            "mean. That is a feature: the compiler makes you admit the conversion."),
        code('#include <iostream>\n\n'
             'template <typename T, typename U>\n'
             'auto pick(T a, U b) {\n'
             '    return (a > b) ? a : b;\n'
             '}\n\n'
             'int main() {\n'
             '    std::cout << pick(3, 7.5) << "\\n";\n'
             '    std::cout << pick<double>(3, 7) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "7.5\n7"),
        exp("Choosing the return type deliberately\n\n"
            "auto as the return type asks the compiler to deduce from the return "
            "expression. That is convenient, but a template that returns a reference "
            "or a const value needs care, and the meaning of auto differs depending on "
            "where it is written.\n\n"
            "Naming the return type is clearer whenever a caller could be surprised by "
            "the conversion."),
        code('#include <iostream>\n\n'
             'template <typename T, typename U>\n'
             'double average(T a, U b) {\n'
             '    return (static_cast<double>(a) + static_cast<double>(b)) / 2.0;\n'
             '}\n\n'
             'int main() {\n'
             '    std::cout << average(3, 4) << "\\n";\n'
             '    std::cout << average(3.0, 4.5) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "3.5\n3.75"),
        CHALLENGE,
        code('#include <iostream>\n\n'
             'template <typename T>\n'
             'T smallest(T a, T b) {\n'
             '    return (a < b) ? a : b;\n'
             '}\n\n'
             'int main() {\n'
             '    std::cout << smallest(9, 4) << "\\n";\n'
             '    std::cout << smallest(1.5, 0.25) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "4\n0.25"),
        quiz("What happens when you call larger(3, 7.5) on template <typename T> larger(T, T)?",
             ["T becomes double and 3 is converted",
              "T becomes int and 7.5 is truncated",
              "The compiler reports a deduction conflict and refuses",
              "It compiles and returns the text of both values"],
             2, "Deduction must agree for every T; an int and a double conflict, so the call "
                "is rejected unless you name the type."),
        ])

# ---------------------------------------------------------------- 9.3
lesson(2, "Class Templates",
       "Give a class a type parameter so one description holds many kinds of value.",
       ["Write a class template with one type parameter.",
        "Use member functions of a class template.",
        "Instantiate a template with two different types."],
       [exp("A class with a type parameter\n\n"
            "A container is the natural place for a class template: the description of "
            "holding one value is the same whether the value is a number, text or "
            "another object.\n\n"
            "The type parameter belongs to the class, so every member function can use "
            "it, and each instantiation is a genuinely different type: Box<int> and "
            "Box<std::string> share source, not behaviour.\n\n"
            "Because they are different types, one cannot be assigned to the other, "
            "which is what you want: a box of numbers is not a box of words."),
        dfn("Class template", "A class declared with one or more type parameters, "
                             "instantiated per type used."),
        exp("Reading a class template\n\n"
            "Member functions defined inside the class body use T directly. Defining "
            "them outside the class needs the full template header repeated, which is "
            "the subject of a later lesson.\n\n"
            "Notice the constructor taking T by value: the argument must match the "
            "instantiation, so Box<int> will not accept text."),
        code('#include <iostream>\n#include <string>\n\n'
             'template <typename T>\n'
             'class Box {\n'
             'public:\n'
             '    explicit Box(T value) : value_(value) {}\n'
             '    T get() const { return value_; }\n'
             '    void set(T value) { value_ = value; }\n'
             'private:\n'
             '    T value_;\n'
             '};\n\n'
             'int main() {\n'
             '    Box<int> number(42);\n'
             '    Box<std::string> word("hello");\n'
             '    number.set(7);\n'
             '    std::cout << number.get() << "\\n";\n'
             '    std::cout << word.get() << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "7\nhello"),
        exp("Two parameters, one class\n\n"
            "A class template may take several type parameters. A pair of values of "
            "different types is the canonical example, and it is what std::pair gives "
            "you ready-made.\n\n"
            "Writing your own version once is worth it: you see exactly where the two "
            "types live and how they travel through the constructor."),
        code('#include <iostream>\n#include <string>\n\n'
             'template <typename First, typename Second>\n'
             'class Pair {\n'
             'public:\n'
             '    Pair(First first, Second second) : first_(first), second_(second) {}\n'
             '    First first() const { return first_; }\n'
             '    Second second() const { return second_; }\n'
             'private:\n'
             '    First first_;\n'
             '    Second second_;\n'
             '};\n\n'
             'int main() {\n'
             '    Pair<std::string, int> score("Ada", 98);\n'
             '    std::cout << score.first() << ": " << score.second() << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "Ada: 98"),
        CHALLENGE,
        code('#include <iostream>\n\n'
             'template <typename T>\n'
             'class Counter {\n'
             'public:\n'
             '    void add(T step) { total_ += step; }\n'
             '    T total() const { return total_; }\n'
             'private:\n'
             '    T total_{};\n'
             '};\n\n'
             'int main() {\n'
             '    Counter<int> whole;\n'
             '    Counter<double> part;\n'
             '    whole.add(3);\n'
             '    whole.add(4);\n'
             '    part.add(0.5);\n'
             '    part.add(0.25);\n'
             '    std::cout << whole.total() << "\\n" << part.total() << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "7\n0.75"),
        quiz("Which two types does Box<int> and Box<std::string> describe?",
             ["The same type with different contents",
              "Two different types generated from one template",
              "One type that switches at run time",
              "A type that only accepts numbers"],
             1, "Each instantiation is its own type; they share source text, not identity."),
        ])

# ---------------------------------------------------------------- 9.4
lesson(2, "Class Templates That Behave",
       "Give a class template copy behaviour, a default value and a readable form.",
       ["Give a class template a default member value.",
        "Print a template instance through a friend operator.",
        "Explain why a template class needs no separate copy code."],
       [exp("Defaults and value initialisation\n\n"
            "A class template that holds an accumulator must start from a sensible "
            "value. Writing T{} value-initialises whatever T is: 0 for numbers, an "
            "empty string for text.\n\n"
            "Writing T value_; would leave a number uninitialised inside a class, which "
            "is the kind of bug that shows up only in one build.\n\n"
            "The brace form is the portable way to say zero-or-empty."),
        dfn("Value initialisation", "T{} gives 0 for numbers and an empty value for class "
                                   "types, regardless of what T is."),
        exp("Printing a template instance\n\n"
            "A friend function declared inside the class body is found when the class is "
            "printed, so the same operator serves every instantiation.\n\n"
            "Because it is a friend of that instantiation, it can read the private member "
            "without a getter."),
        code('#include <iostream>\n#include <string>\n\n'
             'template <typename T>\n'
             'class Meter {\n'
             'public:\n'
             '    Meter() : value_{} {}\n'
             '    explicit Meter(T value) : value_(value) {}\n'
             '    Meter& operator+=(T step) { value_ += step; return *this; }\n'
             '    friend std::ostream& operator<<(std::ostream& out, const Meter& meter) {\n'
             '        return out << meter.value_;\n'
             '    }\n'
             'private:\n'
             '    T value_;\n'
             '};\n\n'
             'int main() {\n'
             '    Meter<int> count;\n'
             '    count += 5;\n'
             '    count += 2;\n'
             '    std::cout << count << "\\n";\n'
             '    Meter<std::string> label("ab");\n'
             '    label += "cd";\n'
             '    std::cout << label << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "7\nabcd"),
        exp("Copying comes for free\n\n"
            "A template class gets a copy constructor and copy assignment generated by "
            "the compiler, exactly like any other class. It copies each member, which "
            "for a simple value member is all that is needed.\n\n"
            "This is worth knowing before you write operator= by hand: the generated one "
            "is usually right, and a hand-written one is the usual place a template goes "
            "wrong."),
        code('#include <iostream>\n#include <string>\n\n'
             'template <typename T>\n'
             'class Tagged {\n'
             'public:\n'
             '    Tagged(std::string name, T value) : name_(name), value_(value) {}\n'
             '    std::string name() const { return name_; }\n'
             '    T value() const { return value_; }\n'
             '    void set(T value) { value_ = value; }\n'
             'private:\n'
             '    std::string name_;\n'
             '    T value_;\n'
             '};\n\n'
             'int main() {\n'
             '    Tagged<int> first("speed", 10);\n'
             '    Tagged<int> second = first;\n'
             '    second.set(20);\n'
             '    std::cout << first.name() << "=" << first.value() << "\\n";\n'
             '    std::cout << second.name() << "=" << second.value() << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "speed=10\nspeed=20"),
        quiz("What does T{} give when T is std::string?",
             ["A string containing one space", "An empty string", "Undefined content", "A compile error"],
             1, "Value initialisation on a class type calls its default constructor, "
                "which for std::string is an empty string."),
        ])

# ---------------------------------------------------------------- 9.5
lesson(3, "Non-Type Template Parameters",
       "Put a number into the template so the size becomes part of the type.",
       ["Declare a template parameter that is a value, not a type.",
        "Explain why a fixed size must be a compile-time constant.",
        "Compare std::array with a built-in array."],
       [exp("Sizes belong in the type\n\n"
            "A container of exactly four numbers is a different thing from one holding "
            "any number of them, and the compiler should know that. A non-type "
            "template parameter puts the size into the type.\n\n"
            "The value must be known at compile time, because the compiler has to lay "
            "out the object. A variable that only exists at run time cannot be used.\n\n"
            "The benefit is that the size is free: no heap, no pointer, and the compiler "
            "can complain about a wrong size before the program ever runs."),
        dfn("Non-type template parameter", "A template parameter that is a value such as "
                                          "an int, not a type, e.g. Array<int, 4>."),
        exp("Writing a fixed-size array\n\n"
            "The size arrives as an int parameter named N. Inside the class it behaves "
            "like a constant, and the storage is a plain built-in array.\n\n"
            "Attempting to construct Array<int, 4> with five values is a compile error, "
            "which is the point: the mistake is caught before it can corrupt memory."),
        code('#include <iostream>\n\n'
             'template <typename T, int N>\n'
             'class Array {\n'
             'public:\n'
             '    T& operator[](int index) { return data_[index]; }\n'
             '    const T& operator[](int index) const { return data_[index]; }\n'
             '    int size() const { return N; }\n'
             'private:\n'
             '    T data_[N]{};\n'
             '};\n\n'
             'int main() {\n'
             '    Array<int, 4> values;\n'
             '    values[0] = 10;\n'
             '    values[3] = 40;\n'
             '    std::cout << values.size() << "\\n";\n'
             '    std::cout << values[0] + values[3] << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "4\n50"),
        exp("The standard version\n\n"
            "std::array is exactly this idea, already written and tested. Prefer it in "
            "real code and keep your own version only as a way of understanding how the "
            "size lives in the type.\n\n"
            "Unlike a built-in array, std::array knows its size, copies like a value, and "
            "does not silently decay to a pointer when you pass it to a function."),
        code('#include <array>\n#include <iostream>\n\n'
             'int main() {\n'
             '    std::array<int, 3> values{4, 8, 15};\n'
             '    int total = 0;\n'
             '    for (int value : values) {\n'
             '        total += value;\n'
             '    }\n'
             '    std::cout << values.size() << "\\n";\n'
             '    std::cout << total << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "3\n27"),
        CHALLENGE,
        code('#include <iostream>\n\n'
             'template <int N>\n'
             'struct Squares {\n'
             '    static int of(int value) { return value * value; }\n'
             '};\n\n'
             'int main() {\n'
             '    std::cout << Squares<4>::of(5) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "25"),
        quiz("Why must a non-type template parameter be known at compile time?",
             ["Because the compiler sizes the object and cannot wait for a run-time value",
              "Because templates cannot use numbers",
              "Because it is copied at run time",
              "Because the linker needs it"],
             0, "The value is part of the type, so the compiler must know it while "
                "generating the code and laying out the object."),
        ])

# ---------------------------------------------------------------- 9.6
lesson(3, "Template Specialization",
       "When one type needs different behaviour, say so explicitly.",
       ["Explain when a template needs a special case.",
        "Write a full specialization for one type.",
        "Describe the cost of over-specialising."],
       [exp("The general rule does not fit every type\n\n"
            "A generic function describes behaviour that is right most of the time. "
            "Occasionally one type needs something genuinely different, and forcing it "
            "through the general path produces a wrong or misleading result.\n\n"
            "A full specialization gives one exact type its own implementation while the "
            "template keeps serving every other type.\n\n"
            "Use it sparingly. A specialization is a second implementation of the same "
            "promise, and two promises drift."),
        dfn("Full specialization", "A separate implementation of a template for one exact "
                                   "set of template arguments."),
        exp("A printer that tells the truth\n\n"
            "Printing a bool through a general template writes 1 or 0, which is rarely "
            "what a reader wants. The specialization for bool prints words instead.\n\n"
            "The call site does not change: describe(true) still looks like one function, "
            "and the compiler picks the specialization whenever the argument is a bool."),
        code('#include <iostream>\n#include <string>\n\n'
             'template <typename T>\n'
             'std::string describe(T) {\n'
             '    return "value";\n'
             '}\n\n'
             'template <>\n'
             'std::string describe<bool>(bool value) {\n'
             '    return value ? "true" : "false";\n'
             '}\n\n'
             'template <>\n'
             'std::string describe<std::string>(std::string value) {\n'
             '    return "text: " + value;\n'
             '}\n\n'
             'int main() {\n'
             '    std::cout << describe(true) << "\\n";\n'
             '    std::cout << describe(42) << "\\n";\n'
             '    std::cout << describe(std::string("hi")) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "true\nvalue\ntext: hi"),
        exp("What specialization costs\n\n"
            "Each specialization is code you must keep correct separately. When the "
            "general template changes, every specialization has to be reconsidered.\n\n"
            "A common alternative is to put the difference in a small type trait or in an "
            "overload, which the compiler resolves without a second copy of the "
            "algorithm. Prefer that when it reads as clearly."),
        code('#include <iostream>\n#include <string>\n\n'
             'std::string describe(bool value) { return value ? "true" : "false"; }\n\n'
             'template <typename T>\n'
             'std::string describe(T) { return "value"; }\n\n'
             'int main() {\n'
             '    std::cout << describe(false) << "\\n";\n'
             '    std::cout << describe(3.5) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "false\nvalue"),
        CHALLENGE,
        code('#include <iostream>\n\n'
             'template <typename T>\n'
             'struct Kind { static const char* name() { return "general"; } };\n\n'
             'template <>\n'
             'struct Kind<int> { static const char* name() { return "integer"; } };\n\n'
             'int main() {\n'
             '    std::cout << Kind<double>::name() << "\\n";\n'
             '    std::cout << Kind<int>::name() << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "general\ninteger"),
        quiz("What does template <> mark?",
             ["A template with no parameters at all",
              "A full specialization for one exact type",
              "A partial match for any type",
              "A template that cannot be instantiated"],
             1, "The empty angle brackets introduce a specialization of the template for "
                "one exact set of arguments."),
        ])

# ---------------------------------------------------------------- 9.7
lesson(4, "Variadic Templates",
       "Accept any number of arguments and let the compiler count them.",
       ["Write a function template that takes any number of arguments.",
        "Use sizeof... to count a parameter pack.",
        "Use a fold expression to combine values."],
       [exp("Any number of arguments\n\n"
            "Sometimes the number of arguments is not known when you write the function: "
            "a sum of one value, or five, or fifty. A parameter pack accepts all of them.\n\n"
            "sizeof...(Args) counts the types in the pack at compile time, so the caller "
            "can be told how many values arrived without any run-time counting machinery.\n\n"
            "A fold expression applies an operator across the whole pack in one short "
            "line, which replaces the recursive helpers older C++ required."),
        dfn("Parameter pack", "A template parameter that accepts zero or more types or "
                              "values, written Args..."),
        dfn("Fold expression", "A C++17 form that applies a binary operator across every "
                              "element of a pack, e.g. (args + ...)."),
        exp("Counting and summing\n\n"
            "The count function only needs the pack's size. The sum function folds the "
            "pack with plus, and because the starting value is 0 it also works for an "
            "empty call.\n\n"
            "Both functions are resolved entirely at compile time; there is no loop and "
            "no list being built at run time."),
        code('#include <iostream>\n\n'
             'template <typename... Args>\n'
             'int count(Args... args) {\n'
             '    return static_cast<int>(sizeof...(args));\n'
             '}\n\n'
             'template <typename... Args>\n'
             'int sum(Args... args) {\n'
             '    return (0 + ... + args);\n'
             '}\n\n'
             'int main() {\n'
             '    std::cout << count(1, 2, 3) << "\\n";\n'
             '    std::cout << sum(1, 2, 3, 4) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "3\n10"),
        exp("Printing every value\n\n"
            "Printing is the classic variadic example because each argument may have a "
            "different type. A fold over the comma operator prints them in order with a "
            "separator between.\n\n"
            "The fold has to handle the empty case, which is why the first form is "
            "written with an explicit initial value."),
        code('#include <iostream>\n#include <string>\n\n'
             'template <typename... Args>\n'
             'void print_all(Args... args) {\n'
             '    ((std::cout << args << " "), ...);\n'
             '    std::cout << "\\n";\n'
             '}\n\n'
             'int main() {\n'
             '    print_all(1, 2.5, std::string("three"));\n'
             '    print_all("solo");\n'
             '    return 0;\n'
             '}\n',
             "1 2.5 three \nsolo "),
        CHALLENGE,
        code('#include <iostream>\n\n'
             'template <typename... Args>\n'
             'int largest_of(Args... args) {\n'
             '    int best = 0;\n'
             '    ((best = (args > best) ? args : best), ...);\n'
             '    return best;\n'
             '}\n\n'
             'int main() {\n'
             '    std::cout << largest_of(4, 19, 7) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "19"),
        quiz("What does sizeof...(args) evaluate to?",
             ["The bytes occupied by the arguments at run time",
              "The number of arguments in the pack, known at compile time",
              "The number of parameters the function declares",
              "Always zero"],
             1, "It is a compile-time count of the elements in the parameter pack."),
        ])

# ---------------------------------------------------------------- 9.8
lesson(4, "Constraining Templates",
       "State what a template needs, so the failure lands on the caller with your own words.",
       ["Explain why an unconstrained template gives a poor error.",
        "Stop a bad instantiation with static_assert.",
        "Remove an overload that does not fit using enable_if."],
       [exp("Why constrain a template\n\n"
            "An unconstrained template accepts any type, then fails somewhere inside its "
            "body with a message about an operator the type does not have. The message "
            "points at a line you did not write, in a place you were not looking.\n\n"
            "C++17 gives you two tools to state the requirement yourself. static_assert "
            "stops the build with your own sentence. enable_if removes an overload when "
            "the type does not fit, so a better one can be chosen instead.\n\n"
            "C++20 adds concepts, which is the same idea in tidier clothes. This lesson "
            "stays in C++17 so that every example runs inside the app; the reasoning is "
            "identical either way."),
        dfn("static_assert", "A compile-time check that stops the build with your message "
                             "when a condition is false."),
        dfn("SFINAE", "Substitution failure is not an error: a template that does not fit "
                      "the type is quietly removed instead of breaking the build."),
        exp("Stopping the build with your own sentence\n\n"
            "static_assert is checked when the template is instantiated, so it fires only "
            "for the type you actually used. std::is_arithmetic_v<T> is true for numbers "
            "and false for text or a class.\n\n"
            "The message is the whole point: it is the sentence a reader needs, written by "
            "you, at the place the mistake happened."),
        code('#include <iostream>\n#include <type_traits>\n\n'
             'template <typename T>\n'
             'T half(T value) {\n'
             '    static_assert(std::is_arithmetic_v<T>, "half() needs a number");\n'
             '    return value / 2;\n'
             '}\n\n'
             'int main() {\n'
             '    std::cout << half(9) << "\\n";\n'
             '    std::cout << half(9.0) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "4\n4.5"),
        exp("Removing an overload that does not fit\n\n"
            "enable_if makes a template vanish when its condition is false. The compiler "
            "then simply does not see it, and an overload meant for the real type is used "
            "instead.\n\n"
            "Two overloads below share one name. The integer call finds only the first, "
            "the double call finds only the second, and neither ever collides with the "
            "other."),
        code('#include <iostream>\n#include <string>\n#include <type_traits>\n\n'
             'template <typename T>\n'
             'std::enable_if_t<std::is_integral_v<T>, std::string> kind(T) {\n'
             '    return "integer";\n'
             '}\n\n'
             'template <typename T>\n'
             'std::enable_if_t<std::is_floating_point_v<T>, std::string> kind(T) {\n'
             '    return "floating point";\n'
             '}\n\n'
             'int main() {\n'
             '    std::cout << kind(3) << "\\n";\n'
             '    std::cout << kind(3.5) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "integer\nfloating point"),
        exp("What this costs, and what comes next\n\n"
            "enable_if works, but it buries the requirement in the return type where a "
            "reader looks last. A row of them becomes unreadable, and the error you get "
            "when nothing matches is a list of every candidate rather than one clear "
            "sentence.\n\n"
            "C++20 concepts move the same requirement next to the template name, so the "
            "declaration reads like the rule it enforces. When your toolchain allows "
            "C++20, prefer them; until then, static_assert for a single check and "
            "enable_if when the type itself decides which overload exists."),
        CHALLENGE,
        code('#include <iostream>\n#include <type_traits>\n\n'
             'template <typename T>\n'
             'std::enable_if_t<std::is_integral_v<T>, T> doubled(T value) {\n'
             '    return value * 2;\n'
             '}\n\n'
             'int main() {\n'
             '    std::cout << doubled(21) << "\\n";\n'
             '    return 0;\n'
             '}\n',
             "42"),
        quiz("What happens when a static_assert condition is false?",
             ["The build stops and your message is printed",
              "The program throws an exception at run time",
              "The function returns a default value",
              "The check is ignored in release builds"],
             0, "static_assert is evaluated by the compiler: a false condition is a "
                "compile error carrying the message you wrote."),
        ])

# ---------------------------------------------------------------- assemble
# prerequisites chain, exactly as the shipped packages do it
previous = None
for _topic, entry in lessons:
    entry["prerequisites"] = [previous] if previous else []
    previous = entry["id"]

topics = [
    (1, "Function templates", [l for t, l in lessons if t == 1]),
    (2, "Class templates", [l for t, l in lessons if t == 2]),
    (3, "Sizes and special cases", [l for t, l in lessons if t == 3]),
    (4, "Modern template features", [l for t, l in lessons if t == 4]),
]

items = [
    {"id": CID, "kind": "course", "title": "C++ Templates — Levels 9",
     "revision": 1,
     "summary": "Templates: one algorithm for many types, from the first function template to concepts.",
     "objectives": ["Write function and class templates.",
                    "Put sizes into types with non-type parameters.",
                    "Use variadic packs and C++20 concepts."],
     "difficulty": "intermediate", "estimated_minutes": 200},
    {"id": f"{CID}.section.001", "kind": "section", "title": "Templates", "revision": 1,
     "parent_id": CID},
    {"id": f"{CID}.module.001", "kind": "module",
     "title": "Level 9 — Templates and Generic Programming", "revision": 1,
     "parent_id": f"{CID}.section.001"},
]
for number, (topic_no, title, group) in enumerate(topics, 1):
    topic_id = f"{CID}.topic.{number:03d}"
    items.append({"id": topic_id, "kind": "topic", "title": title, "revision": 1,
                  "parent_id": f"{CID}.module.001"})
    for entry in group:
        entry["parent_id"] = topic_id
        items.append(entry)

manifest = {
    "schema_version": 2,
    "format": "shepherd.course",
    "id": CID,
    "module_id": "programming-languages",
    "version": VERSION,
    "locale": "en",
    "subjects": [{"id": "programming-languages", "category": "language"}],
    "authors": ["Shepherd Coding Academy"],
    "license": "MIT",
    "authoring": {
        "specification_id": CID + ".spec",
        "specification_version": "1.0.0",
        "allocations": [{
            "batch_id": CID + ".batch.001",
            "section_id": CID + ".section.001",
            "allowed_ids": [item["id"] for item in items],
        }],
    },
    "batches": [{
        "id": CID + ".batch.001", "schema_version": 2, "course_id": CID,
        "specification_id": CID + ".spec", "specification_version": "1.0.0",
        "section_id": CID + ".section.001",
        "item_ids": [item["id"] for item in items],
        "author": "Shepherd Coding Academy",
    }],
    "items": items,
}
Path(__file__).resolve().parent.joinpath("manifest.json").write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
                                 encoding="utf-8")
print(f"lessons written: {len(lessons)}")
