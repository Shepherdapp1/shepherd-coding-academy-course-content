"""Level 10 — The Standard Library in Depth."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("10001", 10, "Iterators and algorithms", "Iterators Are the Contract",
           "A container hands you two positions; the algorithms do the rest.",
           ["Explain what begin() and end() delimit.",
            "Move through a container with an iterator.",
            "Read the half-open range rule."],
           [exp("Two positions, one range\n\n"
                "Every standard container can hand you an iterator to its first element "
                "and one to a position past its last. Everything in the standard library "
                "that loops over data takes that pair and nothing else.\n\n"
                "That single idea is why one algorithm in <algorithm> can work on a "
                "vector, a deque, a built-in array and a string without knowing what any "
                "of them is.\n\n"
                "An iterator behaves like a pointer you can only move forwards: "
                "* gives the value, ++ moves on, and comparing with end() tells you when "
                "to stop."),
            dfn("Iterator", "A position inside a container. It supports *, ++ and "
                            "comparison, and it names a range together with another "
                            "iterator."),
            dfn("Half-open range", "begin() is included, end() is not. A range of "
                                   "five values has its last element four steps from "
                                   "begin(), never at end()."),
            exp("Counting and stepping\n\n"
                "std::distance returns how many steps lie between two positions, and "
                "std::advance moves an iterator forward without a loop of your own.\n\n"
                "Because end() is one past the last element, a container holding four "
                "values measures four, and the last real element is never dereferenced "
                "by accident."),
            code('''#include <iostream>
#include <iterator>
#include <vector>

int main() {
    std::vector<int> values{10, 20, 30, 40};
    auto it = values.begin();
    std::advance(it, 2);
    std::cout << *it << "\\n";
    std::cout << std::distance(values.begin(), values.end()) << "\\n";
    return 0;
}
''', '''30
4'''),
            CHALLENGE,
            code('''#include <iostream>
#include <string>

int main() {
    std::string word = "stressed";
    for (auto it = word.rbegin(); it != word.rend(); ++it) {
        std::cout << *it;
    }
    std::cout << "\\n";
    return 0;
}
''', '''desserts'''),
            quiz("What does end() point at?",
                 ["The last element", "One position past the last element",
                  "The first element", "Nothing until you dereference it"],
                 1, "end() is one past the last element, which is why the loop stops "
                    "when it reaches end() rather than printing it."),
           ]),

    lesson("10002", 10, "Iterators and algorithms", "Algorithms Instead of Loops",
           "Name what you want and let the library loop for you.",
           ["Replace a hand-written search with std::find.",
            "Count and sum with standard algorithms.",
            "Explain what the returned iterator means when nothing is found."],
           [exp("Say what, not how\n\n"
                "A hand-written search loop has three parts that can each be wrong: the "
                "starting condition, the increment, and the stop test. std::find writes "
                "all three once, correctly, and gives them one name.\n\n"
                "The algorithms live in <algorithm>, and numeric ones such as accumulate "
                "live in <numeric>. Both work on any range.\n\n"
                "find returns an iterator, not a value, so one call can answer the "
                "question and also tell you where."),
            dfn("Algorithm", "A standard function that walks a range given as two "
                             "iterators, with the loop already written for you."),
            exp("When nothing is found\n\n"
                "find returns end() if the value is absent. Compare against end() rather "
                "than testing the value, because end() must never be dereferenced. The "
                "distance from begin() to the found position is an index, which is only "
                "meaningful once you know the value was found."),
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{10, 20, 30, 40};
    auto found = std::find(values.begin(), values.end(), 30);
    if (found != values.end()) {
        std::cout << "found " << *found << " at index "
                  << (found - values.begin()) << "\\n";
    }
    return 0;
}
''', '''found 30 at index 2'''),
            exp("Counting and adding\n\n"
                "std::count needs only a value to look for. std::accumulate takes a "
                "starting value and an operation, which is plain addition unless you say "
                "otherwise.\n\n"
                "The starting value decides the type of the result: 0 means an int total, "
                "so summing doubles through it truncates. Give it 0.0 instead."),
            code('''#include <algorithm>
#include <iostream>
#include <numeric>
#include <vector>

int main() {
    std::vector<int> values{4, 4, 9, 1};
    std::cout << std::count(values.begin(), values.end(), 4) << "\\n";
    std::cout << std::accumulate(values.begin(), values.end(), 0) << "\\n";
    return 0;
}
''', '''2
18'''),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{7, 12, 5};
    auto biggest = std::max_element(values.begin(), values.end());
    std::cout << *biggest << "\\n";
    return 0;
}
''', '''12'''),
            quiz("Which header declares std::find?",
                 ["<numeric>", "<algorithm>", "<iterator>", "<vector>"],
                 1, "Searching, sorting and transforming live in <algorithm>; <numeric> "
                    "holds accumulate and iota."),
           ]),

    lesson("10003", 10, "Iterators and algorithms", "Transforming and Filling",
           "Change every element in place, or fill a range with a pattern.",
           ["Apply a function to every element with std::transform.",
            "Generate a sequence with std::iota.",
            "Explain how the output range decides what is written."],
           [exp("One pass, one purpose\n\n"
                "transform reads each element, applies your function, and writes the "
                "result to an output range. The output may be the same range as the "
                "input, which is how an in-place change is written.\n\n"
                "iota fills a range with consecutive values from a starting point, which "
                "removes the classic off-by-one from a counting loop.\n\n"
                "fill writes one value across a whole range, and it accepts a sub-range "
                "like begin() + 2, so part of a container can be reset."),
            dfn("Output range", "The place results are written. It can be the input "
                                "range itself, another container, or a position inside "
                                "one."),
            exp("Where the write lands\n\n"
                "Nothing is checked for you: if the output range is too small, transform "
                "writes past its end. That is a real memory error, not an exception.\n\n"
                "When the sizes differ, write to a destination that is at least as long "
                "as the source, or use the version that appends to a growing container."),
            code('''#include <algorithm>
#include <iostream>
#include <numeric>
#include <vector>

int main() {
    std::vector<int> values(4);
    std::iota(values.begin(), values.end(), 1);
    std::fill(values.begin() + 2, values.end(), 0);
    for (int value : values) {
        std::cout << value << " ";
    }
    std::cout << "\\n";
    return 0;
}
''', '''1 2 0 0 '''),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <string>

int main() {
    std::string word = "template";
    std::reverse(word.begin(), word.end());
    std::cout << word << "\\n";
    return 0;
}
''', '''etalpmet'''),
            quiz("What does std::transform return?",
                 ["A new container", "The number of elements changed",
                  "An iterator to the end of the output range", "Nothing at all"],
                 2, "The algorithm writes in place and returns the position after the "
                    "last value written."),
           ]),

    lesson("10004", 10, "Lambdas in depth", "Lambdas: Captures and State",
           "Borrow a variable by reference, copy it by value, and know the difference.",
           ["Write a lambda that captures from its surroundings.",
            "Explain the difference between [=], [&] and naming one variable.",
            "Use mutable to keep state inside a lambda."],
           [exp("A function written where it is used\n\n"
                "A lambda is a function with no name, written at the point it is needed. "
                "It has a parameter list, a body, and a capture list that decides what it "
                "may see from the surrounding scope.\n\n"
                "Nothing outside the capture list is visible. That is a feature: a "
                "reader can see exactly what the function depends on.\n\n"
                "Capturing stores a reference or a copy when the lambda is created, not "
                "when it is called."),
            dfn("Capture list", "The square bracket part of a lambda, deciding which "
                                "surrounding variables it uses, and whether by reference "
                                "or by copy."),
            exp("Reference versus copy\n\n"
                "[&above, threshold] reads the threshold as a copy and adds to above "
                "through a reference, so the outer variable changes.\n\n"
                "[=] copies everything it uses, so the outer variable is untouched. The "
                "copied value is fixed at the moment of creation, even if the outer "
                "variable changes later."),
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    int threshold = 5;
    int above = 0;
    std::vector<int> values{3, 8, 6};
    std::for_each(values.begin(), values.end(),
                  [&above, threshold](int value) {
                      if (value > threshold) {
                          ++above;
                      }
                  });
    std::cout << above << "\\n";
    return 0;
}
''', '''2'''),
            exp("State inside the lambda\n\n"
                "A lambda that captures by value cannot normally change its copy. "
                "mutable removes that restriction, and the copy then persists between "
                "calls, which is how a small counter is built.\n\n"
                "The outer variable stays whatever it was: the lambda changed its own "
                "copy, not yours."),
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    int calls = 0;
    std::vector<int> values{1, 2, 3};
    std::for_each(values.begin(), values.end(), [calls](int) mutable {
        ++calls;
        std::cout << calls << " ";
    });
    std::cout << "\\n";
    std::cout << calls << "\\n";
    return 0;
}
''', '''1 2 3 
0'''),
            CHALLENGE,
            code('''#include <iostream>

int main() {
    int total = 10;
    auto add = [total](int amount) { return total + amount; };
    std::cout << add(5) << "\\n";
    std::cout << total << "\\n";
    return 0;
}
''', '''15
10'''),
            quiz("What does [&] capture?",
                 ["Nothing", "Every used variable by copy", "Every used variable by "
                  "reference", "Only the first variable"],
                 2, "[&] captures everything the lambda uses by reference, which is why "
                    "a lambda stored beyond the variable's life is dangerous."),
           ]),

    lesson("10005", 10, "Lambdas in depth", "Sorting and Comparators",
           "One lambda decides the order of anything.",
           ["Sort with a custom comparison.",
            "Explain what the comparator must answer.",
            "Choose stable_sort when equal items must keep their order."],
           [exp("The comparator answers one question\n\n"
                "A comparator is called with two elements and must answer one thing: "
                "does the first belong before the second? It is not a test for "
                "equality, and it is not asked to return zero for a tie.\n\n"
                "So sorting largest first is a > b, ascending is a < b, and sorting "
                "words by length is a.size() < b.size().\n\n"
                "The comparison must be consistent. If it ever says a comes before b "
                "and also b comes before a, the sort may read past the end of the "
                "container."),
            dfn("Strict weak ordering", "The rule a comparator must follow: never claim "
                                        "an element comes before itself, and treat "
                                        "equal elements as interchangeable."),
            exp("Records need a field\n\n"
                "Sorting a struct means one field decides the order. The lambda takes "
                "two const references so nothing is copied during the sort.\n\n"
                "stable_sort keeps equal elements in their original order, so two "
                "players on the same score stay in the order they arrived."),
            code('''#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

struct Player {
    std::string name;
    int score;
};

int main() {
    std::vector<Player> players{{"Ada", 90}, {"Bo", 90}, {"Cy", 75}};
    std::stable_sort(players.begin(), players.end(),
                     [](const Player& a, const Player& b) {
                         return a.score > b.score;
                     });
    for (const Player& player : players) {
        std::cout << player.name << " " << player.score << "\\n";
    }
    return 0;
}
''', '''Ada 90
Bo 90
Cy 75'''),
            exp("The mistake that crashes\n\n"
                "Writing <= instead of < for equal elements tells the sort that each of "
                "two equal items belongs before the other. The algorithm trusts you, "
                "walks off the end, and the program segfaults or silently corrupts.\n\n"
                "If you need a tie-break, compare a second field instead of allowing "
                "both answers to be true."),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

int main() {
    std::vector<std::string> words{"pear", "fig", "banana"};
    std::sort(words.begin(), words.end(),
              [](const std::string& a, const std::string& b) {
                  return a.size() < b.size();
              });
    for (const std::string& word : words) {
        std::cout << word << " ";
    }
    std::cout << "\\n";
    return 0;
}
''', '''fig pear banana '''),
            quiz("What must a comparator return true for?",
                 ["When the two elements are equal",
                  "When the first element belongs before the second",
                  "When the first element is larger",
                  "When the elements should be swapped"],
                 1, "It answers one question only: does the first belong before the "
                    "second."),
           ]),

    lesson("10006", 10, "Containers", "Containers and Their Costs",
           "Pick the structure that matches the work you actually do.",
           ["Choose between vector, deque and set with a reason.",
            "Explain what capacity means for a vector.",
            "Describe what a set does to duplicates."],
           [exp("Three shapes of work\n\n"
                "vector keeps its elements side by side in memory. Adding at the end is "
                "cheap, reading is the fastest there is, and inserting in the middle "
                "moves everything after it.\n\n"
                "deque keeps chunks and allows fast work at both ends. set keeps its "
                "elements ordered as you add them, so a lookup is the same cost whether "
                "the container holds ten items or ten thousand.\n\n"
                "Start with vector. Move to something else when a measurement, or a "
                "known access pattern, says you must."),
            dfn("Capacity", "How much room a vector has reserved. It is always at least "
                            "the size, and it grows in jumps so that push_back does not "
                            "allocate every time."),
            exp("Size is not capacity\n\n"
                "size() is how many values you stored; capacity() is how many fit before "
                "the vector must find new memory. When it must grow, it allocates a "
                "bigger block and moves or copies every element into it.\n\n"
                "That is why reserve is worth calling when you already know the count: "
                "one allocation instead of several."),
            code('''#include <deque>
#include <iostream>

int main() {
    std::deque<int> values{2, 3};
    values.push_front(1);
    values.push_back(4);
    for (int value : values) {
        std::cout << value << " ";
    }
    std::cout << "\\n";
    return 0;
}
''', '''1 2 3 4 '''),
            CHALLENGE,
            code('''#include <iostream>
#include <set>

int main() {
    std::set<int> values{3, 1, 3, 2, 1};
    std::cout << values.size() << "\\n";
    for (int value : values) {
        std::cout << value << " ";
    }
    std::cout << "\\n";
    return 0;
}
''', '''3
1 2 3 '''),
            quiz("Which container stores its elements in one contiguous block?",
                 ["A set", "A deque", "A vector", "None of them"],
                 2, "vector is contiguous, which is why its data can be passed to APIs "
                    "that expect a plain array."),
           ]),

    lesson("10007", 10, "Containers", "Maps, Sets and Lookup",
           "Store a value under a key, and avoid the one operator that quietly inserts.",
           ["Insert and look up values in a map.",
            "Explain what operator[] does to a missing key.",
            "Use count and find to test for a key."],
           [exp("A key and a value\n\n"
                "A map stores pairs and keeps them ordered by key. It is the right tool "
                "whenever you find yourself scanning a vector for 'the item with this "
                "name'.\n\n"
                "find returns an iterator to the pair, or end() if the key is absent. The "
                "pair's members are first for the key and second for the value.\n\n"
                "An unordered_map does the same job with hashing, so the order is not "
                "sorted but lookup is usually faster."),
            dfn("Key", "The first half of a map entry, used to find the second half. "
                       "Every key is unique."),
            exp("The operator[] trap\n\n"
                "Writing scores[\"bo\"] on a map that has no such key does not fail: it "
                "creates the key with a default value and returns it.\n\n"
                "So merely reading a missing entry changes the map, and the next "
                "size() is larger than you expect. This is the single most common map "
                "bug.\n\n"
                "Use count() or find() to ask whether a key exists, and at() when you "
                "want an exception instead of a silent insert."),
            code('''#include <iostream>
#include <map>
#include <string>

int main() {
    std::map<std::string, int> scores;
    scores["ada"] = 90;
    int accidental = scores["bo"];
    std::cout << accidental << "\\n";
    std::cout << scores.size() << "\\n";
    std::cout << scores.count("cy") << "\\n";
    return 0;
}
''', '''0
2
0'''),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <unordered_map>

int main() {
    std::unordered_map<std::string, int> stock{{"apple", 3}, {"pear", 0}};
    std::cout << stock.count("apple") << "\\n";
    std::cout << stock.count("plum") << "\\n";
    return 0;
}
''', '''1
0'''),
            quiz("What does scores[\"new\"] do when the key is absent?",
                 ["Returns 0 and leaves the map unchanged",
                  "Throws an exception",
                  "Inserts the key with a default value",
                  "Returns end()"],
                 2, "operator[] must return a reference, so it inserts a "
                    "default-constructed value. Use count or find to test instead."),
           ]),

    lesson("10008", 10, "Containers", "Optional, Pair and Tuple",
           "Say 'there may be no value' in the type, not in a comment.",
           ["Return an optional when a function may produce nothing.",
            "Read a pair with structured bindings.",
            "Take a tuple apart with std::get."],
           [exp("Absence as part of the type\n\n"
                "A function that may fail has three old options: return a magic value, "
                "return a pointer that may be null, or throw. Each one pushes the "
                "check into a comment.\n\n"
                "std::optional<int> says it in the type: either an int, or nothing. The "
                "caller has to consider the empty case because the value has to be asked "
                "for.\n\n"
                "It needs <optional>, and it allocates nothing: the value lives inside "
                "the optional itself."),
            dfn("std::optional", "A value that either holds a T or holds nothing, "
                                 "written std::optional<T> and made empty with "
                                 "std::nullopt."),
            exp("Pairs and tuples\n\n"
                "A pair holds exactly two values of possibly different types; a tuple "
                "holds any number. Both are ordinary value types you can copy, store and "
                "return.\n\n"
                "Structured bindings take them apart in one declaration, which is why "
                "they read like a pair of named variables rather than a first and a "
                "second."),
            code('''#include <iostream>
#include <optional>

std::optional<int> to_positive(int value) {
    if (value > 0) {
        return value;
    }
    return std::nullopt;
}

int main() {
    auto answer = to_positive(-3);
    std::cout << (answer.has_value() ? "has a value" : "empty") << "\\n";
    std::cout << answer.value_or(0) << "\\n";
    std::cout << to_positive(5).value_or(0) << "\\n";
    return 0;
}
''', '''empty
0
5'''),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <tuple>

int main() {
    std::pair<std::string, int> entry{"pages", 12};
    auto [name, count] = entry;
    std::cout << name << " " << count << "\\n";

    auto row = std::make_tuple(1, std::string("ok"), 2.5);
    std::cout << std::get<0>(row) << " " << std::get<1>(row) << " "
              << std::get<2>(row) << "\\n";
    return 0;
}
''', '''pages 12
1 ok 2.5'''),
            quiz("What can std::optional store besides a value?",
                 ["A pointer to the value", "Nothing at all", "A default value of 0",
                  "An error code"],
                 1, "An optional is either engaged with a value or empty, and that "
                    "emptiness is part of its type."),
           ]),
]
