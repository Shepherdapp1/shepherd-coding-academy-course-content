"""Level 11 — Move Semantics and Resource Management."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("11001", 11, "The cost of copying", "Why Copying Costs",
           "See the copy happen, then avoid it with a reference.",
           ["Make a copy visible with a counting copy constructor.",
            "Explain why a copy of a container is expensive.",
            "Pass by const reference to avoid the copy."],
           [exp("What a copy really does\n\n"
                "Copying an int is one machine instruction. Copying a vector of a "
                "million ints is a million instructions plus an allocation, and it "
                "happens every single time you pass that vector by value.\n\n"
                "The copy is not wrong. It is simply work nobody asked for, and the "
                "bill lands in the hot path where no one looks.\n\n"
                "A copy constructor is easy to watch: give the class one that prints, "
                "and every copy becomes visible."),
            dfn("Copy constructor", "The constructor that builds a new object from an "
                                    "existing one of the same type. It runs for =, for "
                                    "passing by value, and for storing in a container."),
            exp("Making it visible\n\n"
                "This Note class holds a string and has a copy constructor that prints. "
                "Passing a Note by value to show() runs it once.\n\n"
                "Nothing in main looks like a copy. That is the point: the copy happens "
                "because of the parameter, not because of anything written at the call."),
            code('''#include <iostream>
#include <string>

struct Note {
    std::string text;
    explicit Note(std::string value) : text(std::move(value)) {}
    Note(const Note& other) : text(other.text) {
        std::cout << "copy\\n";
    }
};

void show(Note note) {
    std::cout << note.text << "\\n";
}

int main() {
    Note note("hello");
    show(note);
    return 0;
}
''', '''copy
hello'''),
            exp("The fix is one character\n\n"
                "Taking the parameter as const Note& makes it a reference: no new object, "
                "no copy, and the function still cannot change the caller's value.\n\n"
                "That is why nearly every function that only reads a non-trivial object "
                "takes it by const reference. The exception is small types such as int, "
                "double or a pointer, which are cheaper to copy than to follow."),
            code('''#include <iostream>
#include <string>

struct Note {
    std::string text;
    explicit Note(std::string value) : text(std::move(value)) {}
    Note(const Note& other) : text(other.text) {
        std::cout << "copy\\n";
    }
};

void show(const Note& note) {
    std::cout << note.text << "\\n";
}

int main() {
    Note note("hello");
    show(note);
    return 0;
}
''', '''hello'''),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <utility>

struct Box {
    std::string text;
    explicit Box(std::string value) : text(std::move(value)) {}
    Box(const Box& other) : text(other.text) {
        std::cout << "copy\\n";
    }
    Box(Box&& other) noexcept : text(std::move(other.text)) {
        std::cout << "move\\n";
    }
};

int main() {
    Box first("a");
    Box second(std::move(first));
    std::cout << second.text << "\\n";
    return 0;
}
''', '''move
a'''),
            quiz("Why is passing a large vector by value expensive?",
                 ["Because C++ cannot pass containers",
                  "Because it copies every element and allocates new memory",
                  "Because the compiler makes a backup on disk",
                  "Because it always throws"],
                 1, "By value means a brand-new container with its own copy of every "
                    "element, exactly like assigning it to a new variable."),
           ]),

    lesson("11002", 11, "The cost of copying", "Rvalue References and std::move",
           "std::move moves nothing. Learn what it actually does before you write it.",
           ["Distinguish an lvalue from an rvalue.",
            "Overload a function on && and &.",
            "Explain that std::move is only a cast."],
           [exp("Lvalues and rvalues\n\n"
                "An lvalue is a name that persists: a variable you can take the address "
                "of and use again on the next line. An rvalue is a temporary that is "
                "about to disappear, such as the result of a construction.\n\n"
                "An rvalue reference, written T&&, binds only to those temporaries. That "
                "lets a function know that nobody else will look at the object afterwards, "
                "so its contents may be stolen instead of copied.\n\n"
                "std::move is a cast from lvalue to rvalue reference. It performs no "
                "movement at all. The moving, if any, happens inside whatever constructor "
                "receives the result."),
            dfn("Rvalue reference", "A reference written T&& that binds to a temporary, "
                                    "signalling that its contents may be taken."),
            dfn("std::move", "A cast that makes an lvalue look like a temporary so that "
                             "a move constructor can be chosen. It moves nothing by "
                             "itself."),
            exp("Choosing between them\n\n"
                "Two overloads of take() show the difference in one run: a named string "
                "goes to the const& version, a temporary goes to the && version, and "
                "std::move(name) makes the named string choose && as well.\n\n"
                "Once an object has been moved from, it is valid but unspecified: you may "
                "assign to it or destroy it, and nothing else may be assumed."),
            code('''#include <iostream>
#include <string>
#include <utility>

void take(const std::string& value) {
    std::cout << "lvalue: " << value << "\\n";
}

void take(std::string&& value) {
    std::cout << "rvalue: " << value << "\\n";
}

int main() {
    std::string name = "ada";
    take(name);
    take(std::string("bo"));
    take(std::move(name));
    return 0;
}
''', '''lvalue: ada
rvalue: bo
rvalue: ada'''),
            exp("Moving into a member\n\n"
                "A move constructor takes the pointer or buffer of the other object "
                "instead of copying it, then leaves the source empty. That is why the "
                "operation is cheap regardless of how much data is held.\n\n"
                "This Holder class moves a string member. The member's own move "
                "constructor does the work; the class only has to choose std::move instead "
                "of copying."),
            code('''#include <iostream>
#include <string>
#include <utility>

struct Holder {
    std::string text;
    explicit Holder(std::string value) : text(value) {}
    Holder(Holder&& other) noexcept : text(std::move(other.text)) {
        std::cout << "moved\\n";
    }
};

int main() {
    Holder first("data");
    Holder second(std::move(first));
    std::cout << second.text << "\\n";
    return 0;
}
''', '''moved
data'''),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <utility>

int main() {
    const std::string source = "fixed";
    std::string copy = std::move(source);
    std::cout << copy << "\\n";
    std::cout << source << "\\n";
    return 0;
}
''', '''fixed
fixed'''),
            quiz("What does std::move do on its own?",
                 ["Frees the memory of the argument",
                  "Casts to an rvalue reference; nothing is moved",
                  "Copies the argument and destroys the original",
                  "Marks the variable as const"],
                 1, "It is a cast. Whether anything is actually moved depends on the "
                    "constructor or assignment that receives it."),
           ]),

    lesson("11003", 11, "Writing move operations", "Move Constructors and Assignment",
           "Write the two functions that make moving real.",
           ["Write a move constructor that leaves the source safe.",
            "Write a move assignment that releases the old resource first.",
            "Explain self-move and why it is guarded."],
           [exp("Take the pointer, empty the source\n\n"
                "A class that owns a heap buffer cannot copy it cheaply, so a move "
                "constructor simply takes the pointer and the size, then sets the source "
                "to zero and null.\n\n"
                "That leaves the source in a state that is safe to destroy: delete[] on "
                "null does nothing. The destructor must therefore be correct for a moved-"
                "from object, or the program crashes at the end of the scope.\n\n"
                "Move assignment does one extra thing: it must release whatever the "
                "destination already owned before taking the new pointer."),
            dfn("Moved-from state", "A valid but empty state left behind after a move. "
                                    "It must be safe to destroy and safe to assign to."),
            exp("The two functions in full\n\n"
                "Move assignment checks for self-assignment, deletes its own buffer, then "
                "copies the pointer and empties the source. The copy operations are "
                "deleted here, so the class can only be moved, which makes the behaviour "
                "unambiguous.\n\n"
                "The noexcept on both is not decoration: it tells the standard containers "
                "they may move during reallocation instead of copying."),
            code('''#include <iostream>
#include <utility>

class Buffer {
public:
    explicit Buffer(int size) : size_(size), data_(new int[size]{}) {
        std::cout << "alloc " << size_ << "\\n";
    }
    ~Buffer() { delete[] data_; }

    Buffer(const Buffer&) = delete;
    Buffer& operator=(const Buffer&) = delete;

    Buffer(Buffer&& other) noexcept
        : size_(other.size_), data_(other.data_) {
        other.size_ = 0;
        other.data_ = nullptr;
        std::cout << "moved " << size_ << "\\n";
    }

    Buffer& operator=(Buffer&& other) noexcept {
        if (this != &other) {
            delete[] data_;
            size_ = other.size_;
            data_ = other.data_;
            other.size_ = 0;
            other.data_ = nullptr;
        }
        return *this;
    }

    int size() const { return size_; }

private:
    int size_;
    int* data_;
};

int main() {
    Buffer first(3);
    Buffer second(std::move(first));
    std::cout << second.size() << " " << first.size() << "\\n";
    return 0;
}
''', '''alloc 3
moved 3
3 0'''),
            exp("The container prefers a move\n\n"
                "push_back with a temporary takes the temporary by move rather than "
                "copying it, so a Tracked object reports born then moved rather than "
                "born then copied.\n\n"
                "When the vector later grows, its elements are moved too, which is only "
                "allowed because the move constructor is noexcept."),
            code('''#include <iostream>
#include <vector>

class Tracked {
public:
    Tracked() { std::cout << "born\\n"; }
    Tracked(const Tracked&) { std::cout << "copied\\n"; }
    Tracked(Tracked&&) noexcept { std::cout << "moved\\n"; }
};

int main() {
    std::vector<Tracked> items;
    items.reserve(2);
    items.push_back(Tracked());
    items.push_back(Tracked());
    std::cout << items.size() << "\\n";
    return 0;
}
''', '''born
moved
born
moved
2'''),
            CHALLENGE,
            code('''#include <iostream>
#include <utility>

struct Token {
    int id;
    explicit Token(int value) : id(value) {}
    Token(const Token& other) : id(other.id) {}
    Token(Token&& other) noexcept : id(other.id) { other.id = -1; }
};

int main() {
    Token first(7);
    Token second(std::move(first));
    std::cout << second.id << " " << first.id << "\\n";
    return 0;
}
''', '''7 -1'''),
            quiz("Why must a moved-from object still be destructible?",
                 ["Because the destructor runs at the end of its scope anyway",
                  "Because the compiler calls it twice",
                  "Because move constructors delete their argument",
                  "It does not need to be"],
                 0, "A moved-from object still reaches the end of its lifetime, so its "
                    "destructor runs: a null pointer or zero size keeps that safe."),
           ]),

    lesson("11004", 11, "Writing move operations", "The Rule of Five",
           "Declare all five, or declare none, and know which one you are breaking.",
           ["List the five special member functions.",
            "Explain what declaring a destructor suppresses.",
            "Decide when to write all five and when to write none."],
           [exp("Five functions, one decision\n\n"
                "A class has five special functions: the destructor, the copy "
                "constructor, the copy assignment, the move constructor and the move "
                "assignment.\n\n"
                "If your class manages a resource it needs a destructor, and the moment "
                "you write one the compiler stops generating the move operations. Moves "
                "silently become copies, and copies silently become the old bug.\n\n"
                "That is the rule of five: if you need one of them, you almost certainly "
                "need all five."),
            dfn("Special member function", "One of the five operations the compiler "
                                           "generates unless you supply your own: "
                                           "destructor, copy constructor, copy "
                                           "assignment, move constructor, move "
                                           "assignment."),
            exp("The move that never gets written\n\n"
                "Noisy has a destructor and a copy constructor. Because it declares a "
                "destructor, the compiler does not generate a move constructor, so "
                "push_back copies the temporary instead of moving it.\n\n"
                "Nothing warns you. The program is correct and slower than it should be, "
                "and one printed line is the only evidence."),
            code('''#include <iostream>
#include <vector>

class Noisy {
public:
    Noisy() = default;
    ~Noisy() { std::cout << "gone\\n"; }
    Noisy(const Noisy&) { std::cout << "copied\\n"; }
};

int main() {
    std::vector<Noisy> items;
    items.reserve(4);
    items.push_back(Noisy());
    return 0;
}
''', '''copied
gone
gone'''),
            exp("Rule of Zero\n\n"
                "The better answer for most classes is to own nothing directly. Hold a "
                "string, a vector or a unique_ptr and let those types handle their own "
                "copies and moves: the compiler's generated five are then all correct and "
                "you write none.\n\n"
                "Write the five yourself only when you own a raw resource no library type "
                "already manages. When you do, mark the move operations noexcept."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <vector>

class Report {
public:
    explicit Report(std::string title) : title_(std::move(title)) {}
    const std::string& title() const { return title_; }
private:
    std::string title_;
};

int main() {
    Report first("first");
    Report second = first;
    std::vector<Report> reports;
    reports.push_back(Report("third"));
    std::cout << second.title() << " " << reports[0].title() << "\\n";
    return 0;
}
''', '''first third'''),
            quiz("Which move operation does the app use when a vector grows?",
                 ["The copy constructor", "The move constructor",
                  "The destructor", "None"],
                 1, "If the element's move constructor is noexcept the vector moves; "
                    "otherwise it copies, to keep its strong guarantee."),
           ]),

    lesson("11005", 11, "Ownership", "RAII: Ownership as a Guarantee",
           "Tie the resource to the lifetime of an object and stop writing delete.",
           ["Explain what RAII guarantees.",
            "Use unique_ptr to own a heap object.",
            "Predict the order resources are released in."],
           [exp("Every acquisition inside a constructor\n\n"
                "RAII is one rule: acquire in a constructor, release in a destructor. "
                "Because destructors run at the end of scope, during a return, and while "
                "an exception is unwinding, the release happens no matter how you "
                "leave.\n\n"
                "The classic alternative is a manual delete on every exit path, and the "
                "bug is always the exit path someone forgot.\n\n"
                "unique_ptr is RAII for a single heap object. It cannot be copied, only "
                "moved, so ownership is a fact the compiler enforces rather than a "
                "comment."),
            dfn("RAII", "Resource Acquisition Is Initialisation: a resource is owned by "
                        "an object, so its lifetime follows the object's scope."),
            dfn("unique_ptr", "An owner of one heap object. Copying is forbidden; "
                              "moving transfers the ownership."),
            exp("Ownership can be given away, never shared\n\n"
                "std::move transfers the pointer. Afterwards the original is empty, and "
                "asking whether it still owns anything is a simple test.\n\n"
                "This is the default choice for heap objects: if you need sharing, you "
                "should be able to say why."),
            code('''#include <iostream>
#include <memory>
#include <utility>

int main() {
    std::unique_ptr<int> value(new int(7));
    std::cout << *value << "\\n";
    auto other = std::move(value);
    std::cout << (value ? "still owns" : "gave up ownership") << "\\n";
    std::cout << *other << "\\n";
    return 0;
}
''', '''7
gave up ownership
7'''),
            exp("The destructor runs at the closing brace\n\n"
                "A Guard that prints on construction and destruction shows the order: "
                "open, use, close at the end of the block, then the code after it.\n\n"
                "make_unique does the allocation and never leaves a moment where a raw "
                "pointer could be lost."),
            code('''#include <iostream>
#include <memory>

struct Guard {
    const char* name;
    explicit Guard(const char* value) : name(value) {
        std::cout << "open " << name << "\\n";
    }
    ~Guard() { std::cout << "close " << name << "\\n"; }
};

int main() {
    {
        auto guard = std::make_unique<Guard>("file");
        std::cout << "using " << guard->name << "\\n";
    }
    std::cout << "after scope\\n";
    return 0;
}
''', '''open file
using file
close file
after scope'''),
            CHALLENGE,
            code('''#include <iostream>
#include <memory>
#include <vector>

int main() {
    std::vector<std::unique_ptr<int>> numbers;
    numbers.push_back(std::make_unique<int>(1));
    numbers.push_back(std::make_unique<int>(2));
    for (const auto& number : numbers) {
        std::cout << *number << " ";
    }
    std::cout << "\\n";
    return 0;
}
''', '''1 2 '''),
            quiz("When is the object owned by a unique_ptr destroyed?",
                 ["At the end of the program only",
                  "When the unique_ptr is destroyed or reset",
                  "When it is moved",
                  "When it is first read"],
                 1, "The owner's destructor deletes it, which is why the object's "
                    "lifetime follows the owner's scope."),
           ]),

    lesson("11006", 11, "Ownership", "Shared Ownership and Its Cost",
           "Use shared_ptr when two owners are genuinely required, and know what it costs.",
           ["Explain what a reference count protects.",
            "Use weak_ptr to observe without owning.",
            "Say when shared_ptr is the wrong choice."],
           [exp("A count decides the end\n\n"
                "shared_ptr keeps a count of how many owners exist. Copying an owner "
                "increases it, destroying one decreases it, and the object dies when the "
                "last owner goes.\n\n"
                "The count is atomic, so it is safe across threads, and that safety is "
                "paid for on every copy.\n\n"
                "Sharing is the exception, not the default: a unique_ptr that is moved "
                "expresses most ownership in real programs."),
            dfn("Reference count", "The number of shared owners of one object. The "
                                   "object is destroyed when it reaches zero."),
            dfn("weak_ptr", "An observer that does not keep the object alive and can "
                            "report whether it is still there."),
            exp("Watching without owning\n\n"
                "A weak_ptr does not increase the count. It can be asked whether the "
                "object has expired, which is how a cache or a back-reference avoids "
                "keeping something alive forever.\n\n"
                "Two shared_ptr objects pointing at each other is the classic leak: each "
                "keeps the other's count above zero, so neither is ever destroyed. One "
                "side of such a pair must be a weak_ptr."),
            code('''#include <iostream>
#include <memory>

int main() {
    auto owner = std::make_shared<int>(9);
    std::weak_ptr<int> watcher = owner;
    std::cout << (watcher.expired() ? "gone" : "alive") << "\\n";
    owner.reset();
    std::cout << (watcher.expired() ? "gone" : "alive") << "\\n";
    return 0;
}
''', '''alive
gone'''),
            CHALLENGE,
            code('''#include <iostream>
#include <memory>

int main() {
    auto first = std::make_shared<int>(42);
    std::cout << first.use_count() << "\\n";
    {
        auto second = first;
        std::cout << first.use_count() << "\\n";
    }
    std::cout << first.use_count() << "\\n";
    return 0;
}
''', '''1
2
1'''),
            quiz("What is the cost of copying a shared_ptr?",
                 ["Nothing", "An atomic increment of the reference count",
                  "A deep copy of the object", "A new allocation of the object"],
                 1, "The object is shared, not copied; only the count changes, and that "
                    "change is atomic."),
           ]),

    lesson("11007", 11, "Returning values", "Returning Values and Copy Elision",
           "Return by value and stop worrying: the compiler removes the copy.",
           ["Explain what copy elision removes.",
            "State what C++17 guarantees on a returned temporary.",
            "Avoid defeating elision with std::move on a return."],
           [exp("The copy you were told to avoid\n\n"
                "Older advice said never return a large object by value. That advice is "
                "out of date: the compiler builds the returned object directly in the "
                "caller's storage, and neither a copy nor a move happens.\n\n"
                "The compiler is even allowed to skip the constructor entirely. Since "
                "C++17 this is guaranteed when you return a temporary, so the behaviour "
                "no longer depends on optimisation settings.\n\n"
                "Return by value. It is both the clearest and the fastest form."),
            dfn("Copy elision", "Building an object directly where it is needed instead "
                                "of constructing a temporary and copying it there."),
            exp("What C++17 guarantees\n\n"
                "Returning Report(\"ready\") constructs the object once, in the caller's "
                "variable. Even a class with a printing move constructor shows only the "
                "ordinary construction and no move.\n\n"
                "Returning a named local is the same idea under the name NRVO, which every "
                "mainstream compiler performs but which is not guaranteed by the "
                "standard. Write the natural code and let it happen."),
            code('''#include <iostream>
#include <string>
#include <utility>

struct Report {
    std::string text;
    explicit Report(std::string value) : text(std::move(value)) {
        std::cout << "built\\n";
    }
    Report(const Report&) { std::cout << "copied\\n"; }
    Report(Report&&) noexcept { std::cout << "moved\\n"; }
};

Report make() {
    return Report("ready");
}

int main() {
    auto report = make();
    std::cout << report.text << "\\n";
    return 0;
}
''', '''built
ready'''),
            exp("Do not write std::move on a return\n\n"
                "Writing return std::move(local); turns the returned object into an "
                "rvalue reference, which blocks NRVO and forces a real move. It is the "
                "one place where adding std::move makes code slower.\n\n"
                "Return the name itself. The compiler already knows the local is about to "
                "be destroyed."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>

std::string greeting() {
    return "hello " + std::string("world");
}

int main() {
    std::string text = greeting();
    std::cout << text << "\\n";
    std::cout << text.size() << "\\n";
    return 0;
}
''', '''hello world
11'''),
            quiz("What does C++17 guarantee when a function returns a temporary?",
                 ["A copy is made", "A move is made",
                  "The object is built directly in the caller", "An allocation is made"],
                 2, "Guaranteed copy elision means no copy and no move constructor call "
                    "at all for a returned temporary."),
           ]),

    lesson("11008", 11, "Returning values", "Measuring the Difference",
           "Count the copies and moves, then remove them one by one.",
           ["Instrument a class to count copies and moves.",
            "Use reserve to change what a container does.",
            "Read the counts and draw the conclusion."],
           [exp("Make the invisible visible\n\n"
                "A copy you cannot see is a copy you cannot argue about. Two static "
                "counters incremented in the copy and move constructors turn every "
                "decision into a number you can print.\n\n"
                "This is the fastest way to settle an argument about performance without "
                "a profiler: build the smallest program that isolates the decision and "
                "let the counters speak.\n\n"
                "The counters are static because they describe the class, not one object."),
            dfn("Instrumentation", "Temporary counting or printing added to a class so "
                                   "that an otherwise invisible operation can be "
                                   "measured."),
            exp("What reserve changed\n\n"
                "With room already reserved, two push_back calls of temporaries cost two "
                "moves and zero copies. Remove the reserve and the vector must grow, "
                "which adds relocation work on top.\n\n"
                "Now the choice is a measurement, not a preference: reserve when you know "
                "the count."),
            code('''#include <iostream>
#include <vector>

struct Tracked {
    static int copies;
    static int moves;
    Tracked() = default;
    Tracked(const Tracked&) { ++copies; }
    Tracked(Tracked&&) noexcept { ++moves; }
};
int Tracked::copies = 0;
int Tracked::moves = 0;

int main() {
    std::vector<Tracked> items;
    items.reserve(4);
    items.push_back(Tracked());
    items.push_back(Tracked());
    std::cout << "moves " << Tracked::moves
              << " copies " << Tracked::copies << "\\n";
    return 0;
}
''', '''moves 2 copies 0'''),
            exp("Copying an existing element\n\n"
                "push_back on a named object cannot move it, because the original is "
                "still in use after the call. The counter records a copy, which is "
                "correct and expected.\n\n"
                "If the original is genuinely finished, std::move makes the intent "
                "explicit and turns that copy into a move."),
            CHALLENGE,
            code('''#include <iostream>
#include <utility>
#include <vector>

struct Tracked {
    static int copies;
    static int moves;
    Tracked() = default;
    Tracked(const Tracked&) { ++copies; }
    Tracked(Tracked&&) noexcept { ++moves; }
};
int Tracked::copies = 0;
int Tracked::moves = 0;

int main() {
    std::vector<Tracked> items;
    items.reserve(4);
    Tracked original;
    items.push_back(original);
    items.push_back(std::move(original));
    std::cout << "moves " << Tracked::moves
              << " copies " << Tracked::copies << "\\n";
    return 0;
}
''', '''moves 1 copies 1'''),
            quiz("What does reserve change?",
                 ["The size of the vector", "How many elements fit before reallocation",
                  "The number of copies the compiler makes", "Nothing at all"],
                 1, "reserve sets capacity, not size: it removes the reallocation and "
                    "the relocation of existing elements."),
           ]),
]
