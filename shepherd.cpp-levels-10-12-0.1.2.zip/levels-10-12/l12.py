"""Level 12 — Exceptions and Error Handling."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("12001", 12, "Exceptions", "What an Exception Is",
           "Throw stops the function, runs the destructors, and lands in a catch.",
           ["Separate the failure path from the normal return value.",
            "Catch an exception by const reference.",
            "Explain stack unwinding."],
           [exp("A failure that cannot return a value\n\n"
                "divide() cannot answer with an int when the divisor is zero, and it "
                "should not pick a magic number that the caller might print. throw ends "
                "the function immediately and hands a value to whoever is prepared to "
                "handle it.\n\n"
                "The normal path stays clean: no out-parameters, no checking a return "
                "code after every call, and no way for the failure to be ignored by "
                "accident.\n\n"
                "The thrown object travels up the call stack until a catch matches it. If "
                "none does, the program terminates, which is why main should always "
                "handle what it can."),
            dfn("Exception", "An object thrown to signal failure, caught by a handler "
                             "that matches its type."),
            dfn("Stack unwinding", "What happens between throw and catch: every "
                                   "automatic object in the abandoned functions is "
                                   "destroyed."),
            exp("Destructors still run\n\n"
                "A Guard prints in its destructor. When the throw passes through its "
                "scope, the destructor runs before the catch is entered, so the release "
                "message appears first.\n\n"
                "This is the reason RAII and exceptions fit together: the cleanup does "
                "not need to know an exception happened."),
            code('''#include <iostream>
#include <stdexcept>

int divide(int a, int b) {
    if (b == 0) {
        throw std::invalid_argument("cannot divide by zero");
    }
    return a / b;
}

int main() {
    try {
        std::cout << divide(9, 3) << "\\n";
        std::cout << divide(1, 0) << "\\n";
        std::cout << "never printed\\n";
    } catch (const std::invalid_argument& error) {
        std::cout << "caught: " << error.what() << "\\n";
    }
    return 0;
}
''', '''3
caught: cannot divide by zero'''),
            CHALLENGE,
            code('''#include <iostream>
#include <stdexcept>

struct Guard {
    ~Guard() { std::cout << "guard released\\n"; }
};

int main() {
    try {
        Guard guard;
        throw std::runtime_error("boom");
    } catch (const std::runtime_error& error) {
        std::cout << "caught: " << error.what() << "\\n";
    }
    return 0;
}
''', '''guard released
caught: boom'''),
            quiz("What happens to automatic objects between throw and catch?",
                 ["They are leaked", "They are destroyed in reverse order",
                  "They are kept for the catch", "They are copied to the heap"],
                 1, "Stack unwinding destroys every automatic object in each abandoned "
                    "scope, last created first."),
           ]),

    lesson("12002", 12, "Exceptions", "Catching Correctly",
           "Catch by reference, most specific first, and keep one last resort.",
           ["Catch by const reference and explain why.",
            "Order catch clauses from specific to general.",
            "Use catch(...) as a final safety net."],
           [exp("Why the ampersand matters\n\n"
                "catch (const std::exception& error) binds to the thrown object itself. "
                "Catching by value instead slices it: the derived part is cut away and "
                "you no longer see the real type.\n\n"
                "That is why nearly every catch reads catch (const SomeType& name). It "
                "costs nothing and preserves everything.\n\n"
                "The clauses are tried in order, so the most specific type must come "
                "first; a catch for the base class placed early would swallow the "
                "derived ones."),
            dfn("Slicing", "Losing the derived part of an exception by catching it by "
                           "value instead of by reference."),
            exp("The last resort\\n\\n"
                "catch (...) matches anything at all, including types that are not "
                "classes. It has no name for the exception, so it can only log that "
                "something happened and stop.\n\n"
                "Keep it at the end of main, not scattered through the program: an "
                "unknown exception reaching main means something above did not do its "
                "job, and swallowing it everywhere hides real bugs."),
            code('''#include <iostream>
#include <stdexcept>

int main() {
    try {
        throw std::out_of_range("index 9");
    } catch (const std::out_of_range& error) {
        std::cout << "range: " << error.what() << "\\n";
    } catch (const std::exception& error) {
        std::cout << "other: " << error.what() << "\\n";
    }
    return 0;
}
''', '''range: index 9'''),
            CHALLENGE,
            code('''#include <iostream>

int main() {
    try {
        throw 42;
    } catch (const char* text) {
        std::cout << "text " << text << "\\n";
    } catch (...) {
        std::cout << "something was thrown\\n";
    }
    return 0;
}
''', '''something was thrown'''),
            quiz("Which catch order is correct?",
                 ["Base class before derived class",
                  "Derived class before base class",
                  "Any order; the compiler sorts them",
                  "Only one catch clause is allowed"],
                 1, "Clauses are tested in order, so a base class catch placed first "
                    "would hide every derived type behind it."),
           ]),

    lesson("12003", 12, "Exceptions", "Exceptions Across Functions",
           "Let the throw travel, and add context without losing the original.",
           ["Trace an exception through several functions.",
            "Rethrow with a bare throw.",
            "Decide which function should handle a failure."],
           [exp("The caller does not have to be the catcher\n\n"
                "A function that cannot deal with a failure should not catch it. The "
                "exception passes through, and each level decides whether it is the right "
                "place to react.\n\n"
                "That is what makes a deep failure survivable: nothing in the middle has "
                "to know how to recover, and the code that does know is usually the one "
                "holding the user interface or the transaction.\n\n"
                "The stack unwinds as it travels, so no intermediate function leaks its "
                "resources on the way out."),
            dfn("Propagation", "An exception continuing up through callers that do not "
                               "catch it, unwinding each one."),
            exp("Rethrowing keeps the original\\n\\n"
                "A bare throw; inside a catch clause throws the same exception again, "
                "preserving its type. A middle layer can therefore note that it saw the "
                "failure and still let the outer layer handle it.\n\n"
                "throw error; would copy the caught object and lose the original's "
                "identity. Use the bare throw when the intent is to pass it on."),
            code('''#include <iostream>
#include <stdexcept>

void inner() {
    throw std::runtime_error("disk full");
}

void outer() {
    try {
        inner();
    } catch (const std::exception&) {
        std::cout << "outer noticed\\n";
        throw;
    }
}

int main() {
    try {
        outer();
    } catch (const std::exception& error) {
        std::cout << "main says: " << error.what() << "\\n";
    }
    return 0;
}
''', '''outer noticed
main says: disk full'''),
            exp("Handling higher up\\n\\n"
                "A validation function deep in the call chain throws; main catches and "
                "prints. Nothing between the two has any exception code at all, which is "
                "the ordinary shape of a well-behaved program."),
            code('''#include <iostream>
#include <stdexcept>

int parse(int value) {
    if (value < 0) {
        throw std::domain_error("negative value");
    }
    return value * 2;
}

int middle(int value) {
    return parse(value);
}

int main() {
    try {
        std::cout << middle(4) << "\\n";
        std::cout << middle(-1) << "\\n";
    } catch (const std::domain_error& error) {
        std::cout << "handled at the top: " << error.what() << "\\n";
    }
    return 0;
}
''', '''8
handled at the top: negative value'''),
            CHALLENGE,
            code('''#include <iostream>
#include <stdexcept>
#include <string>

std::string describe(int value) {
    if (value == 0) {
        throw std::invalid_argument("zero has no sign");
    }
    return value > 0 ? "positive" : "negative";
}

int main() {
    for (int value : {5, -2, 0}) {
        try {
            std::cout << describe(value) << "\\n";
        } catch (const std::invalid_argument& error) {
            std::cout << "skipped: " << error.what() << "\\n";
        }
    }
    return 0;
}
''', '''positive
negative
skipped: zero has no sign'''),
            quiz("What does a bare throw; do inside a catch clause?",
                 ["Throws a new default exception", "Rethrows the same exception",
                  "Ends the program", "Returns from the function"],
                 1, "It propagates the exception being handled, keeping its original "
                    "type."),
           ]),

    lesson("12004", 12, "Exceptions", "RAII Makes Exceptions Safe",
           "Local objects release themselves on the way out, in reverse order.",
           ["Explain why manual cleanup fails during unwinding.",
            "Rely on destructors for release.",
            "Predict the release order of two resources."],
           [exp("Every exit path, without listing them\\n\\n"
                "A function that returns early, throws, or reaches its closing brace has "
                "three exit paths. Manual cleanup must be repeated three times, and the "
                "one that gets forgotten is always the one nobody tests.\n\n"
                "A destructor runs on all three. That is the whole argument for RAII and "
                "the reason exceptions do not leak in well-written C++.\n\n"
                "Resources are released in the reverse of the order they were created, "
                "which is usually the dependency order you want."),
            dfn("Release order", "Locals die last-created-first, so a resource that "
                                 "depends on another is destroyed before it."),
            exp("Two resources, one throw\\n\\n"
                "db is created first and file second, so file is released first. The "
                "catch then runs, and main continues normally.\n\n"
                "Nothing in the try block mentions cleanup. The release messages are the "
                "destructors doing their job during unwinding."),
            code('''#include <iostream>
#include <stdexcept>
#include <string>
#include <utility>

struct Resource {
    std::string name;
    explicit Resource(std::string value) : name(std::move(value)) {
        std::cout << "acquire " << name << "\\n";
    }
    ~Resource() { std::cout << "release " << name << "\\n"; }
};

int main() {
    try {
        Resource first("db");
        Resource second("file");
        throw std::runtime_error("fail");
    } catch (const std::exception&) {
        std::cout << "recovered\\n";
    }
    return 0;
}
''', '''acquire db
acquire file
release file
release db
recovered'''),
            exp("The library types already do this\\n\\n"
                "unique_ptr, string, vector and the stream types all release in their "
                "destructors. Using them means you are already exception safe without "
                "writing a single try.\n\n"
                "The memory here is freed before the catch runs, so no leak is possible "
                "even though the throw happened in the middle of the work."),
            CHALLENGE,
            code('''#include <iostream>
#include <memory>
#include <stdexcept>

int main() {
    try {
        auto value = std::make_unique<int>(5);
        throw std::runtime_error("fail");
    } catch (const std::exception&) {
        std::cout << "caught, memory already freed\\n";
    }
    return 0;
}
''', '''caught, memory already freed'''),
            quiz("Why is RAII the basis of exception safety?",
                 ["Because destructors are never called",
                  "Because destructors run during unwinding on every exit path",
                  "Because exceptions skip destructors",
                  "Because it avoids exceptions"],
                 1, "Unwinding destroys locals, so ownership tied to a local is released "
                    "however the function exits."),
           ]),

    lesson("12005", 12, "Exception safety", "The Three Guarantees",
           "Say what your function leaves behind when it fails.",
           ["Name the three exception safety guarantees.",
            "Design a function that never half-changes anything.",
            "Mark a function noexcept when it truly cannot throw."],
           [exp("Three levels, one choice per function\n\n"
                "No guarantee: the program may be left in any state. Nobody should write "
                "this on purpose.\n\n"
                "The basic guarantee: the program stays valid and leaks nothing, but "
                "values may have changed. This is the minimum acceptable.\n\n"
                "The strong guarantee: the operation either succeeds completely or leaves "
                "everything exactly as it was. Callers can retry as if nothing happened."),
            dfn("Strong guarantee", "On failure, no observable change: the operation is "
                                    "all or nothing."),
            dfn("noexcept", "A promise that a function does not throw. Breaking it calls "
                            "std::terminate rather than unwinding."),
            exp("Validate before you change anything\\n\\n"
                "add_item checks the argument before touching the vector, so a rejected "
                "call leaves the container exactly as it was. This is the cheapest way to "
                "get the strong guarantee: do the checks first, then mutate.\n\n"
                "When several changes must happen together and any of them could fail, "
                "the usual tool is to build the new state aside and swap it in."),
            CHALLENGE,
            code('''#include <iostream>
#include <stdexcept>
#include <vector>

void add_item(std::vector<int>& items, int value) {
    if (value < 0) {
        throw std::invalid_argument("negative");
    }
    items.push_back(value);
}

int main() {
    std::vector<int> items{1, 2};
    try {
        add_item(items, -5);
    } catch (const std::exception&) {
        std::cout << "rejected\\n";
    }
    std::cout << items.size() << "\\n";
    return 0;
}
''', '''rejected
2'''),
            code('''#include <iostream>

int safe(int value) noexcept {
    return value + 1;
}

int main() {
    std::cout << safe(41) << "\\n";
    std::cout << (noexcept(safe(1)) ? "promises not to throw" : "may throw") << "\\n";
    return 0;
}
''', '''42
promises not to throw'''),
            quiz("What does the strong guarantee promise?",
                 ["The function never throws",
                  "On failure the program is still valid but values may change",
                  "On failure nothing observable changed",
                  "The function is faster"],
                 2, "All-or-nothing: a failed call leaves the observable state exactly "
                    "as it was, so the caller can retry."),
           ]),

    lesson("12006", 12, "Exception safety", "Copy and Swap",
           "Assign safely by making the copy first and swapping at the end.",
           ["Explain why operator= is hard to get right.",
            "Implement assignment with copy and swap.",
            "State why self-assignment then needs no special case."],
           [exp("What goes wrong in a hand-written assignment\\n\\n"
                "The destination already owns memory. It must free that memory, then "
                "allocate new memory, then copy. If the allocation or the copy throws "
                "after the free, the object is left broken and its destructor will free "
                "the same pointer again.\n\n"
                "The strong guarantee fixes this by doing the risky work first, while the "
                "object is still untouched.\n\n"
                "Copy and swap is the standard shape: take the parameter by value so the "
                "copy is made before anything else, then swap with the finished copy."),
            dfn("Copy and swap", "Assignment that builds a complete copy, then exchanges "
                                 "its contents with the destination so the old state is "
                                 "destroyed by the copy's destructor."),
            exp("Why self-assignment stops being a problem\\n\\n"
                "When the argument is the same object, it was copied on the way in, so "
                "the swap is between two different objects and the original survives.\n\n"
                "You still need a swap that cannot throw, which is why swap is marked "
                "noexcept and only exchanges a pointer and a size."),
            code('''#include <algorithm>
#include <iostream>
#include <utility>

class Numbers {
public:
    explicit Numbers(int size) : size_(size), data_(new int[size]{}) {}

    Numbers(const Numbers& other)
        : size_(other.size_), data_(new int[other.size_] {}) {
        std::copy(other.data_, other.data_ + size_, data_);
    }

    Numbers& operator=(Numbers other) {
        swap(other);
        return *this;
    }

    ~Numbers() { delete[] data_; }

    void swap(Numbers& other) noexcept {
        std::swap(size_, other.size_);
        std::swap(data_, other.data_);
    }

    void set(int index, int value) { data_[index] = value; }
    int get(int index) const { return data_[index]; }
    int size() const { return size_; }

private:
    int size_;
    int* data_;
};

int main() {
    Numbers first(2);
    first.set(0, 7);
    Numbers second(3);
    second = first;
    std::cout << second.size() << " " << second.get(0) << "\\n";
    std::cout << first.size() << " " << first.get(0) << "\\n";
    return 0;
}
''', '''2 7
2 7'''),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <utility>

class Pocket {
public:
    explicit Pocket(int coins) : coins_(coins) {}
    Pocket(const Pocket& other) : coins_(other.coins_) {}
    Pocket& operator=(Pocket other) {
        swap(other);
        return *this;
    }
    void swap(Pocket& other) noexcept { std::swap(coins_, other.coins_); }
    int coins() const { return coins_; }
private:
    int coins_;
};

int main() {
    Pocket wallet(5);
    wallet = wallet;
    std::cout << wallet.coins() << "\\n";
    return 0;
}
''', '''5'''),
            quiz("Why does copy and swap give the strong guarantee?",
                 ["Because swap cannot fail and the copy is finished before any change",
                  "Because it never allocates",
                  "Because it catches its own exceptions",
                  "Because it marks operator= noexcept"],
                 0, "All the risky work happens while building the copy; the only step "
                    "that touches the destination is a noexcept swap."),
           ]),

    lesson("12007", 12, "Exception safety", "noexcept and Destructors",
           "A promise the compiler can act on, and the one place you must not break it.",
           ["Mark move operations noexcept.",
            "Explain what the containers do differently when a move is noexcept.",
            "Keep destructors from throwing."],
           [exp("Why the container cares\\n\\n"
                "When a vector grows it must transfer every element to new memory. If a "
                "move could throw halfway through, some elements would be in the new "
                "block and some in the old, and no arrangement restores the original.\n\n"
                "So the standard library moves only when the move is noexcept; "
                "otherwise it copies, because a copy failing leaves the source "
                "untouched.\n\n"
                "Marking your move constructor noexcept is therefore not decoration: it "
                "decides which operation the container uses."),
            dfn("move_if_noexcept", "The rule a vector follows when relocating: move if "
                                    "that cannot throw, copy otherwise."),
            exp("Destructors and no-throw zones\\n\\n"
                "A destructor runs during unwinding. If it threw while another exception "
                "was in flight, there would be two exceptions at once and the program "
                "would have no way to choose, so the language terminates.\n\n"
                "Destructors should be treated as noexcept by default: release a "
                "resource, print nothing that could fail, and never throw. If cleanup can "
                "fail, provide an explicit close() the caller can call and handle."),
            code('''#include <iostream>
#include <vector>

struct Safe {
    static int copies;
    static int moves;
    Safe() = default;
    Safe(const Safe&) { ++copies; }
    Safe(Safe&&) noexcept { ++moves; }
};
int Safe::copies = 0;
int Safe::moves = 0;

int main() {
    std::vector<Safe> items;
    items.reserve(2);
    items.push_back(Safe());
    std::cout << "moves " << Safe::moves << " copies " << Safe::copies << "\\n";
    return 0;
}
''', '''moves 1 copies 0'''),
            exp("Remove the noexcept and watch it copy\\n\\n"
                "Risky has a move constructor that is not noexcept. When the vector grows "
                "it refuses to use it and copies the existing element instead, so the "
                "counters show one copy that a noexcept would have made a move.\n\n"
                "This is the concrete cost of an unmarked move, and it is invisible unless "
                "you count."),
            code('''#include <iostream>
#include <vector>

struct Risky {
    static int copies;
    static int moves;
    Risky() = default;
    Risky(const Risky&) { ++copies; }
    Risky(Risky&&) { ++moves; }
};
int Risky::copies = 0;
int Risky::moves = 0;

int main() {
    std::vector<Risky> items;
    items.push_back(Risky());
    items.push_back(Risky());
    std::cout << "moves " << Risky::moves << " copies " << Risky::copies << "\\n";
    return 0;
}
''', '''moves 2 copies 1'''),
            CHALLENGE,
            code('''#include <iostream>
#include <utility>

struct Clean {
    int id;
    explicit Clean(int value) : id(value) {}
    ~Clean() noexcept = default;
    Clean(Clean&& other) noexcept : id(other.id) { other.id = 0; }
};

int main() {
    Clean first(4);
    Clean second(std::move(first));
    std::cout << second.id << " " << first.id << "\\n";
    std::cout << (noexcept(Clean(std::move(first))) ? "move cannot throw" : "move may throw")
              << "\\n";
    return 0;
}
''', '''4 0
move cannot throw'''),
            quiz("Why does a vector copy instead of move when the move is not noexcept?",
                 ["Because it cannot find the move constructor",
                  "Because a throw part-way through moving would leave elements split "
                  "between two blocks",
                  "Because copying is always faster",
                  "Because noexcept is only for destructors"],
                 1, "Copying leaves the source intact if it fails, which preserves the "
                    "vector's strong guarantee."),
           ]),

    lesson("12008", 12, "Exceptions", "When Not to Throw",
           "Exceptions are for the unexpected; use a return value for the expected.",
           ["Decide between an exception and a return value.",
            "Use an enum result for a recoverable outcome.",
            "Keep constructors valid by throwing on bad input."],
           [exp("Two kinds of failure\\n\\n"
                "A failure the caller expects and can handle normally is not exceptional: "
                "a search that finds nothing, a parse that rejects input, a user who "
                "cancels. Returning a value or an optional makes that case visible in "
                "the type and keeps the cost at nothing.\n\n"
                "An exception is for the case that must not be ignored and cannot be "
                "handled locally: a broken invariant, a missing file the program needs, a "
                "negative age. It cannot be silently skipped because the alternative is "
                "an abandoned call stack.\n\n"
                "Throwing is not slow because of the throw itself but because of the "
                "unwinding, so a rare path pays a price no ordinary path should."),
            dfn("Error code", "A returned value describing what went wrong, used when the "
                              "failure is an ordinary outcome the caller must handle."),
            exp("A constructor cannot return a code\\n\\n"
                "A class that must never exist in an invalid state cannot report failure "
                "through a return value, because there is no object to return it from. "
                "throw is the only way out of a constructor, which is exactly why input "
                "validation belongs there.\\n\\n"
                "Outside constructors, prefer the quiet return. Reserve exceptions for "
                "the paths where letting the call stack stop is the desired behaviour."),
            code('''#include <iostream>

enum class Result { ok, divided_by_zero };

Result divide(int a, int b, int& answer) {
    if (b == 0) {
        return Result::divided_by_zero;
    }
    answer = a / b;
    return Result::ok;
}

int main() {
    int answer = 0;
    if (divide(8, 0, answer) == Result::ok) {
        std::cout << answer << "\\n";
    } else {
        std::cout << "no answer\\n";
    }
    return 0;
}
''', '''no answer'''),
            code('''#include <iostream>
#include <stdexcept>

class Age {
public:
    explicit Age(int value) : value_(value) {
        if (value < 0) {
            throw std::invalid_argument("age cannot be negative");
        }
    }
    int value() const { return value_; }
private:
    int value_;
};

int main() {
    try {
        Age bad(-1);
    } catch (const std::invalid_argument& error) {
        std::cout << error.what() << "\\n";
    }
    Age good(30);
    std::cout << good.value() << "\\n";
    return 0;
}
''', '''age cannot be negative
30'''),
            CHALLENGE,
            code('''#include <iostream>
#include <optional>
#include <string>

std::optional<int> find_index(const std::string& text, char wanted) {
    for (std::size_t index = 0; index < text.size(); ++index) {
        if (text[index] == wanted) {
            return static_cast<int>(index);
        }
    }
    return std::nullopt;
}

int main() {
    std::cout << find_index("hello", 'l').value_or(-1) << "\\n";
    std::cout << find_index("hello", 'z').value_or(-1) << "\\n";
    return 0;
}
''', '''2
-1'''),
            quiz("When is an exception the right choice?",
                 ["For every possible failure",
                  "For an unexpected failure that must not be ignored and cannot be "
                  "handled locally",
                  "For a search that finds nothing",
                  "For performance reasons"],
                 1, "Expected outcomes belong in the return type; exceptions are for "
                    "failures that must stop the normal flow."),
           ]),
]
