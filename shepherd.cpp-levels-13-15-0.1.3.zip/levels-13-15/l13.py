"""Level 13 — Testing and Debugging."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("13001", 13, "Why tests exist", "A Test Is an Argument You Can Re-run",
           "Write the check you keep doing by hand, and let the machine do it forever.",
           ["Explain what a test protects you from.",
            "Write a check that compares an actual result with an expected one.",
            "Describe what makes a test worth keeping."],
           [exp("The check you already do\n\n"
                "Every time you run a program to see whether it printed the right "
                "answer, you are testing by eye. It works once, for one input, and it "
                "costs your attention every time you change anything.\n\n"
                "A test is that same comparison, written down: give the function an "
                "input, compare the result with what it should be, and print FAIL if "
                "they differ. The machine repeats it in milliseconds, forever.\n\n"
                "The value is not that the test finds a bug today. It is that the test "
                "notices the day a later change breaks something that used to work."),
            dfn("Test", "A small program that calls a function with a known input and "
                        "compares the result with a known answer, reporting a failure "
                        "when they disagree."),
            exp("The shape of every test\n\n"
                "Three steps, in this order: arrange the input, call the code, compare. "
                "The comparison is the only part that decides pass or fail, and it must "
                "be explicit rather than a printed value you read yourself.\n\n"
                "This check returns a bool and prints both values on failure, so the "
                "output tells you what went wrong instead of only that something did."),
            code('''#include <iostream>

int add(int a, int b) {
    return a + b;
}

bool check_add(int a, int b, int expected) {
    int actual = add(a, b);
    if (actual != expected) {
        std::cout << "FAIL add(" << a << ", " << b << ") = " << actual
                  << ", expected " << expected << "\\n";
        return false;
    }
    return true;
}

int main() {
    bool ok = true;
    ok = check_add(2, 3, 5) && ok;
    ok = check_add(-1, 1, 0) && ok;
    std::cout << (ok ? "all passed" : "there were failures") << "\\n";
    return 0;
}
''', '''all passed'''),
            exp("A failing test looks like this\n\n"
                "The same program with a wrong expectation prints the failure line and "
                "names both numbers, which is what makes a test useful: it explains "
                "itself without a debugger.\n\n"
                "Notice that every check still runs. Combining with && after the call "
                "keeps later checks alive even after one fails, so one run reports every "
                "problem instead of stopping at the first."),
            code('''#include <iostream>

int add(int a, int b) {
    return a + b;
}

bool check_add(int a, int b, int expected) {
    int actual = add(a, b);
    if (actual != expected) {
        std::cout << "FAIL add(" << a << ", " << b << ") = " << actual
                  << ", expected " << expected << "\\n";
        return false;
    }
    return true;
}

int main() {
    bool ok = true;
    ok = check_add(2, 3, 5) && ok;
    ok = check_add(4, 4, 9) && ok;
    std::cout << (ok ? "all passed" : "there were failures") << "\\n";
    return 0;
}
''', '''FAIL add(4, 4) = 8, expected 9
there were failures'''),
            CHALLENGE,
            code('''#include <iostream>

int half(int value) {
    return value / 2;
}

int main() {
    int result = half(9);
    std::cout << (result == 4 ? "PASS" : "FAIL") << ": half(9) = " << result << "\\n";
    return 0;
}
''', '''PASS: half(9) = 4'''),
            quiz("What is the real value of a test you keep?",
                 ["It proves the program has no bugs",
                  "It notices when a later change breaks behaviour that used to work",
                  "It makes the program run faster",
                  "It replaces the compiler"],
                 1, "Tests are a guard against regressions: they hold today's behaviour "
                    "still while you change the code."),
           ]),

    lesson("13002", 13, "Why tests exist", "assert and Static Assertions",
           "One line that stops the program the moment an assumption is false.",
           ["Use assert to check an assumption while developing.",
            "Explain what NDEBUG does to assert.",
            "Choose static_assert for something knowable at compile time."],
           [exp("An assumption written down\n\n"
                "assert(condition) checks a condition and, if it is false, prints the "
                "expression, the file and the line, then aborts. It costs one line and "
                "turns a silent wrong answer into an immediate stop.\n\n"
                "It lives in <cassert>. Use it for things that must be true for the code "
                "to make sense: an index inside the array, a denominator that is not "
                "zero, a size that is not negative.\n\n"
                "Defining NDEBUG before the include removes every assert. That is what a "
                "release build usually does, so an assert must never carry work the "
                "program depends on."),
            dfn("assert", "A runtime check from <cassert> that aborts the program with a "
                          "message when the condition is false. Compiled out when "
                          "NDEBUG is defined."),
            dfn("static_assert", "A compile-time check. It fires while building, so a "
                                 "mistake never reaches a running program."),
            exp("The failure, and what it looks like\n\n"
                "The passing assertion prints nothing. The failing one prints the "
                "expression and the location, then aborts, which is deliberately loud: a "
                "broken assumption should not continue quietly.\n\n"
                "Because abort ends the program, an assert on user input is the wrong "
                "tool. Validate input and throw; assert your own invariants."),
            code('''#include <cassert>
#include <iostream>

int at(const int* data, int size, int index) {
    assert(index >= 0 && index < size);
    return data[index];
}

int main() {
    int values[3] = {10, 20, 30};
    std::cout << at(values, 3, 1) << "\\n";
    std::cout << "still running\\n";
    return 0;
}
''', '''20
still running'''),
            exp("The version that cannot wait for a test run\n\n"
                "static_assert is checked by the compiler, so it costs nothing at run "
                "time and cannot be skipped by a release build. It is the right tool "
                "whenever the fact is known while compiling.\n\n"
                "A failed static_assert stops the build with your message, which is the "
                "earliest possible moment to learn about the mistake."),
            code('''#include <iostream>

int main() {
    static_assert(sizeof(int) >= 4, "this code assumes a 32-bit int");
    std::cout << "assumption holds\\n";
    return 0;
}
''', '''assumption holds'''),
            CHALLENGE,
            code('''#include <cassert>
#include <iostream>

int divide(int a, int b) {
    assert(b != 0);
    return a / b;
}

int main() {
    std::cout << divide(9, 3) << "\\n";
    return 0;
}
''', '''3'''),
            quiz("What happens to assert when NDEBUG is defined?",
                 ["It throws an exception", "It is removed entirely",
                  "It prints a warning and continues", "It becomes static_assert"],
                 1, "Every assert compiles away, so an assert must never be the only "
                    "thing doing real work."),
           ]),

    lesson("13003", 13, "Building a harness", "A Tiny Test Harness",
           "Count the passes, list the failures, and exit with a code a script can read.",
           ["Track passing and failing checks in two counters.",
            "Print a summary a human can scan.",
            "Return a non-zero exit code when anything failed."],
           [exp("From checks to a report\n\n"
                "One check that prints FAIL is useful. Twenty checks need a summary: how "
                "many ran, how many passed, and which ones failed. Two counters and one "
                "function give you all three.\n\n"
                "The exit code matters more than the printing. A program that returns 0 "
                "has succeeded; anything else has failed, and that is how a script, a "
                "build server or another program decides whether to continue."),
            dfn("Exit code", "The integer a program returns from main. Zero means "
                             "success by convention; anything else means failure."),
            exp("The counters\n\n"
                "Each check increments one counter. At the end, main prints both and "
                "returns 1 if any check failed, so the harness behaves like a test "
                "runner rather than a report.\n\n"
                "This is the whole harness. Every testing framework you will ever use is "
                "this idea with better formatting."),
            code('''#include <iostream>

int checks = 0;
int failures = 0;

void expect_equal(int actual, int expected, const char* name) {
    ++checks;
    if (actual != expected) {
        ++failures;
        std::cout << "FAIL " << name << ": got " << actual
                  << ", expected " << expected << "\\n";
    }
}

int square(int value) {
    return value * value;
}

int main() {
    expect_equal(square(3), 9, "square(3)");
    expect_equal(square(-4), 16, "square(-4)");
    expect_equal(square(0), 1, "square(0)");
    std::cout << checks - failures << " passed, " << failures << " failed\\n";
    return failures == 0 ? 0 : 1;
}
''', '''FAIL square(0): got 0, expected 1
2 passed, 1 failed'''),
            exp("Silence when everything passes\n\n"
                "A passing run prints one summary line and nothing else. That quiet is "
                "the point: output only when something needs attention.\n\n"
                "A failing run names the check. Which is why the name is a parameter: "
                "\"square(0)\" tells you where to look, while \"check 3 failed\" does "
                "not."),
            CHALLENGE,
            code('''#include <iostream>

int checks = 0;
int failures = 0;

void expect_equal(int actual, int expected, const char* name) {
    ++checks;
    if (actual != expected) {
        ++failures;
        std::cout << "FAIL " << name << "\\n";
    }
}

int main() {
    expect_equal(2 + 2, 4, "addition");
    expect_equal(3 * 3, 9, "multiplication");
    std::cout << checks - failures << " passed, " << failures << " failed\\n";
    return failures == 0 ? 0 : 1;
}
''', '''2 passed, 0 failed'''),
            quiz("What should a test program return from main when every check passed?",
                 ["1", "0", "The number of checks", "Nothing"],
                 1, "Zero means success, so a failing run must return non-zero for any "
                    "caller to notice."),
           ]),

    lesson("13004", 13, "Building a harness", "Edge Cases Are the Test",
           "Test the empty, the zero, the negative and the boundary, not the easy middle.",
           ["List the edge cases of a simple function.",
            "Write tests for empty input and for boundaries.",
            "Explain why the happy path alone proves little."],
           [exp("Where the bugs live\n\n"
                "A function that sums a list works for a list of three numbers almost by "
                "accident. The bugs hide in the empty list, the single element, the "
                "negative number, zero as a divisor, the last valid index, and one past "
                "it.\n\n"
                "So the useful tests are the ones at the edges. The middle case will "
                "almost always pass and almost never tell you anything.\n\n"
                "Before writing tests, list the edges in words. The list is often longer "
                "than you expect, and writing it is where the missing validation "
                "appears."),
            dfn("Edge case", "An input at the boundary of what a function accepts: empty, "
                             "zero, negative, the maximum, or exactly at the limit."),
            exp("Empty and single\n\n"
                "sum of an empty vector is 0 by definition, and the test says so out "
                "loud so nobody later \"fixes\" it to crash. The single-element case "
                "catches loops that skip the first or run once too often.\n\n"
                "These two tests are always worth writing for anything that takes a "
                "collection."),
            code('''#include <iostream>
#include <vector>

int total(const std::vector<int>& values) {
    int sum = 0;
    for (int value : values) {
        sum += value;
    }
    return sum;
}

void check(int actual, int expected, const char* name) {
    std::cout << (actual == expected ? "PASS " : "FAIL ") << name << "\\n";
}

int main() {
    check(total({}), 0, "empty list");
    check(total({7}), 7, "one element");
    check(total({-5, 5}), 0, "cancelling pair");
    return 0;
}
''', '''PASS empty list
PASS one element
PASS cancelling pair'''),
            exp("Boundaries of a search\n\n"
                "A search that returns an index has four edges: the first element, the "
                "last element, an element that is absent, and an empty container. Missing "
                "any of them leaves a case that only a user can find.\n\n"
                "The absent case is the one that catches the classic off-by-one, because "
                "it is the case where the loop must stop without success."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

int find_index(const std::vector<int>& values, int wanted) {
    for (std::size_t i = 0; i < values.size(); ++i) {
        if (values[i] == wanted) {
            return static_cast<int>(i);
        }
    }
    return -1;
}

void check(int actual, int expected, const char* name) {
    std::cout << (actual == expected ? "PASS " : "FAIL ") << name << "\\n";
}

int main() {
    check(find_index({}, 3), -1, "empty list");
    check(find_index({4, 5, 6}, 4), 0, "first element");
    check(find_index({4, 5, 6}, 6), 2, "last element");
    check(find_index({4, 5, 6}, 9), -1, "absent");
    return 0;
}
''', '''PASS empty list
PASS first element
PASS last element
PASS absent'''),
            quiz("Which test is most likely to find a real bug?",
                 ["A list of three ordinary numbers", "An empty list",
                  "A list the code was written for", "A list of ten numbers"],
                 1, "Empty input, boundaries and absent values are where off-by-one and "
                    "missing checks live."),
           ]),

    lesson("13005", 13, "Reading errors", "Reading a Compiler Error",
           "Read the first error, find your line, and ignore the cascade beneath it.",
           ["Find the real error among the cascade.",
            "Read a missing semicolon and an undeclared name.",
            "Explain why the last error is usually the least useful."],
           [exp("The compiler tells you where it noticed, not where you erred\n\n"
                "A missing semicolon on line 5 is reported when line 6 fails to parse, so "
                "the named line can be the innocent one. The real mistake is usually just "
                "above it.\n\n"
                "Errors also cascade: one missing brace produces dozens of complaints. "
                "Read the first error in each file, fix it, and rebuild before reading "
                "further.\n\n"
                "The last error in a long list is almost never the cause. It is the point "
                "where the compiler gave up trying to recover."),
            dfn("Cascade", "A long run of errors caused by one mistake, which disappears "
                           "when that mistake is fixed."),
            exp("The two errors you will meet most\n\n"
                "'expected ; before ...' almost always means the previous statement is "
                "missing a semicolon. 'was not declared in this scope' means a name is "
                "misspelt, used before it is defined, or comes from a header you forgot "
                "to include.\n\n"
                "Both are located by looking one line up and at the include list, not by "
                "staring at the reported line."),
            code('''#include <iostream>

int main() {
    int total = 0;
    total = total + 1
    std::cout << total << "\\n";
    return 0;
}
''', '''main.cpp:5:22: error: expected ';' before 'std'
5 |     total = total + 1
  |                      ^
  |                      ;
''', language="text"),
            exp("The fix\n\n"
                "One character. The program was correct apart from the missing semicolon, "
                "and the compiler's message named the following line because that is where "
                "the grammar broke.\n\n"
                "This is why the habit is: read the message, look at the line above, and "
                "change one thing before rebuilding."),
            code('''#include <iostream>

int main() {
    int total = 0;
    total = total + 1;
    std::cout << total << "\\n";
    return 0;
}
''', '''1'''),
            CHALLENGE,
            code('''#include <iostream>

int main() {
    int value = 3;
    std::cout << value << "\\n";
    return 0;
}
''', '''3'''),
            quiz("Where should you look first when the compiler reports an error?",
                 ["The last error in the list", "The first error, and the line above it",
                  "The linker output", "The program's runtime output"],
                 0, "The first error is the cause; the rest are usually its cascade, and "
                    "the mistake often sits one line above the reported position."),
           ]),

    lesson("13006", 13, "Reading errors", "When a Program Crashes",
           "A segfault has a cause you can find by narrowing the input.",
           ["Recognise the common causes of a crash.",
            "Narrow a crash by reducing the input.",
            "Use a sanitizer to get the line number."],
           [exp("What a crash actually is\n\n"
                "A segmentation fault means the program touched memory it does not own. "
                "The usual causes are a null pointer, an index past the end, a dangling "
                "pointer to something already destroyed, and reading an uninitialised "
                "value as if it were a pointer.\n\n"
                "The crash often happens later than the mistake, because writing out of "
                "bounds corrupts a neighbour that is only used much afterwards.\n\n"
                "That delay is why narrowing matters: shrink the input until the smallest "
                "reproduction fails, and the offending statement is usually next to it."),
            dfn("Sanitizer", "A compiler option that instruments the program to report "
                             "the exact line where memory was misused, instead of crashing "
                             "somewhere later."),
            exp("The tools that name the line\n\n"
                "Compiling with -fsanitize=address,undefined turns a silent corruption "
                "into a report naming the statement and the allocation. Run it in the "
                "terminal; the message is worth learning to read.\n\n"
                "Compile the same program twice, once with the sanitizer for testing and "
                "once without for release. The sanitizer costs speed, not correctness."),
            code('''g++ -std=c++17 -g -fsanitize=address,undefined -Wall main.cpp -o program
./program
''', '''main.cpp:6:16: runtime error: index 5 out of bounds for type 'int [3]'
''', language="text"),
            exp("Bounds checking by hand, then by the library\n\n"
                "The program below shows the defensive habit: check the index before "
                "using it. The alternative is std::vector and at(), which throws instead "
                "of corrupting memory.\n\n"
                "Reading past the end of an array is undefined behaviour: it may crash, "
                "print a wrong number, or appear to work. 'It worked when I tried it' is "
                "not evidence."),
            code('''#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{10, 20, 30};
    int index = 5;
    if (index >= 0 && index < static_cast<int>(values.size())) {
        std::cout << values[static_cast<std::size_t>(index)] << "\\n";
    } else {
        std::cout << "index " << index << " is out of range\\n";
    }
    return 0;
}
''', '''index 5 is out of range'''),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{1, 2};
    try {
        std::cout << values.at(7) << "\\n";
    } catch (const std::out_of_range& error) {
        std::cout << "caught: " << error.what() << "\\n";
    }
    return 0;
}
''', '''caught: vector::_M_range_check: __n (which is 7) >= this->size() (which is 2)'''),
            quiz("Why can an out-of-bounds write crash much later?",
                 ["Because the compiler delays it",
                  "Because it corrupts memory that is only used afterwards",
                  "Because memory is checked at the end of the program",
                  "It cannot; it always crashes immediately"],
                 1, "Undefined behaviour damages neighbouring memory, and the damage is "
                    "noticed only when that memory is next used."),
           ]),

    lesson("13007", 13, "Finding the fault", "Debug Prints and Bisecting",
           "Halve the problem instead of reading everything.",
           ["Add temporary prints that answer one question.",
            "Bisect a program by commenting out halves.",
            "Remove the prints once the fault is found."],
           [exp("Ask the program a question\n\n"
                "A debug print is not decoration: each one should answer a specific "
                "question, such as 'did this branch run?' or 'what is the value here?'. "
                "Print the value and the line, or you will forget which print is which.\n\n"
                "When you know the last point where the data was correct and the first "
                "where it was wrong, the fault lies between them, and the prints have "
                "narrowed it to a few statements.\n\n"
                "Delete the prints when you are done. A print left in a loop turns a "
                "readable program into a flood."),
            dfn("Bisect", "Repeatedly halving the part of the program under suspicion "
                          "until the faulty statement is isolated."),
            exp("Narrowing with a value print\n\n"
                "This loop is meant to total the values but resets the accumulator each "
                "time. One print of the running total on each pass makes the fault "
                "obvious at a glance.\n\n"
                "The print answers exactly one question: what is the total after each "
                "iteration. That is enough."),
            code('''#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{2, 3, 4};
    int total = 0;
    for (int value : values) {
        total = value;
        std::cout << "debug: total after " << value << " is " << total << "\\n";
    }
    std::cout << total << "\\n";
    return 0;
}
''', '''debug: total after 2 is 2
debug: total after 3 is 3
debug: total after 4 is 4
4'''),
            exp("The fixed version, prints removed\n\n"
                "total += value instead of total = value. The running total climbs, and "
                "the final answer is the sum.\n\n"
                "The prints have done their job and are gone, which is the difference "
                "between debugging and leaving a mess behind."),
            code('''#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{2, 3, 4};
    int total = 0;
    for (int value : values) {
        total += value;
    }
    std::cout << total << "\\n";
    return 0;
}
''', '''9'''),
            CHALLENGE,
            code('''#include <iostream>

int main() {
    int a = 3;
    int b = 4;
    std::cout << "debug a=" << a << " b=" << b << "\\n";
    std::cout << a * b << "\\n";
    return 0;
}
''', '''debug a=3 b=4
12'''),
            quiz("What makes a debug print useful?",
                 ["Printing every variable at every step",
                  "Answering one specific question about the program's state",
                  "Being left in the final code",
                  "Using the loudest format possible"],
                 1, "Targeted prints narrow the search; a flood of output hides the "
                    "answer you are looking for."),
           ]),

    lesson("13008", 13, "Finding the fault", "A Debugging Routine",
           "A repeatable method beats staring at the code.",
           ["Reproduce a fault reliably before changing anything.",
            "Form one hypothesis and test it.",
            "Write the test that would have caught it."],
           [exp("The routine\n\n"
                "First, reproduce it every time with the smallest input you can find. A "
                "fault you cannot reproduce cannot be fixed, only guessed at.\n\n"
                "Second, form one hypothesis and test it with one change or one print. "
                "Changing three things at once means you learn nothing whichever way it "
                "goes.\n\n"
                "Third, when it works, write the failing test before you move on. The "
                "fault is now a case that will be checked forever, which is the only way "
                "a bug stays fixed."),
            dfn("Reproduction", "The smallest reliable set of steps or input that shows "
                                "the fault, which is what every later change is tested "
                                "against."),
            exp("The bug, then the test that catches it\n\n"
                "average() divides by size without checking. Called with an empty "
                "container it divides by zero, which is undefined for integers.\n\n"
                "The test below is written before the fix: it calls the function with an "
                "empty container and expects a defined answer. It fails now, and it will "
                "pass once the guard is added, and it will stay in the file."),
            code('''#include <iostream>
#include <vector>

double average(const std::vector<int>& values) {
    int sum = 0;
    for (int value : values) {
        sum += value;
    }
    return static_cast<double>(sum) / static_cast<double>(values.size());
}

int main() {
    std::cout << average({2, 4}) << "\\n";
    return 0;
}
''', '''3'''),
            exp("The guard, and the test that stays\n\n"
                "The empty case now returns 0 instead of dividing by zero, and the test "
                "states that as a requirement rather than leaving it to chance.\n\n"
                "This is the shape of every finished bug: a guard in the code and a check "
                "in the tests, both pointing at each other."),
            code('''#include <iostream>
#include <vector>

double average(const std::vector<int>& values) {
    if (values.empty()) {
        return 0.0;
    }
    int sum = 0;
    for (int value : values) {
        sum += value;
    }
    return static_cast<double>(sum) / static_cast<double>(values.size());
}

int main() {
    std::cout << average({}) << "\\n";
    std::cout << average({2, 4}) << "\\n";
    std::cout << ((average({}) == 0.0) ? "PASS empty average" : "FAIL") << "\\n";
    return 0;
}
''', '''0
3
PASS empty average'''),
            CHALLENGE,
            code('''#include <iostream>

int main() {
    int attempts = 0;
    for (int i = 0; i < 3; ++i) {
        ++attempts;
    }
    std::cout << (attempts == 3 ? "PASS loop ran three times" : "FAIL") << "\\n";
    return 0;
}
''', '''PASS loop ran three times'''),
            quiz("Why write the failing test before fixing the bug?",
                 ["To make the build fail on purpose",
                  "So the fault is checked forever and cannot come back",
                  "Because tests must fail at least once",
                  "To slow the program down"],
                 1, "The test becomes the proof of the fix and the guard against a "
                    "regression."),
           ]),
]
