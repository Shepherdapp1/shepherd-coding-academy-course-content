"""Level 14 — Streams, Files and Text."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("14001", 14, "Streams", "A Stream Is a Stateful Pipe",
           "A stream remembers whether it is still working, and every read can fail.",
           ["Explain what cin returns and why it converts to bool.",
            "Check a stream after reading.",
            "Recover a stream with clear()."],
           [exp("One pipe for everything\n\n"
                "cin, cout and the file streams are all the same kind of object. You put "
                "characters in or take them out, and the stream handles the buffering and "
                "the formatting.\n\n"
                "A stream also carries a state: good, end-of-file, or failed. Once it has "
                "failed it stays failed and every later read does nothing, which is why an "
                "unchecked failure looks like a silent program.\n\n"
                "That is why a read expression converts to bool: while (std::cin >> value) "
                "asks 'is the stream still usable?' before using the value."),
            dfn("Stream state", "A flag on a stream saying whether it is usable, has "
                                "reached the end, or has failed. A failed stream ignores "
                                "every later operation until cleared."),
            exp("Reading until the input runs out\n\n"
                "The loop keeps reading while the stream is good. When the input ends, the "
                "stream reaches end-of-file, the expression becomes false, and the loop "
                "stops without any special handling.\n\n"
                "This shape reads a number of arbitrary length from the keyboard or a pipe "
                "and is the standard way to consume input in C++."),
            code('''#include <iostream>
#include <sstream>

int main() {
    std::istringstream input("4 8 15");
    int value = 0;
    int total = 0;
    while (input >> value) {
        total += value;
    }
    std::cout << total << "\\n";
    std::cout << (input.eof() ? "reached the end" : "stopped early") << "\\n";
    return 0;
}
''', '''27
reached the end'''),
            exp("When the input is not what you expected\n\n"
                "A failed stream stays failed. Asking it to read again does nothing and "
                "the variable keeps its old value, which is how a loop can run forever or "
                "produce a wrong sum.\n\n"
                "clear() resets the failure flag. After that you must also discard the "
                "characters that caused the failure, which is what the loop below does "
                "with ignore."),
            code('''#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::istringstream input("12 abc");
    int value = 0;
    int second = 0;
    input >> value;
    input >> second;
    std::cout << value << "\\n";
    std::cout << (input.fail() ? "read failed" : "read worked") << "\\n";
    input.clear();
    std::string rest;
    input >> rest;
    std::cout << "next token: " << rest << "\\n";
    return 0;
}
''', '''12
read failed
next token: abc'''),
            CHALLENGE,
            code('''#include <iostream>
#include <sstream>

int main() {
    std::istringstream input("1 2 3 4");
    int count = 0;
    int value = 0;
    while (input >> value) {
        ++count;
    }
    std::cout << count << "\\n";
    return 0;
}
''', '''4'''),
            quiz("What does a failed stream do with later operations?",
                 ["Retries them", "Ignores them until clear() is called",
                  "Throws an exception", "Restarts from the beginning"],
                 1, "The failure state sticks, so every later read or write does nothing "
                    "until the flag is cleared."),
           ]),

    lesson("14002", 14, "Streams", "Reading Text Properly",
           "getline takes the whole line; >> stops at the first space.",
           ["Read a whole line with getline.",
            "Explain what >> leaves behind in the stream.",
            "Mix >> and getline safely."],
           [exp("Two very different reads\n\n"
                "The extraction operator >> skips leading whitespace, reads one token, and "
                "stops at the next whitespace. It is for numbers and single words.\n\n"
                "getline reads everything up to and including a newline, keeps the spaces "
                "inside the line, and removes the newline. It is for sentences, names and "
                "file lines.\n\n"
                "Using >> when you meant getline is the commonest input bug: you get one "
                "word and then an empty line on the next read."),
            dfn("getline", "A function that reads one whole line of text into a string, "
                           "including the spaces, and discards the newline."),
            exp("The trap: >> leaves the newline\n\n"
                "After reading a number with >>, the newline that ended the line is still "
                "in the stream. A following getline sees it immediately and returns an "
                "empty string.\n\n"
                "ignore() discards up to and including the newline, which puts the stream "
                "back at the start of a line and makes the next getline work."),
            code('''#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::istringstream input("42\\nAshanti Region\\n");
    int number = 0;
    input >> number;
    std::string region;
    std::getline(input, region);
    std::cout << "[" << region << "]\\n";
    input.clear();
    std::istringstream second("42\\nAshanti Region\\n");
    second >> number;
    second.ignore();
    std::getline(second, region);
    std::cout << "[" << region << "]\\n";
    return 0;
}
''', '''[]
[Ashanti Region]'''),
            exp("Reading a line at a time\n\n"
                "getline in the while condition reads until the input runs out, one line "
                "per pass. This is how a text file is processed, and it is why getline is "
                "the right tool for anything line-shaped.\n\n"
                "An empty line is a real line and is returned as an empty string, not as "
                "the end of input. Only the missing line stops the loop."),
            CHALLENGE,
            code('''#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::istringstream input("first line\\nsecond line\\n");
    std::string line;
    int count = 0;
    while (std::getline(input, line)) {
        ++count;
        std::cout << count << ": " << line << "\\n";
    }
    return 0;
}
''', '''1: first line
2: second line'''),
            code('''#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::istringstream input("Ada 1990 Accra\\n");
    std::string name;
    int year = 0;
    std::string city;
    input >> name >> year >> city;
    std::cout << name << " | " << year << " | " << city << "\\n";
    return 0;
}
''', '''Ada | 1990 | Accra'''),
            quiz("What does >> leave in the stream after reading a number?",
                 ["Nothing", "The whitespace that ended the token",
                  "The number again", "The rest of the line"],
                 1, "It stops at the whitespace and leaves it, which is why a following "
                    "getline returns an empty string without ignore()."),
           ]),

    lesson("14003", 14, "Streams", "Formatting Output",
           "Set precision once, and know which flags reset themselves.",
           ["Control decimals with std::setprecision.",
            "Pad and align a column with std::setw.",
            "Explain which manipulators are sticky."],
           [exp("Numbers do not format themselves\n\n"
                "A double prints with six significant digits by default, so 1.0/3.0 shows "
                "as 0.333333. Money, measurements and reports need a fixed number of "
                "decimals, which is what std::fixed and std::setprecision provide.\n\n"
                "The manipulators come from <iomanip>. fixed means 'always show a decimal "
                "point', and setprecision then means 'this many digits after it'.\n\n"
                "Under fixed, precision stops being about total digits and starts being "
                "about decimals. That change of meaning surprises everybody once."),
            dfn("Manipulator", "A value you write into a stream to change how it formats: "
                               "setw, setfill, setprecision, fixed, left, right."),
            exp("Sticky and one-shot\n\n"
                "fixed and setprecision stay in effect for every later number on that "
                "stream. setw applies to the next output only, which is why it is written "
                "immediately before each value in a table.\n\n"
                "Remembering which is sticky is the whole skill: a table needs setw "
                "repeated and setfill set once."),
            code('''#include <iomanip>
#include <iostream>

int main() {
    double value = 2.0 / 3.0;
    std::cout << value << "\\n";
    std::cout << std::fixed << std::setprecision(3) << value << "\\n";
    std::cout << std::setw(8) << 42 << "|\\n";
    std::cout << std::setfill('.') << std::setw(8) << 42 << "|\\n";
    return 0;
}
''', '''0.666667
0.667
      42|
......42|'''),
            exp("A readable table\n\n"
                "left aligns text and right aligns numbers, and setw gives each column a "
                "fixed width. The header uses the same widths so the columns line up.\n\n"
                "Widths are chosen from the longest value, not guessed: one longer name "
                "and the table breaks."),
            code('''#include <iomanip>
#include <iostream>
#include <string>

int main() {
    std::cout << std::left << std::setw(10) << "name" << std::right << std::setw(6)
              << "score" << "\\n";
    std::cout << std::left << std::setw(10) << "Ada" << std::right << std::setw(6)
              << 98 << "\\n";
    std::cout << std::left << std::setw(10) << "Bo" << std::right << std::setw(6)
              << 7 << "\\n";
    return 0;
}
''', '''name       score
Ada           98
Bo             7'''),
            CHALLENGE,
            code('''#include <iomanip>
#include <iostream>

int main() {
    double price = 12.5;
    std::cout << std::fixed << std::setprecision(2) << price << "\\n";
    std::cout << std::setw(6) << std::setfill('0') << 7 << "\\n";
    return 0;
}
''', '''12.50
000007'''),
            quiz("Which manipulator applies only to the next value?",
                 ["std::fixed", "std::setprecision", "std::setw", "std::setfill"],
                 2, "setw resets after one output value; the others persist on the "
                    "stream."),
           ]),

    lesson("14004", 14, "Streams", "Writing Files",
           "An ofstream opens, writes and closes itself when it goes out of scope.",
           ["Open a file for writing with std::ofstream.",
            "Explain why the file must be checked after opening.",
            "Rely on the destructor to close the file."],
           [exp("A stream that points at a file\n\n"
                "std::ofstream is cout with a file behind it. Constructing it opens the "
                "file, insertions write to it, and the destructor closes it.\n\n"
                "By default it truncates: an existing file is emptied. That is the single "
                "most destructive default in the library, so be certain of the path "
                "before you write to it.\n\n"
                "Appending instead requires std::ios::app, which keeps what is already "
                "there and adds to the end."),
            dfn("ofstream", "An output file stream from <fstream>. It creates or truncates "
                            "the named file unless std::ios::app is given."),
            exp("The check that matters\n\n"
                "Opening can fail: the directory does not exist, the disk is full, the "
                "path is a folder, or the program is running somewhere it may not write.\n\n"
                "A failed ofstream is silent. Every write is ignored and the file simply "
                "never appears, which looks like a mysterious data loss. Check with is_open "
                "or by testing the stream before writing anything that matters."),
            code('''#include <fstream>
#include <iostream>

int main() {
    std::ofstream missing("/no/such/folder/report.txt");
    std::cout << (missing.is_open() ? "opened" : "could not open") << "\\n";
    return 0;
}
''', '''could not open'''),
            exp("Write, then read it back\n\n"
                "Writing to a std::ostringstream shows the same insertions without "
                "touching the disk, so the logic can be tested anywhere. The text it "
                "collects is exactly what a file would contain.\n\n"
                "In real code, replace the ostringstream with an ofstream and the code "
                "below is unchanged: that is the point of streams all being the same "
                "type."),
            code('''#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::ostringstream report;
    report << "player,score\\n";
    report << "ada," << 98 << "\\n";
    report << "bo," << 91 << "\\n";
    std::cout << report.str();
    std::cout << "bytes: " << report.str().size() << "\\n";
    return 0;
}
''', '''player,score
ada,98
bo,91
bytes: 26'''),
            CHALLENGE,
            code('''#include <fstream>
#include <iostream>

int main() {
    std::ifstream missing("this_file_does_not_exist.txt");
    if (!missing) {
        std::cout << "no such file, and the stream is safely closed\\n";
    }
    return 0;
}
''', '''no such file, and the stream is safely closed'''),
            quiz("What does an ofstream do to an existing file by default?",
                 ["Appends to it", "Truncates it", "Refuses to open it", "Renames it"],
                 1, "The default mode empties the file; ios::app is needed to keep what "
                    "is already there."),
           ]),

    lesson("14005", 14, "Streams", "Reading Files Safely",
           "Open, check, read until the end, and know the difference between empty and missing.",
           ["Read a file line by line with ifstream.",
            "Distinguish 'file missing' from 'file empty'.",
            "Close a file deliberately when you need to."],
           [exp("Three things can happen\n\n"
                "The file may not exist, it may exist and be empty, or it may have "
                "content. Those are three different situations and a program that treats "
                "them as one will eventually report the wrong thing to a user.\n\n"
                "is_open() answers the first question before any read. The getline loop "
                "answers the third: a loop that never runs means the file was empty, not "
                "that it was missing.\n\n"
                "Counting the lines read is how you tell them apart in a report."),
            dfn("EOF", "End of file: the state a stream enters after the last character "
                       "has been read. It is not an error."),
            exp("Counting what was read\n\n"
                "The loop reads until getline fails, and the counter records how many "
                "lines arrived. Zero lines with a successful open means empty; a failed "
                "open means missing.\n\n"
                "Keeping those two apart is the difference between 'nothing to do' and "
                "'something is wrong' in every program that reads files."),
            code('''#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

int count_lines(std::istream& source) {
    std::string line;
    int count = 0;
    while (std::getline(source, line)) {
        ++count;
    }
    return count;
}

int main() {
    std::istringstream empty_input("");
    std::cout << "empty source: " << count_lines(empty_input) << " lines\\n";
    std::ifstream missing("not_here.txt");
    std::cout << (missing.is_open() ? "opened" : "missing file") << "\\n";
    return 0;
}
''', '''empty source: 0 lines
missing file'''),
            exp("Closing on purpose\n\n"
                "The destructor closes the file, but a long-running program may need the "
                "data on disk immediately rather than at the end of scope. close() does "
                "that, and the stream can be opened again afterwards.\n\n"
                "Writing to a std::ostringstream and printing the result is how the same "
                "logic is tested without a disk at all."),
            CHALLENGE,
            code('''#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::istringstream data("10\\n20\\n30\\n");
    std::string line;
    int total = 0;
    while (std::getline(data, line)) {
        total += std::stoi(line);
    }
    std::cout << total << "\\n";
    return 0;
}
''', '''60'''),
            code('''#include <fstream>
#include <iostream>

int main() {
    std::ifstream input("not_here.txt");
    if (!input.is_open()) {
        std::cout << "cannot read the file; nothing to process\\n";
        return 1;
    }
    return 0;
}
''', '''cannot read the file; nothing to process'''),
            quiz("A file opens successfully and the read loop runs zero times. Why?",
                 ["The file is missing", "The file exists and is empty",
                  "The stream failed to open", "The file is too large"],
                 1, "is_open() succeeded, so the file exists; zero lines means there was "
                    "nothing in it."),
           ]),

    lesson("14006", 14, "Parsing text", "stringstream as a Toolbox",
           "Turn text into numbers and numbers into text without touching a file.",
           ["Convert a string to a number with stoi.",
            "Split a line into fields with istringstream.",
            "Format a value into text with ostringstream."],
           [exp("Text is not a number\n\n"
                "std::stoi turns text into an int, std::stod into a double, and both throw "
                "std::invalid_argument if the text is not a number at all. A trailing "
                "junk character throws std::out_of_range or is simply ignored depending "
                "on the position.\n\n"
                "So a conversion from user input must be inside a try. This is the "
                "boundary where untrusted text becomes a trusted value, and it is the "
                "right place for the check.\n\n"
                "Going the other way, std::to_string turns a number into text with no "
                "formatting control at all; an ostringstream gives you precision and "
                "width."),
            dfn("stoi", "String to int. Throws std::invalid_argument if there are no "
                        "digits, so it must be used on text you have not yet trusted."),
            exp("Splitting a line\n\n"
                "An istringstream over one line lets >> walk its fields, which is exactly "
                "how a CSV line or a configuration line is read. The comma is the only "
                "obstacle, so it is read into a throwaway string between the values.\n\n"
                "This is the smallest useful parser, and it is enough for most "
                "comma-separated files."),
            code('''#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::istringstream line("ada,98,accra");
    std::string name;
    std::string score_text;
    std::string city;
    std::getline(line, name, ',');
    std::getline(line, score_text, ',');
    std::getline(line, city, ',');
    int score = std::stoi(score_text);
    std::cout << name << " scored " << score << " in " << city << "\\n";
    return 0;
}
''', '''ada scored 98 in accra'''),
            exp("When the text is not a number\n\n"
                "stoi on letters throws std::invalid_argument, and the catch turns it into "
                "a message a user can act on. Without the try, the program terminates.\n\n"
                "Every value that arrives as text passes through a conversion like this, "
                "and every one of those conversions is a place to be suspicious."),
            code('''#include <iostream>
#include <stdexcept>
#include <string>

int main() {
    try {
        int value = std::stoi("twelve");
        std::cout << value << "\\n";
    } catch (const std::invalid_argument& error) {
        std::cout << "not a number: " << error.what() << "\\n";
    }
    std::cout << std::stoi("42") << "\\n";
    std::cout << std::stod("2.5") * 2 << "\\n";
    return 0;
}
''', '''not a number: stoi
42
5'''),
            CHALLENGE,
            code('''#include <iomanip>
#include <iostream>
#include <sstream>

int main() {
    std::ostringstream text;
    text << std::fixed << std::setprecision(1) << 3.14159;
    std::string result = text.str();
    std::cout << result << " (" << result.size() << " chars)\\n";
    return 0;
}
''', '''3.1 (3 chars)'''),
            quiz("What does std::stoi throw when the text has no digits?",
                 ["Nothing; it returns 0", "std::invalid_argument",
                  "std::out_of_range", "It aborts the program"],
                 1, "It throws std::invalid_argument, which is why untrusted text must be "
                    "converted inside a try."),
           ]),

    lesson("14007", 14, "Parsing text", "Parsing a Simple Data File",
           "Split, convert, reject, and count what you rejected.",
           ["Parse a line into typed fields.",
            "Skip malformed lines without stopping.",
            "Report how many lines were accepted and rejected."],
           [exp("Real files are partly broken\n\n"
                "A data file written by a person or an older version has empty lines, a "
                "missing field, a stray comma, or text where a number belongs. A parser "
                "that stops at the first bad line is useless on real data.\n\n"
                "The reliable shape is: read a line, try to parse it, accept it or count "
                "it as rejected, and continue. Nothing is lost, and the counts at the end "
                "tell you whether the file was as expected.\n\n"
                "Two counters also give you a report a user can act on: how much was read "
                "and how much was skipped."),
            dfn("Defensive parsing", "Reading input so that malformed data is counted and "
                                     "skipped rather than able to stop the program."),
            exp("The parser\n\n"
                "Each line is split into a name and a score. An empty line, a missing "
                "comma, or a score that is not a number is rejected and counted, and the "
                "loop continues.\n\n"
                "The output is a summary plus the accepted rows, which is exactly what a "
                "real importer prints."),
            code('''#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::istringstream file("ada,98\\n\\nbroken line\\nbo,ninety\\ncy,75\\n");
    std::string line;
    int accepted = 0;
    int rejected = 0;
    while (std::getline(file, line)) {
        std::istringstream row(line);
        std::string name;
        std::string score_text;
        if (!std::getline(row, name, ',') || !std::getline(row, score_text, ',')) {
            ++rejected;
            continue;
        }
        try {
            int score = std::stoi(score_text);
            ++accepted;
            std::cout << "ok " << name << " " << score << "\\n";
        } catch (const std::invalid_argument&) {
            ++rejected;
        }
    }
    std::cout << "accepted " << accepted << ", rejected " << rejected << "\\n";
    return 0;
}
''', '''ok ada 98
ok cy 75
accepted 2, rejected 3'''),
            exp("Why the counts matter\n\n"
                "Two accepted and three rejected out of five lines is a report. If the file "
                "should have had fifty rows, the reject count is the first signal that "
                "something upstream changed.\n\n"
                "Printing the rejected line itself is the next step when investigating, and "
                "it costs one extra stream insertion."),
            CHALLENGE,
            code('''#include <iostream>
#include <sstream>
#include <string>

float percent(int part, int whole) {
    if (whole == 0) {
        return 0.0f;
    }
    return 100.0f * static_cast<float>(part) / static_cast<float>(whole);
}

int main() {
    std::cout << percent(2, 4) << "\\n";
    return 0;
}
''', '''50'''),
            code('''#include <iostream>
#include <sstream>
#include <string>

int main() {
    std::istringstream record("name=shepherd;version=3");
    std::string pair;
    while (std::getline(record, pair, ';')) {
        std::istringstream field(pair);
        std::string key;
        std::string value;
        std::getline(field, key, '=');
        std::getline(field, value, '=');
        std::cout << key << " -> " << value << "\\n";
    }
    return 0;
}
''', '''name -> shepherd
version -> 3'''),
            quiz("What should a parser do with a malformed line?",
                 ["Stop the program", "Skip it and count it as rejected",
                  "Insert a default row", "Print the whole file again"],
                 1, "Skipping and counting keeps the rest of the file usable and gives you "
                    "a number to report."),
           ]),

    lesson("14008", 14, "Parsing text", "Putting Streams to Work",
           "One small program that reads, validates and reports.",
           ["Combine parsing, validation and reporting in one program.",
            "Keep the reading, the checking and the printing separate.",
            "Predict the output of a mixed valid and invalid file."],
           [exp("Three jobs, three parts\n\n"
                "Even a small program reads better when reading, deciding and printing are "
                "separate. The reader fills a structure, the checker decides whether it is "
                "acceptable, and the printer reports.\n\n"
                "Separating them is what makes each part testable: the checker can be "
                "called with a value you wrote by hand, without a file anywhere.\n\n"
                "This is the same division you met in Level 13, seen from the input "
                "side."),
            dfn("Separation of concerns", "Giving reading, deciding and reporting "
                                          "different functions so each can be tested and "
                                          "changed alone."),
            exp("Read, then decide\n\n"
                "parse() turns one line into a record and reports failure through a bool. "
                "valid() is a pure question about a record. main() only connects them and "
                "prints.\n\n"
                "The line with a negative score is parsed successfully and rejected by a "
                "rule, which is a different failure from a line that cannot be parsed at "
                "all."),
            code('''#include <iostream>
#include <sstream>
#include <string>

struct Entry {
    std::string name;
    int score = 0;
};

bool parse(const std::string& line, Entry& entry) {
    std::istringstream row(line);
    std::string score_text;
    if (!std::getline(row, entry.name, ',') || !std::getline(row, score_text, ',')) {
        return false;
    }
    try {
        entry.score = std::stoi(score_text);
    } catch (const std::invalid_argument&) {
        return false;
    }
    return true;
}

bool valid(const Entry& entry) {
    return !entry.name.empty() && entry.score >= 0 && entry.score <= 100;
}

int main() {
    std::istringstream file("ada,98\\nbo,-4\\ncy,88\\n");
    std::string line;
    int shown = 0;
    while (std::getline(file, line)) {
        Entry entry;
        if (!parse(line, entry) || !valid(entry)) {
            std::cout << "skipped: " << line << "\\n";
            continue;
        }
        ++shown;
        std::cout << entry.name << " " << entry.score << "\\n";
    }
    std::cout << shown << " entries accepted\\n";
    return 0;
}
''', '''ada 98
skipped: bo,-4
cy 88
2 entries accepted'''),
            exp("Why the split matters later\n\n"
                "Because valid() takes one entry and returns a bool, it can be tested with "
                "three values and no input at all, and it can be reused when the data "
                "arrives from a file, a network reply or a form.\n\n"
                "The reading code is the only part that would change."),
            CHALLENGE,
            code('''#include <iostream>
#include <sstream>
#include <string>

bool valid_score(int score) {
    return score >= 0 && score <= 100;
}

int main() {
    std::istringstream file("100\\n101\\n0\\n");
    int line_value = 0;
    int good = 0;
    while (file >> line_value) {
        if (valid_score(line_value)) {
            ++good;
        }
    }
    std::cout << good << " valid scores\\n";
    return 0;
}
''', '''2 valid scores'''),
            quiz("Why is it useful to separate parsing from validation?",
                 ["It runs faster", "Each part can be tested on its own",
                  "It uses less memory", "The compiler requires it"],
                 1, "A pure validation function can be checked with hand-written values, "
                    "without any input stream."),
           ]),
]
