"""Level 15 — Multiple Files and Building."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("15001", 15, "Splitting a program", "Declarations and Definitions",
           "A declaration promises; a definition builds. One of each, usually.",
           ["Tell a declaration from a definition.",
            "Explain why a function can be declared many times but defined once.",
            "Write a header that only declares."],
           [exp("Two different statements\n\n"
                "A declaration says what something is: its name, its parameters, its "
                "return type. It promises that the definition exists somewhere.\n\n"
                "A definition provides the body or the storage. A function with { } after "
                "it is a definition; one that ends with a semicolon is a declaration.\n\n"
                "The rule that makes multi-file programs work is the one-definition rule: "
                "one definition in the whole program, but as many declarations as you "
                "like."),
            dfn("Declaration", "A statement of a name's type and signature, with no body, "
                               "ending in a semicolon."),
            dfn("One-definition rule", "Every function and variable has exactly one "
                                       "definition in the program; declarations may be "
                                       "repeated."),
            exp("Declared, then defined later\n\n"
                "The compiler needs only the declaration to check a call. That is why "
                "greet() can be declared at the top and defined at the bottom: main() "
                "compiles against the promise.\n\n"
                "The linker then matches the promise to the one definition. If no "
                "definition exists you get an undefined reference; if two do, a duplicate "
                "symbol."),
            code('''#include <iostream>

int add(int a, int b);

int main() {
    std::cout << add(2, 3) << "\\n";
    return 0;
}

int add(int a, int b) {
    return a + b;
}
''', '''5'''),
            exp("The same idea for a variable\n\n"
                "A declaration with extern says 'this variable exists somewhere else'. "
                "Without extern, and with an initialiser, it is a definition and it "
                "allocates storage.\n\n"
                "That single word is the difference between one shared counter and two "
                "private ones, which is the classic link error of a multi-file project."),
            code('''#include <iostream>

extern int shared_counter;
int shared_counter = 10;

void bump() {
    ++shared_counter;
}

int main() {
    bump();
    bump();
    std::cout << shared_counter << "\\n";
    return 0;
}
''', '''12'''),
            CHALLENGE,
            code('''#include <iostream>

int triple(int value);

int main() {
    std::cout << triple(4) << "\\n";
    std::cout << triple(0) << "\\n";
    return 0;
}

int triple(int value) {
    return value * 3;
}
''', '''12
0'''),
            quiz("How many definitions may a function have in a program?",
                 ["As many as you like", "Exactly one", "One per file", "Two: header and source"],
                 1, "The one-definition rule allows exactly one definition, with any "
                    "number of declarations."),
           ]),

    lesson("15002", 15, "Splitting a program", "The Header and the Source",
           "The header says what, the source says how.",
           ["Describe what belongs in a header and what belongs in a source file.",
            "Write a header, a source and a main that use each other.",
            "Explain the include guard."],
           [exp("One file per idea\n\n"
                "A header carries declarations: the functions a module offers, the types "
                "it defines, the constants it publishes. A source file carries the "
                "definitions and anything private to that module.\n\n"
                "main.cpp then includes the header and calls the functions. It never needs "
                "to know how they are written, which is what lets one part be rewritten "
                "without touching the others.\n\n"
                "The header is included in both the source and the caller, so the "
                "compiler sees the same promise in both places and can check they agree."),
            dfn("Header", "A .h or .hpp file containing declarations, included by any "
                          "file that needs them."),
            dfn("Include guard", "A pair of #ifndef/#define lines (or #pragma once) that "
                                 "stop a header's contents being read twice in one "
                                 "translation unit."),
            exp("What the three files look like\n\n"
                "The header declares twice(). The source includes the header and defines "
                "it. main includes the header and calls it.\n\n"
                "Each file is shown as text because they are built together rather than "
                "compiled alone. The include guard in the header is what allows it to be "
                "included by several files without a duplicate-definition error."),
            code('''// math.hpp
#ifndef MATH_HPP
#define MATH_HPP

int twice(int value);
double twice(double value);

#endif
''', '''header with an include guard''', language="text"),
            code('''// math.cpp
#include "math.hpp"

int twice(int value) {
    return value * 2;
}

double twice(double value) {
    return value * 2.0;
}
''', '''definition, compiled once''', language="text"),
            code('''// main.cpp
#include <iostream>
#include "math.hpp"

int main() {
    std::cout << twice(5) << "\\n";
    std::cout << twice(1.5) << "\\n";
    return 0;
}
''', '''5
3''', language="text"),
            exp("The guard explained\n\n"
                "The first time the header is read, MATH_HPP is not defined, so the "
                "contents are compiled and the macro is defined. The second time, in the "
                "same file, the contents are skipped.\n\n"
                "#pragma once does the same job in one line and is understood by every "
                "compiler you will meet. Use it; know the guard because you will read it "
                "in other people's code."),
            CHALLENGE,
            code('''#include <iostream>

namespace math {
int twice(int value) {
    return value * 2;
}
}

int main() {
    std::cout << math::twice(6) << "\\n";
    return 0;
}
''', '''12'''),
            quiz("Where does a function's body belong?",
                 ["In the header, so everyone can see it",
                  "In a source file, with the declaration in the header",
                  "In main.cpp only", "In the include guard"],
                 1, "The body goes in a source file so it is defined once, while the "
                    "header carries the declaration."),
           ]),

    lesson("15003", 15, "Splitting a program", "Names and Namespaces",
           "Give your code a surname so two teams can both write a read().",
           ["Create and use a namespace.",
            "Explain how a using-declaration narrows the risk.",
            "Avoid a using-directive in a header."],
           [exp("Why names collide\n\n"
                "Two libraries both offering init() is not a mistake, it is normal. Without "
                "namespaces the linker cannot tell them apart and the compiler refuses the "
                "call.\n\n"
                "A namespace groups names under a prefix. The fully qualified name outside::"
                "read is unambiguous, and the code inside a namespace can use the short "
                "name.\n\n"
                "The standard library keeps everything in std, which is why the prefix "
                "usually only appears inside headers of your own."),
            dfn("Namespace", "A named scope that groups declarations so that identical "
                             "short names can exist in different groups."),
            exp("Nested names and the short form\n\n"
                "Namespaces nest, so app::io::read is a name in a name in a name. Inside "
                "app::io, calling read refers to that one.\n\n"
                "A using-declaration names exactly one thing: using app::greet; brings "
                "only greet into scope. A using-directive, using namespace app;, brings "
                "everything and is the one to avoid at file scope."),
            code('''#include <iostream>

namespace app {
namespace io {
const char* read() {
    return "reading";
}
}
}

namespace other {
const char* read() {
    return "other reading";
}
}

int main() {
    using app::io::read;
    std::cout << read() << "\\n";
    std::cout << other::read() << "\\n";
    return 0;
}
''', '''reading
other reading'''),
            exp("Never a using-directive in a header\n\n"
                "using namespace std; inside a header leaks into every file that includes "
                "it, and the file's author never sees it. A name that resolves to a "
                "different function than expected is then almost impossible to find.\n\n"
                "Inside a .cpp file, at the top of a function, it is a convenience. In a "
                "header it is a bug waiting for a second team."),
            CHALLENGE,
            code('''#include <iostream>

namespace academy {
int lessons() {
    return 12;
}
}

int main() {
    std::cout << academy::lessons() << " lessons\\n";
    return 0;
}
''', '''12 lessons'''),
            quiz("Why avoid using namespace std; in a header?",
                 ["It slows compilation", "It leaks names into every file that includes "
                  "the header", "It is not valid C++", "It removes the std namespace"],
                 1, "Every includer inherits the names silently, which can change what "
                    "their own code resolves to."),
           ]),

    lesson("15004", 15, "Building", "Compiling and Linking",
           "Two steps: turn each file into an object, then join the objects.",
           ["Name the two stages of building a program.",
            "Read a compile error and a link error differently.",
            "Write the command that builds three files."],
           [exp("Two jobs, two kinds of error\n\n"
                "The compiler translates each .cpp file on its own into an object file. It "
                "knows about other files only through the declarations they published in "
                "headers.\n\n"
                "The linker then joins the object files, resolving every promise into a "
                "definition, and produces the executable.\n\n"
                "So a mistake inside one file is a compile error naming a line, while a "
                "promise with no definition is a link error naming a symbol. Reading that "
                "difference tells you where to look."),
            dfn("Object file", "The compiler's output for one source file, before linking. "
                               "It holds machine code and unresolved references."),
            dfn("Linker", "The program that joins object files and resolves references to "
                          "the one definition of each symbol."),
            exp("The command\n\n"
                "g++ takes every source file at once; it compiles each and links them in one "
                "go. -o names the executable and -Wall asks for warnings.\n\n"
                "Run this in the folder that holds the files. With llvm-mingw on Windows "
                "the compiler is clang++ and the executable is program.exe."),
            code('''g++ -std=c++17 -Wall math.cpp main.cpp -o program
''', '''compiles both files, links them, writes ./program''', language="text"),
            exp("The two errors, side by side\n\n"
                "A compile error names a file and a line inside it: the syntax is wrong. A "
                "link error names a symbol that no definition matched: the declaration "
                "exists but nobody wrote the body, or the .cpp was left out of the "
                "command.\n\n"
                "'undefined reference to add(int, int)' is almost always a missing source "
                "file in the command, not a missing function in the code."),
            code('''// a missing function is caught by the compiler
undefined reference to `add(int, int)'\\ncollect2: error: ld returned 1 exit status
''', '''the linker could not find a definition''', language="text"),
            CHALLENGE,
            code('''#include <iostream>

namespace part_a {
int value() { return 1; }
}
namespace part_b {
int value() { return 2; }
}

int main() {
    std::cout << part_a::value() + part_b::value() << "\\n";
    return 0;
}
''', '''3'''),
            quiz("Which error appears when a declared function has no definition?",
                 ["A compile error in the header", "A link error naming the symbol",
                  "A runtime crash", "A warning only"],
                 1, "The compiler is satisfied by the declaration; the linker is the stage "
                    "that needs a body."),
           ]),

    lesson("15005", 15, "Building", "Static, Inline and Header-Only",
           "Decide where a function lives, and keep the linker from seeing two copies.",
           ["Explain what static at file scope means.",
            "Mark a header function inline.",
            "Choose a header-only design deliberately."],
           [exp("Private to one file\n\n"
                "A function marked static at file scope is visible only inside its own "
                ".cpp file. That is how a helper is kept private without a namespace, and "
                "how two files may each have their own helper with the same name.\n\n"
                "C++17 prefers an anonymous namespace for the same purpose, which is the "
                "same idea written differently and works with more types.\n\n"
                "Without either, a helper with a common name in two files is a duplicate "
                "symbol at link time."),
            dfn("Internal linkage", "A name that exists only within its own translation "
                                    "unit, produced by static at file scope or by an "
                                    "anonymous namespace."),
            exp("A function defined in a header\n\n"
                "If a header contains a full definition and is included by three files, "
                "the linker sees three definitions. inline tells the compiler that "
                "several identical definitions are allowed and one may be kept.\n\n"
                "That is why small functions live in headers at all: the compiler can "
                "copy the body into each caller instead of making a call."),
            code('''#include <iostream>

namespace {
int helper(int value) {
    return value + 1;
}
}

inline int doubled(int value) {
    return value * 2;
}

int main() {
    std::cout << helper(4) << "\\n";
    std::cout << doubled(helper(4)) << "\\n";
    return 0;
}
''', '''5
10'''),
            exp("When header-only is right\n\n"
                "A header-only library is easy to drop into a project: include it and the "
                "definitions come with it. That convenience is why templates are "
                "header-only by necessity, since their bodies must be visible to "
                "compile.\n\n"
                "The cost is compile time: every file that includes it recompiles its "
                "contents. Small utilities are fine; a large library is not."),
            CHALLENGE,
            code('''#include <iostream>

namespace {
const char* internal_name() {
    return "private";
}
}

int main() {
    std::cout << internal_name() << "\\n";
    return 0;
}
''', '''private'''),
            quiz("Why must a template's body be visible where it is used?",
                 ["Because the linker deletes it",
                  "Because the compiler generates code only for the types it sees",
                  "Because templates cannot be linked",
                  "Because inline requires it"],
                 1, "Instantiation happens at the point of use, so the body must be in the "
                    "header."),
           ]),

    lesson("15006", 15, "Building", "A Build Script",
           "Write the commands down so the build is one step, not five.",
           ["Run a build with one command.",
            "Explain what a build script removes.",
            "Describe when a compiler flag belongs in the script."],
           [exp("The commands are part of the program\n\n"
                "Two files, three flags and an output name is a command nobody remembers "
                "correctly. Written in a script, the build becomes one step that is the "
                "same on every machine.\n\n"
                "The script also becomes documentation: a new person can read it and see "
                "which files exist and which flags matter.\n\n"
                "For a project of a few files a shell script or a .bat file is enough. "
                "Make a CMake file when the project needs to build on three systems with "
                "two compilers."),
            dfn("Build script", "A file containing the compiler commands for a project, so "
                                "the build is repeatable and needs no memory."),
            exp("The script, and what each flag buys\n\n"
                "-std=c++17 pins the language version, -Wall and -Wextra turn on the "
                "warnings that catch real mistakes, -g keeps debug information, and -O2 "
                "optimises for a release build.\n\n"
                "Compile with warnings on and optimisation off while developing: an "
                "optimiser can hide the statement that caused a problem."),
            code('''/usr/bin/env bash
build() {
    g++ -std=c++17 -Wall -Wextra -g math.cpp main.cpp -o program
}
build
''', '''one command builds every file''', language="text"),
            exp("A Windows equivalent\n\n"
                "The same file with a .bat extension, calling clang++ from the bundled "
                "llvm-mingw toolchain. The flags are the same; only the shell differs."),
            code('''clang++ -std=c++17 -Wall -Wextra math.cpp main.cpp -o program.exe
''', '''builds program.exe with the bundled compiler''', language="text"),
            CHALLENGE,
            code('''#include <iostream>

int main() {
    int value = 7;
    std::cout << (value > 5 ? "large" : "small") << "\\n";
    return 0;
}
''', '''large'''),
            quiz("Why develop with optimisation off?",
                 ["The program runs slower, which is safer",
                  "The optimiser can move or remove code and hide the real fault",
                  "Optimisation is only for release builds by law",
                  "It changes the language"],
                 1, "Optimised code no longer maps line by line to the source, which makes "
                    "both debugging and sanitizer reports harder to read."),
           ]),

    lesson("15007", 15, "Building", "CMake in One Page",
           "One file describes the project; every generator does the rest.",
           ["Read a minimal CMakeLists.txt.",
            "Explain what add_executable declares.",
            "Name the two commands that build the project."],
           [exp("Describe, then generate\n\n"
                "CMake does not compile anything itself. It reads CMakeLists.txt and "
                "writes the build files for whatever toolchain you have: Make on Linux, "
                "Visual Studio or Ninja on Windows.\n\n"
                "The description is short: what the project is called, which sources "
                "belong to the executable, and which standard to compile against. One "
                "file serves every platform.\n\n"
                "That portability is the whole reason CMake exists, and it is why the "
                "app itself can compile CMake projects."),
            dfn("CMakeLists.txt", "The project description CMake reads: the project name, "
                                  "its sources and its requirements."),
            exp("The file\n\n"
                "cmake_minimum_required sets the CMake version, project names the "
                "project, and add_executable says which sources become the program.\n\n"
                "CMAKE_CXX_STANDARD 17 asks for the language version, and "
                "CMAKE_CXX_STANDARD_REQUIRED stops the generator quietly choosing "
                "something older."),
            code('''cmake_minimum_required(VERSION 3.16)
project(academy CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)

add_executable(program math.cpp main.cpp)
''', '''the project described in seven lines''', language="text"),
            exp("The two commands\n\n"
                "The first creates a build folder and generates the build files there, "
                "keeping the sources clean. The second runs the build.\n\n"
                "Building outside the source folder means a mistake never leaves "
                "generated files among your code, and deleting the build folder resets "
                "everything."),
            code('''cmake -S . -B build
cmake --build build
''', '''generates, then builds''', language="text"),
            CHALLENGE,
            code('''#include <iostream>

int main() {
    std::cout << "cmake builds this in any folder\\n";
    return 0;
}
''', '''cmake builds this in any folder'''),
            quiz("What does CMake itself produce?",
                 ["The executable", "Build files for another toolchain",
                  "The object files", "The source code"],
                 1, "It generates the build system; the compiler invoked by that build "
                    "system produces the binary."),
           ]),

    lesson("15008", 15, "Building", "A Project You Can Grow",
           "The layout that scales from three files to thirty without a rewrite.",
           ["Lay out a project so growing it needs no decisions.",
            "Keep headers, sources and tests apart.",
            "Explain why main.cpp should stay thin."],
           [exp("The layout\n\n"
                "A small project that will grow keeps its headers in include, its sources "
                "in src, and its tests in tests. Every file then has one obvious "
                "home, and the compiler command is easy to write.\n\n"
                "main.cpp contains the smallest possible amount of code: read the input, "
                "call the library, print the result. Everything worth testing lives "
                "outside it.\n\n"
                "That last rule is the one people break first and regret: logic in main "
                "cannot be called from a test."),
            dfn("Translation unit", "One source file after its headers have been included: "
                                    "the input to the compiler for one object file."),
            exp("A thin main\n\n"
                "main reads, calls and reports. The arithmetic is in a function that takes "
                "values and returns a value, so a test can call it with numbers and no "
                "input stream.\n\n"
                "This is the same separation you met in Level 13 and Level 14, arriving "
                "from the structure side: what main does not contain is what can be "
                "tested."),
            code('''#include <iostream>

double percent(int part, int whole) {
    if (whole == 0) {
        return 0.0;
    }
    return 100.0 * static_cast<double>(part) / static_cast<double>(whole);
}

int main() {
    std::cout << percent(3, 4) << "\\n";
    return 0;
}
''', '''75'''),
            exp("The test that lives beside it\n\n"
                "tests/test_percent.cpp compiles against the same function and calls it "
                "directly. Growing the project never means rewriting the test, because "
                "the test never depended on main.\n\n"
                "Three files, one idea, and the shape is exactly what a hundred-file "
                "project uses."),
            CHALLENGE,
            code('''#include <iostream>

bool in_range(int value, int low, int high) {
    return value >= low && value <= high;
}

int main() {
    int passed = 0;
    int total = 0;
    for (int value : {-1, 0, 5, 10, 11}) {
        ++total;
        if (in_range(value, 0, 10)) {
            ++passed;
        }
    }
    std::cout << passed << " of " << total << " in range\\n";
    return 0;
}
''', '''3 of 5 in range'''),
            quiz("Why keep logic out of main()?",
                 ["main cannot call functions",
                  "Logic in main cannot be called by a test",
                  "main is slower", "The linker forbids it"],
                 1, "Everything in main is unreachable from tests, so the code that most "
                    "needs checking ends up the only code that cannot be checked."),
           ]),
]
