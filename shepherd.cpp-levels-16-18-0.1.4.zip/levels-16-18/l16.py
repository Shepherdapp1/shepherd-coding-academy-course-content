"""Level 16 — Data Structures and Algorithms."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("16001", 16, "Cost", "Measuring Cost by Counting",
           "Count the steps, not the seconds, and the comparison is the same on every machine.",
           ["Count the operations an algorithm performs.",
            "Compare linear and binary search by step count.",
            "Explain why counting beats timing."],
           [exp("Why not just time it\n\n"
                "A stopwatch measures your machine, its load and its compiler as much as "
                "the algorithm. Run the same program twice and you get two answers, "
                "neither of which says anything about the next computer.\n\n"
                "Counting is different. A linear search over 1024 items always performs "
                "1024 comparisons in the worst case, on any machine, in any year. The "
                "count is a property of the algorithm.\n\n"
                "That is what big-O notation describes: how the work grows as the input "
                "grows, with the constants and the hardware left out."),
            dfn("Big-O", "A description of how the number of operations grows with the "
                         "input size: O(n) grows in step with the input, O(log n) barely "
                         "grows at all."),
            exp("Two searches, counted\n\n"
                "The linear search walks from the start and counts each comparison. The "
                "binary search halves the range and counts far fewer. Both find the same "
                "value at index 999.\n\n"
                "The step counts are printed, so the difference is a number rather than an "
                "opinion: 1000 against 10 for the same answer."),
            code('''#include <iostream>
#include <vector>

int linear(const std::vector<int>& data, int wanted, int& steps) {
    steps = 0;
    for (std::size_t i = 0; i < data.size(); ++i) {
        ++steps;
        if (data[i] == wanted) {
            return static_cast<int>(i);
        }
    }
    return -1;
}

int main() {
    std::vector<int> data(1000);
    for (int i = 0; i < 1000; ++i) {
        data[static_cast<std::size_t>(i)] = i;
    }
    int steps = 0;
    int found = linear(data, 999, steps);
    std::cout << "found at " << found << " in " << steps << " steps\\n";
    return 0;
}
''', '''found at 999 in 1000 steps'''),
            exp("The same answer, ten steps\n\n"
                "Binary search relies on the data being sorted: it looks at the middle, "
                "discards half, and repeats. Ten halvings cover a thousand items, and "
                "twenty cover a million.\n\n"
                "That is the whole argument for keeping data sorted: an O(log n) search "
                "turns a thousand comparisons into ten."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

int binary(const std::vector<int>& data, int wanted, int& steps) {
    int low = 0;
    int high = static_cast<int>(data.size()) - 1;
    steps = 0;
    while (low <= high) {
        ++steps;
        int middle = low + (high - low) / 2;
        if (data[static_cast<std::size_t>(middle)] == wanted) {
            return middle;
        }
        if (data[static_cast<std::size_t>(middle)] < wanted) {
            low = middle + 1;
        } else {
            high = middle - 1;
        }
    }
    return -1;
}

int main() {
    std::vector<int> data(1000);
    for (int i = 0; i < 1000; ++i) {
        data[static_cast<std::size_t>(i)] = i;
    }
    int steps = 0;
    int found = binary(data, 999, steps);
    std::cout << "found at " << found << " in " << steps << " steps\\n";
    return 0;
}
''', '''found at 999 in 10 steps'''),
            quiz("Why is counting operations better than timing a run?",
                 ["It is faster to do", "The count depends only on the algorithm and the "
                  "input size, not the machine", "Timers are always wrong",
                  "The compiler removes the timer"],
                 1, "A count is reproducible everywhere; a time is a property of one "
                    "machine on one day."),
           ]),

    lesson("16002", 16, "Structures", "A Linked List",
           "Nodes that point at each other: cheap to insert, slow to reach.",
           ["Build a list of nodes with unique_ptr.",
            "Walk a list to print it.",
            "Explain why reaching the nth item is linear."],
           [exp("Pointers instead of neighbours\n\n"
                "A vector keeps its elements side by side, so the tenth element is just "
                "an offset away. A linked list keeps each value in its own node with a "
                "pointer to the next, so the nodes can sit anywhere in memory.\n\n"
                "That freedom is what makes insertion cheap: adding a node changes one "
                "pointer. It is also what makes access expensive: reaching the tenth "
                "element means following ten pointers.\n\n"
                "Each node is a small object holding a value and a pointer to the next. "
                "unique_ptr makes the ownership obvious: the list owns its nodes."),
            dfn("Node", "One element of a linked structure: a value plus the link to the "
                        "next node."),
            exp("Walking the chain\n\n"
                "The loop follows next until it is empty, and each visit prints one value. "
                "No index is involved, which is exactly why there is no fast access to the "
                "middle.\n\n"
                "Because the nodes are owned by unique_ptr, the whole list is freed "
                "automatically when the head goes out of scope: no manual delete and no "
                "leak on an early return."),
            code('''#include <iostream>
#include <memory>

struct Node {
    int value = 0;
    std::unique_ptr<Node> next;
};

void print(const Node* node) {
    while (node != nullptr) {
        std::cout << node->value << " ";
        node = node->next.get();
    }
    std::cout << "\\n";
}

int main() {
    auto third = std::make_unique<Node>();
    third->value = 3;
    auto second = std::make_unique<Node>();
    second->value = 2;
    second->next = std::move(third);
    auto head = std::make_unique<Node>();
    head->value = 1;
    head->next = std::move(second);
    print(head.get());
    return 0;
}
''', '''1 2 3 '''),
            exp("Counting the work\n\n"
                "Finding the length is a walk, so it costs one step per node. Reaching the "
                "last element is the same walk. This is why a linked list is the wrong "
                "structure for anything that needs random access.\n\n"
                "In exchange, inserting at the front is one pointer assignment no matter "
                "how long the list is, which a vector cannot do without moving every "
                "element."),
            CHALLENGE,
            code('''#include <iostream>
#include <memory>

struct Node {
    int value = 0;
    std::unique_ptr<Node> next;
};

int length(const Node* node) {
    int count = 0;
    while (node != nullptr) {
        ++count;
        node = node->next.get();
    }
    return count;
}

int main() {
    auto second = std::make_unique<Node>();
    second->value = 20;
    auto head = std::make_unique<Node>();
    head->value = 10;
    head->next = std::move(second);
    std::cout << "length " << length(head.get()) << "\\n";
    std::cout << "front " << head->value << "\\n";
    return 0;
}
''', '''length 2
front 10'''),
            quiz("What does reaching the last element of a linked list cost?",
                 ["One step", "A number of steps proportional to the list length",
                  "Nothing, it is stored", "A sort"],
                 1, "There is no index arithmetic: you must follow every link, which is "
                    "what O(n) means."),
           ]),

    lesson("16003", 16, "Structures", "Stacks and Queues",
           "Last in, first out; or first in, first out.",
           ["Use std::stack for last-in, first-out.",
            "Use std::queue for first-in, first-out.",
            "Name a problem each one solves."],
           [exp("Two orders, one interface\n\n"
                "A stack adds and removes at the same end: last in, first out. A queue "
                "adds at one end and removes at the other: first in, first out.\n\n"
                "The standard adaptors, std::stack and std::queue, provide only push, pop "
                "and top or front. That narrow interface is the point: no indexing, no "
                "inserting in the middle.\n\n"
                "Stacks model undo, back buttons, and expression evaluation. Queues model "
                "print jobs, request handling, and breadth-first search."),
            dfn("Stack", "A container where the last value added is the first one "
                         "removed."),
            dfn("Queue", "A container where the first value added is the first one "
                         "removed."),
            exp("Reversing with a stack\n\n"
                "Pushing the digits of a number and popping them reverses the order, which "
                "is the smallest useful stack program. The stack itself is "
                "std::stack<int> over a deque.\n\n"
                "Notice pop returns nothing: you read top first, then pop. That separates "
                "looking from removing and prevents the classic 'pop and lose the value' "
                "mistake."),
            code('''#include <iostream>
#include <stack>

int main() {
    std::stack<int> digits;
    for (int value : {1, 2, 3}) {
        digits.push(value);
    }
    while (!digits.empty()) {
        std::cout << digits.top() << " ";
        digits.pop();
    }
    std::cout << "\\n";
    return 0;
}
''', '''3 2 1 '''),
            exp("A queue keeps arrival order\n\n"
                "The same three values pushed into a queue come out in the order they "
                "arrived, which is what a fair scheduler or a print spooler needs.\n\n"
                "The two containers differ only in which end is read, and that difference "
                "decides which problem each solves."),
            CHALLENGE,
            code('''#include <iostream>
#include <queue>

int main() {
    std::queue<int> line;
    for (int value : {1, 2, 3}) {
        line.push(value);
    }
    while (!line.empty()) {
        std::cout << line.front() << " ";
        line.pop();
    }
    std::cout << "\\n";
    std::cout << "size now " << line.size() << "\\n";
    return 0;
}
''', '''1 2 3 
size now 0'''),
            quiz("Which container removes the most recently added value first?",
                 ["A queue", "A stack", "A vector", "A set"],
                 1, "A stack is last-in, first-out; a queue is first-in, first-out."),
           ]),

    lesson("16004", 16, "Searching", "Binary Search by Hand",
           "Halve, compare, repeat — and get the boundaries right.",
           ["Write a binary search that returns -1 when absent.",
            "Explain the low and high boundary rule.",
            "Use std::binary_search when the answer is only yes or no."],
           [exp("The sorted requirement\n\n"
                "Binary search only works on sorted data, because discarding half is only "
                "valid if everything on one side is smaller. Given that, it finds a value "
                "in about log2(n) comparisons.\n\n"
                "The algorithm keeps a range of possible answers, [low, high], inclusive. "
                "Each step compares the middle, then moves one boundary past it.\n\n"
                "Almost every bug in a hand-written binary search is a boundary: middle + "
                "1 instead of middle, or low < high instead of low <= high."),
            dfn("Inclusive range", "Both ends are candidates. Writing low <= high in the "
                                   "loop is what makes the last remaining element get "
                                   "tested."),
            exp("Absent values terminate correctly\n\n"
                "When the value is absent, low eventually passes high and the loop stops. "
                "That terminating condition is the thing to test, not the successful "
                "search: the found case almost always works.\n\n"
                "middle is computed as low + (high - low) / 2 rather than (low + high) / 2 "
                "so that two large indices cannot overflow."),
            code('''#include <iostream>
#include <vector>

int binary(const std::vector<int>& data, int wanted) {
    int low = 0;
    int high = static_cast<int>(data.size()) - 1;
    while (low <= high) {
        int middle = low + (high - low) / 2;
        int value = data[static_cast<std::size_t>(middle)];
        if (value == wanted) {
            return middle;
        }
        if (value < wanted) {
            low = middle + 1;
        } else {
            high = middle - 1;
        }
    }
    return -1;
}

int main() {
    std::vector<int> data{2, 4, 6, 8, 10};
    std::cout << binary(data, 8) << "\\n";
    std::cout << binary(data, 5) << "\\n";
    std::cout << binary(data, 2) << "\\n";
    std::cout << binary(data, 10) << "\\n";
    return 0;
}
''', '''3
-1
0
4'''),
            exp("When you only need a yes or no\n\n"
                "std::binary_search returns a bool: it answers 'is it there?' without "
                "telling you where. It is the right call when that is all you need.\n\n"
                "When you need the position, std::lower_bound gives the first element not "
                "less than the value, which is the standard way to find an insertion "
                "point."),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> data{2, 4, 6, 8, 10};
    std::cout << (std::binary_search(data.begin(), data.end(), 6) ? "found" : "absent")
              << "\\n";
    std::cout << (std::binary_search(data.begin(), data.end(), 7) ? "found" : "absent")
              << "\\n";
    auto position = std::lower_bound(data.begin(), data.end(), 7);
    std::cout << "insert 7 at " << (position - data.begin()) << "\\n";
    return 0;
}
''', '''found
absent
insert 7 at 3'''),
            quiz("What must be true before binary search can be used?",
                 ["The data must be sorted", "The data must be unique",
                  "The data must be numbers", "The data must fit on one cache line"],
                 0, "Discarding half is only valid when the order tells you which half "
                    "cannot contain the value."),
           ]),

    lesson("16005", 16, "Sorting", "Writing a Sort by Hand",
           "Insertion sort in ten lines, and the reason the library's sort exists.",
           ["Write insertion sort and count its comparisons.",
            "Explain why it is fast on nearly sorted data.",
            "Compare it with std::sort by measurement."],
           [exp("Sorting the way you sort cards\n\n"
                "Insertion sort takes each element and walks it left past everything "
                "larger, then drops it in place. Hand-sorting a few cards works exactly "
                "this way.\n\n"
                "On small or nearly sorted data it is genuinely good: when the array is "
                "already ordered, each element is compared once and no shifts happen, so "
                "it is linear.\n\n"
                "On a reversed array of a thousand elements it performs about half a "
                "million shifts. That quadratic behaviour is why it is not used for "
                "general sorting."),
            dfn("Quadratic", "Work proportional to n squared: doubling the input makes the "
                             "work four times larger. Bubble, selection and insertion sort "
                             "are all quadratic in the worst case."),
            exp("Counting the shifts\n\n"
                "The counter makes the cost visible. On five reversed values there are ten "
                "shifts, which is exactly n(n-1)/2 - the shape of quadratic growth in one "
                "number.\n\n"
                "Comparing a count from two algorithms on the same input is the "
                "measurement habit from Level 13, applied to a choice of algorithm."),
            code('''#include <iostream>
#include <vector>

void insertion_sort(std::vector<int>& data, int& shifts) {
    shifts = 0;
    for (std::size_t i = 1; i < data.size(); ++i) {
        int key = data[i];
        std::size_t position = i;
        while (position > 0 && data[position - 1] > key) {
            data[position] = data[position - 1];
            --position;
            ++shifts;
        }
        data[position] = key;
    }
}

int main() {
    std::vector<int> data{5, 4, 3, 2, 1};
    int shifts = 0;
    insertion_sort(data, shifts);
    for (int value : data) {
        std::cout << value << " ";
    }
    std::cout << "\\nshifts " << shifts << "\\n";
    return 0;
}
''', '''1 2 3 4 5 
shifts 10'''),
            exp("Already sorted costs nothing\n\n"
                "The same function on sorted data performs zero shifts, because no element "
                "is ever out of order. That is the property that makes insertion sort the "
                "usual finishing step inside a larger sort.\n\n"
                "std::sort is an introsort: quicksort, switching to heapsort when it "
                "recurses too deeply, and to insertion sort for small pieces. Use it, and "
                "know this much about why it is fast."),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{9, 1, 5, 3};
    std::sort(values.begin(), values.end());
    std::cout << (std::is_sorted(values.begin(), values.end()) ? "sorted" : "not sorted")
              << "\\n";
    for (int value : values) {
        std::cout << value << " ";
    }
    std::cout << "\\n";
    return 0;
}
''', '''sorted
1 3 5 9 '''),
            quiz("Why is insertion sort fast on nearly sorted data?",
                 ["It skips elements", "Each element usually needs no shifting",
                  "It sorts in parallel", "It uses a hash table"],
                 1, "Nearly sorted input means the inner loop runs almost never, so the "
                    "work is close to linear."),
           ]),

    lesson("16006", 16, "Structures", "How a Hash Table Finds in One Step",
           "Turn a key into a bucket with a hash, then look in that one place.",
           ["Explain what a hash function does.",
            "Place keys in buckets and read them back.",
            "Describe why collisions must be handled."],
           [exp("A number instead of a search\n\n"
                "A hash function turns a key into a number, and the table uses that number "
                "as an index. Finding a value then means computing the index and looking "
                "there, which takes the same time whether the table holds ten keys or ten "
                "thousand.\n\n"
                "Two keys can produce the same index. That is a collision, and it is "
                "normal. The table handles it by keeping a small list per bucket and "
                "comparing the keys inside it.\n\n"
                "The hash must be stable: the same key always gives the same number, or "
                "the value can never be found again."),
            dfn("Hash function", "A function that turns a key into a number, which is then "
                                 "reduced to a bucket index."),
            dfn("Collision", "Two different keys producing the same bucket index."),
            exp("A hash you can see\n\n"
                "The standard library already provides std::hash for text and numbers, so "
                "you never write one for ordinary keys. Applying it and taking the "
                "remainder places each word in a bucket.\n\n"
                "The exact bucket number depends on the standard library, which is why the "
                "program below prints facts rather than the number: it is inside the "
                "table, and it is the same on every call."),
            code('''#include <functional>
#include <iostream>
#include <string>

int bucket_for(const std::string& key, int buckets) {
    std::size_t hashed = std::hash<std::string>{}(key);
    return static_cast<int>(hashed % static_cast<std::size_t>(buckets));
}

int main() {
    int bucket = bucket_for("ada", 8);
    std::cout << (bucket >= 0 && bucket < 8 ? "inside the table" : "outside") << "\\n";
    std::cout << (bucket_for("ada", 8) == bucket_for("ada", 8) ? "stable" : "unstable")
              << "\\n";
    return 0;
}
''', '''inside the table
stable'''),
            exp("The library table\n\n"
                "unordered_map does all of this for you: hash, bucket, collision "
                "handling, resizing. It finds a key in roughly constant time, and in "
                "exchange the keys are not kept in any order.\n\n"
                "Use map when you need sorted keys, unordered_map when you only need fast "
                "lookup. That single difference decides the choice."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <unordered_map>

int main() {
    std::unordered_map<std::string, int> stock{{"pen", 3}, {"ink", 7}};
    auto it = stock.find("ink");
    if (it != stock.end()) {
        std::cout << it->first << " in stock: " << it->second << "\\n";
    }
    std::cout << "buckets " << (stock.bucket_count() >= 2 ? "allocated" : "missing")
              << "\\n";
    return 0;
}
''', '''ink in stock: 7
buckets allocated'''),
            quiz("What is a collision in a hash table?",
                 ["A key that cannot be hashed", "Two keys sharing a bucket index",
                  "A table that is full", "A key inserted twice"],
                 1, "Different keys can hash to the same bucket; the table stores both and "
                    "compares keys to tell them apart."),
           ]),

    lesson("16007", 16, "Structures", "A Binary Tree and Traversal",
           "Insert by comparison, then read it back in order.",
           ["Build a binary search tree with unique_ptr.",
            "Walk it in order to read the keys sorted.",
            "Explain why in-order traversal is sorted."],
           [exp("Order kept by structure\n\n"
                "In a binary search tree every node holds a key, everything in its left "
                "subtree is smaller and everything in its right subtree is larger. "
                "Insertion follows those rules automatically, so no sorting step is "
                "needed.\n\n"
                "Reading the tree in order - left subtree, node, right subtree - therefore "
                "produces the keys in sorted order.\n\n"
                "The cost depends on the shape. A balanced tree of a million keys is about "
                "twenty levels deep; a badly unbalanced one is a linked list."),
            dfn("In-order traversal", "Visiting left subtree, then the node, then the "
                                      "right subtree, which reads a search tree's keys in "
                                      "sorted order."),
            exp("Insert and read\n\n"
                "Each insert compares and moves left or right until it finds an empty "
                "place. The traversal then prints the keys in ascending order, so the "
                "sorting happened as a side effect of the structure.\n\n"
                "Ten nodes inserted in scrambled order still come out as 1 2 3 4 5."),
            code('''#include <iostream>
#include <memory>

struct Node {
    int key = 0;
    std::unique_ptr<Node> left;
    std::unique_ptr<Node> right;
};

void insert(std::unique_ptr<Node>& node, int key) {
    if (!node) {
        node = std::make_unique<Node>();
        node->key = key;
        return;
    }
    if (key < node->key) {
        insert(node->left, key);
    } else if (key > node->key) {
        insert(node->right, key);
    }
}

void in_order(const Node* node) {
    if (!node) {
        return;
    }
    in_order(node->left.get());
    std::cout << node->key << " ";
    in_order(node->right.get());
}

int main() {
    std::unique_ptr<Node> root;
    for (int key : {4, 2, 5, 1, 3}) {
        insert(root, key);
    }
    in_order(root.get());
    std::cout << "\\n";
    return 0;
}
''', '''1 2 3 4 5 '''),
            exp("What the structure costs\n\n"
                "Searching compares once per level, so a balanced tree is O(log n). "
                "Inserting in sorted order builds a chain and destroys that advantage, "
                "which is why balanced trees such as the red-black tree behind std::map "
                "exist.\n\n"
                "Writing the tree yourself once is how the concept becomes concrete; use "
                "std::map or std::set in real code."),
            CHALLENGE,
            code('''#include <iostream>
#include <memory>

struct Node {
    int key = 0;
    std::unique_ptr<Node> left;
    std::unique_ptr<Node> right;
};

void insert(std::unique_ptr<Node>& node, int key) {
    if (!node) {
        node = std::make_unique<Node>();
        node->key = key;
        return;
    }
    if (key < node->key) {
        insert(node->left, key);
    } else if (key > node->key) {
        insert(node->right, key);
    }
}

int height(const Node* node) {
    if (!node) {
        return 0;
    }
    int left = height(node->left.get());
    int right = height(node->right.get());
    return 1 + (left > right ? left : right);
}

int main() {
    std::unique_ptr<Node> root;
    for (int key : {2, 1, 3}) {
        insert(root, key);
    }
    std::cout << "height " << height(root.get()) << "\\n";
    return 0;
}
''', '''height 2'''),
            quiz("Why does an in-order traversal of a search tree come out sorted?",
                 ["Because the algorithm sorts while printing",
                  "Because every left subtree holds smaller keys and every right subtree "
                  "larger ones",
                  "Because the keys are unique",
                  "Because the tree is balanced"],
                 1, "The ordering is a structural property, so reading left-node-right "
                    "visits keys from smallest to largest."),
           ]),

    lesson("16008", 16, "Structures", "Choosing a Structure",
           "Pick from the operations you perform, not from the name you like.",
           ["Choose a container from the operations required.",
            "Read the cost table for the standard containers.",
            "Explain why vector is the default choice."],
           [exp("Three questions\n\n"
                "What do I do most: read in order, look up by key, or add and remove at "
                "the ends? How big will it get? Must the order be stable?\n\n"
                "vector is the default because memory is contiguous, which makes iteration "
                "the fastest thing a processor can do. deque is the right answer when both "
                "ends are used. set and map when lookup by key dominates. unordered_* when "
                "keys need speed and order does not matter.\n\n"
                "Choosing from these questions is the whole skill; the table just records "
                "the answers."),
            dfn("Amortised", "An average cost over many operations. push_back on a vector "
                             "is amortised constant: an occasional expensive reallocation "
                             "is paid for by the many cheap appends."),
            exp("The costs worth remembering\n\n"
                "vector: index O(1), append amortised O(1), insert in the middle O(n). "
                "set and map: lookup O(log n), always ordered. unordered: lookup about "
                "O(1), no order. list: insert anywhere O(1) once you have the position, "
                "but no indexing.\n\n"
                "The code below is a decision recorded in a program: a case-insensitive "
                "word count uses unordered_map because order is not needed."),
            code('''#include <cctype>
#include <iostream>
#include <string>
#include <unordered_map>

std::string lower(std::string text) {
    for (char& letter : text) {
        letter = static_cast<char>(std::tolower(static_cast<unsigned char>(letter)));
    }
    return text;
}

int main() {
    std::unordered_map<std::string, int> words;
    for (const char* word : {"Ada", "ada", "Bo"}) {
        ++words[lower(word)];
    }
    std::cout << words["ada"] << "\\n";
    std::cout << words.size() << " distinct words\\n";
    return 0;
}
''', '''2
2 distinct words'''),
            exp("When order matters instead\n\n"
                "A report read by a human needs sorted output, so map replaces "
                "unordered_map. The loop then prints keys in alphabetical order without a "
                "separate sort.\n\n"
                "That is the trade in one program: unordered for speed, map for order, and "
                "the choice made once at the declaration."),
            CHALLENGE,
            code('''#include <iostream>
#include <map>
#include <string>
#include <vector>

int main() {
    std::map<std::string, int> ordered{{"pear", 2}, {"apple", 5}, {"fig", 1}};
    for (const auto& entry : ordered) {
        std::cout << entry.first << "=" << entry.second << " ";
    }
    std::cout << "\\n";
    std::vector<int> values{3, 1, 2};
    values.push_back(4);
    std::cout << values.front() << " " << values.back() << " " << values.size() << "\\n";
    return 0;
}
''', '''apple=5 fig=1 pear=2 
3 4 4'''),
            quiz("Why is vector the usual default container?",
                 ["It sorts itself", "Its memory is contiguous, so iteration is fast",
                  "It allows duplicate keys", "It is the only one that can grow"],
                 1, "Contiguous memory makes sequential access cache-friendly, which "
                    "usually outweighs the cost of occasional reallocation."),
           ]),
]
