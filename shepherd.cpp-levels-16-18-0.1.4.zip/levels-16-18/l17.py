"""Level 17 — Concurrency."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("17001", 17, "Threads", "Two Things at Once",
           "A thread runs its own function; join before you touch its result.",
           ["Start a thread with std::thread.",
            "Explain what join does.",
            "Say why a thread must be joined or detached."],
           [exp("A second flow of control\n\n"
                "A thread runs a function independently of the one that started it. Both "
                "run at the same time, which the operating system schedules and the "
                "program does not control.\n\n"
                "Because of that freedom, a thread's result may not be visible yet. join() "
                "waits for the thread to finish, which is the barrier that makes the "
                "result safe to read.\n\n"
                "A std::thread must be joined or detached before it is destroyed. "
                "Otherwise the program terminates: the library refuses to guess whether "
                "you still needed it."),
            dfn("Thread", "An independent flow of execution inside one process, running a "
                          "function that may overlap in time with the main one."),
            dfn("join", "Wait for a thread to finish before continuing. After join "
                        "returns, everything the thread did is visible."),
            exp("One worker, one result\n\n"
                "The lambda writes into a local int. main joins before reading it, so the "
                "read is guaranteed to happen after the write.\n\n"
                "Remove the join and the program is undefined: main may print before the "
                "thread has run, or the runtime may abort."),
            code('''#include <iostream>
#include <thread>

int main() {
    int result = 0;
    std::thread worker([&result] {
        result = 21 * 2;
    });
    worker.join();
    std::cout << result << "\\n";
    return 0;
}
''', '''42'''),
            exp("Two workers, both joined\n\n"
                "Each thread owns a different variable, so no coordination is needed "
                "beyond waiting at the end. The two results are printed after both joins, "
                "so the output is the same on every run regardless of scheduling.\n\n"
                "That last point is a design habit worth adopting: keep output in one "
                "place, after the joins, and concurrency does not make your program's "
                "output unpredictable."),
            CHALLENGE,
            code('''#include <iostream>
#include <thread>

int main() {
    int first = 0;
    int second = 0;
    std::thread a([&first] { first = 10; });
    std::thread b([&second] { second = 32; });
    a.join();
    b.join();
    std::cout << first + second << "\\n";
    return 0;
}
''', '''42'''),
            quiz("What must happen to a std::thread before it is destroyed?",
                 ["Nothing", "It must be joined or detached",
                  "It must be locked", "It must be copied"],
                 1, "The destructor terminates the program if the thread is still "
                    "joinable, because the library cannot know whether you still need it."),
           ]),

    lesson("17002", 17, "Sharing data", "Data Races",
           "Two threads writing the same variable is undefined behaviour, not a slow path.",
           ["Explain what a data race is.",
            "Protect a shared counter with std::mutex.",
            "Say why a race gives different answers on different runs."],
           [exp("The increment is not one step\n\n"
                "count++ looks like one operation but is three: read the value, add one, "
                "write it back. If two threads interleave between those steps, one "
                "increment is lost.\n\n"
                "A data race is two threads touching the same memory with at least one "
                "writing, without synchronisation. In C++ it is undefined behaviour, so "
                "the result is not merely a lost increment: it can be anything, including "
                "a silently wrong total.\n\n"
                "This is why a racy program sometimes looks correct. It is never correct; "
                "it just has not been observed yet."),
            dfn("Data race", "Two threads accessing the same memory, at least one of them "
                             "writing, with no synchronisation between them."),
            exp("One owner of the lock at a time\n\n"
                "std::mutex gives exclusive access: a thread locks it, does the work, and "
                "unlocks. std::lock_guard does both automatically, so the unlock happens "
                "even if an exception is thrown.\n\n"
                "With the guard, two threads each increment a thousand times and the "
                "answer is exactly two thousand, every run."),
            code('''#include <iostream>
#include <mutex>
#include <thread>

int main() {
    int counter = 0;
    std::mutex gate;
    auto work = [&counter, &gate] {
        for (int i = 0; i < 1000; ++i) {
            std::lock_guard<std::mutex> guard(gate);
            ++counter;
        }
    };
    std::thread a(work);
    std::thread b(work);
    a.join();
    b.join();
    std::cout << counter << "\\n";
    return 0;
}
''', '''2000'''),
            exp("The atomic alternative\n\n"
                "For a single counter, std::atomic<int> does the whole job without a "
                "mutex: the increment becomes one indivisible operation.\n\n"
                "Atomic is faster and simpler for one variable. A mutex is for keeping "
                "several values consistent with each other, which atomics cannot do."),
            CHALLENGE,
            code('''#include <atomic>
#include <iostream>
#include <thread>

int main() {
    std::atomic<int> counter{0};
    auto work = [&counter] {
        for (int i = 0; i < 1000; ++i) {
            ++counter;
        }
    };
    std::thread a(work);
    std::thread b(work);
    a.join();
    b.join();
    std::cout << counter.load() << "\\n";
    return 0;
}
''', '''2000'''),
            quiz("Why is ++counter not safe from two threads?",
                 ["Because int is small", "Because it is three operations that can "
                  "interleave", "Because the compiler removes it",
                  "Because threads cannot add"],
                 1, "Read, add and write can be interleaved by another thread, which "
                    "loses an update."),
           ]),

    lesson("17003", 17, "Sharing data", "Lock Guard and Scope",
           "Hold the lock for as little as possible, and never while doing slow work.",
           ["Protect exactly the lines that touch shared data.",
            "Explain why holding a lock too long hurts.",
            "Recognise a lock held across a call that also locks."],
           [exp("The lock costs everybody\n\n"
                "While one thread holds a mutex, every other thread that wants it waits. "
                "The mutex is correct but it serialises the work, so the time spent inside "
                "it is time the program is effectively single-threaded.\n\n"
                "The habit is therefore: lock, touch the shared value, unlock. Do the "
                "reading, the computing and the printing outside the lock.\n\n"
                "lock_guard's scope is what makes this easy to see. The braces around it "
                "are the size of the critical section, and a reader can check it."),
            dfn("Critical section", "The lines of code that touch shared data and must run "
                                    "while holding the lock."),
            exp("Slow work outside the lock\n\n"
                "The shared total is updated inside a two-line critical section; the "
                "loop that does the work runs outside it. With a long task inside the "
                "lock, adding threads would make the program slower, not faster.\n\n"
                "This is the point where concurrency stops being about correctness and "
                "starts being about whether it was worth doing at all."),
            code('''#include <iostream>
#include <mutex>
#include <thread>
#include <vector>

int main() {
    long total = 0;
    std::mutex gate;
    auto work = [&total, &gate](int amount) {
        long local = 0;
        for (int i = 0; i < amount; ++i) {
            local += i;
        }
        std::lock_guard<std::mutex> guard(gate);
        total += local;
    };
    std::thread a(work, 100);
    std::thread b(work, 100);
    a.join();
    b.join();
    std::cout << total << "\\n";
    return 0;
}
''', '''9900'''),
            exp("The nested lock that hangs\n\n"
                "A std::mutex cannot be locked twice by the same thread: it blocks "
                "forever, waiting for itself. That is why the second function below is "
                "documented as 'assumes the lock is held' and never takes it.\n\n"
                "When a locking function must call another, decide once which level owns "
                "the lock, and keep that rule in the names: locked_add versus add."),
            CHALLENGE,
            code('''#include <iostream>
#include <mutex>

std::mutex gate;
int total = 0;

void add_locked(int amount) {
    total += amount;
}

void add(int amount) {
    std::lock_guard<std::mutex> guard(gate);
    add_locked(amount);
}

int main() {
    add(5);
    add(7);
    std::cout << total << "\\n";
    return 0;
}
''', '''12'''),
            quiz("Why keep the critical section as short as possible?",
                 ["Because the mutex is expensive to create",
                  "Because other threads wait for the whole time the lock is held",
                  "Because long functions cannot be locked",
                  "Because lock_guard expires"],
                 1, "A held lock serialises the program, so long critical sections remove "
                    "the benefit of having threads."),
           ]),

    lesson("17004", 17, "Deadlock", "Deadlock and Lock Ordering",
           "Two locks taken in two orders will eventually freeze the program.",
           ["Explain how a deadlock happens.",
            "Fix it by agreeing one global lock order.",
            "Use std::scoped_lock to take several locks at once."],
           [exp("Each holds one and waits for the other\n\n"
                "Thread A locks the first mutex and waits for the second. Thread B locks "
                "the second and waits for the first. Neither can proceed, and neither will "
                "ever release. The program hangs with no error message.\n\n"
                "The deadlock needs the right timing, so it may appear once in a thousand "
                "runs - which is exactly the kind of bug that reaches a user.\n\n"
                "There are two reliable cures: always take the locks in the same order, or "
                "take them both at once with std::scoped_lock."),
            dfn("Deadlock", "Two or more threads each holding a resource the other needs, "
                            "so none can continue."),
            dfn("Lock ordering", "A rule that every thread takes multiple locks in the "
                                 "same sequence, which makes a cycle impossible."),
            exp("Both locks, taken together\n\n"
                "std::scoped_lock with two or more mutexes takes them all or none, using "
                "an algorithm that cannot deadlock. C++17 provides it, so there is no "
                "reason to write the two-lock case by hand.\n\n"
                "Where you must take locks separately, the ordering rule is the fix: name "
                "the mutexes in a documented order and never take them the other way."),
            code('''#include <iostream>
#include <mutex>
#include <thread>

int main() {
    std::mutex first;
    std::mutex second;
    int balance = 0;
    auto work = [&] {
        std::scoped_lock both(first, second);
        ++balance;
    };
    std::thread a(work);
    std::thread b(work);
    a.join();
    b.join();
    std::cout << balance << "\\n";
    return 0;
}
''', '''2'''),
            exp("The same lock order in both threads\n\n"
                "You can also avoid the problem by never holding two locks at once. The "
                "example below moves the value in a single short critical section, so "
                "only one mutex exists and no cycle is possible.\n\n"
                "Fewer locks is the cheapest deadlock fix there is."),
            CHALLENGE,
            code('''#include <iostream>
#include <mutex>
#include <thread>

int main() {
    std::mutex gate;
    int moved = 0;
    auto work = [&] {
        for (int i = 0; i < 50; ++i) {
            std::lock_guard<std::mutex> guard(gate);
            ++moved;
        }
    };
    std::thread a(work);
    std::thread b(work);
    a.join();
    b.join();
    std::cout << moved << "\\n";
    return 0;
}
''', '''100'''),
            quiz("What is the reliable way to take two mutexes?",
                 ["Lock one, then sleep, then the other",
                  "std::scoped_lock with both, or an agreed global order",
                  "Use one mutex twice", "Never use two mutexes"],
                 1, "scoped_lock takes both without deadlock; an agreed ordering makes a "
                    "cycle impossible when they must be taken separately."),
           ]),

    lesson("17005", 17, "Tools", "Atomics and What They Guarantee",
           "One variable, no lock, one indivisible operation.",
           ["Use std::atomic for a shared counter or flag.",
            "Explain why an atomic is not a replacement for all locking.",
            "Read a value with load and write with store."],
           [exp("Operations that cannot be split\n\n"
                "An atomic type guarantees that its operations happen as a whole. Another "
                "thread sees the value before or after, never halfway through.\n\n"
                "That is enough for a counter, a flag, or a pointer swapped under a lock. "
                "It is not enough for two variables that must agree with each other: two "
                "separate atomic updates can still be observed apart.\n\n"
                "So the rule is: atomic for single values, mutex for invariants that span "
                "several."),
            dfn("std::atomic", "A type whose read-modify-write operations are indivisible, "
                               "so no other thread can observe a half-finished update."),
            exp("A counter and a flag\n\n"
                "Two threads increment an atomic counter with no lock, and the total is "
                "exact. A separate atomic flag is written once and read after the joins, "
                "which is the simplest form of thread hand-off.\n\n"
                "fetch_add returns the previous value, which is how an atomic is used to "
                "hand out unique numbers."),
            code('''#include <atomic>
#include <iostream>
#include <thread>

int main() {
    std::atomic<int> tickets{0};
    std::atomic<bool> finished{false};
    auto work = [&tickets] {
        for (int i = 0; i < 10; ++i) {
            tickets.fetch_add(1);
        }
    };
    std::thread a(work);
    std::thread b(work);
    a.join();
    b.join();
    finished.store(true);
    std::cout << tickets.load() << "\\n";
    std::cout << (finished.load() ? "finished" : "running") << "\\n";
    return 0;
}
''', '''20
finished'''),
            exp("When atomics are not enough\n\n"
                "Two atomics that must change together cannot be made consistent without "
                "a lock. A transfer that takes from one account and gives to another has "
                "to be seen as a whole, or a reader can observe money that exists in "
                "neither place.\n\n"
                "That is a mutex's job: it protects the relationship, not the individual "
                "variables."),
            CHALLENGE,
            code('''#include <atomic>
#include <iostream>
#include <thread>

int main() {
    std::atomic<long long> total{0};
    auto work = [&total](int amount) {
        long long local = 0;
        for (int i = 0; i < amount; ++i) {
            local += 2;
        }
        total.fetch_add(local);
    };
    std::thread a(work, 100);
    std::thread b(work, 100);
    a.join();
    b.join();
    std::cout << total.load() << "\\n";
    return 0;
}
''', '''400'''),
            quiz("When is a mutex needed instead of an atomic?",
                 ["When the value is an int", "When several values must stay consistent "
                  "with each other", "When the value is read often",
                  "When threads are joined"],
                 1, "Atomics guarantee single operations; a relationship between values "
                    "needs a lock."),
           ]),

    lesson("17006", 17, "Tools", "async and future",
           "Ask for a result, then collect it when you need it.",
           ["Run a function with std::async.",
            "Collect the result with future.get().",
            "Explain what get() does if the task has not finished."],
           [exp("A promise of a value\n\n"
                "std::async starts a function and returns a future. The future is a "
                "handle to a result that may not exist yet - you can hold it, pass it "
                "around, and ask for the value later.\n\n"
                "get() waits if the work is still running and returns the value once. It "
                "can be called only once, because the value is moved out of the future.\n\n"
                "This is the highest-level tool in the standard library: no threads to "
                "manage, and exceptions thrown inside the task are rethrown by get()."),
            dfn("future", "A handle to a value that will be produced, possibly later. get() "
                          "waits for it and takes it out."),
            exp("Two tasks, collected in order\n\n"
                "Each async call returns its own future. Collecting them with get() in a "
                "fixed order makes the printed result independent of which task finished "
                "first.\n\n"
                "That is the habit that keeps concurrent output predictable: start freely, "
                "collect in a defined order."),
            code('''#include <future>
#include <iostream>

int slow_square(int value) {
    return value * value;
}

int main() {
    auto first = std::async(std::launch::async, slow_square, 6);
    auto second = std::async(std::launch::async, slow_square, 7);
    std::cout << first.get() << "\\n";
    std::cout << second.get() << "\\n";
    return 0;
}
''', '''36
49'''),
            exp("An exception crosses the future\n\n"
                "If the task throws, the exception is stored in the future and rethrown "
                "by get(). The code that collects the result therefore has one place to "
                "handle failure, exactly as if the work had run in the same thread.\n\n"
                "That property is why async is easier to reason about than a raw thread: "
                "the error handling looks ordinary."),
            CHALLENGE,
            code('''#include <future>
#include <iostream>
#include <stdexcept>

int risky(int value) {
    if (value < 0) {
        throw std::invalid_argument("negative");
    }
    return value + 1;
}

int main() {
    auto good = std::async(std::launch::async, risky, 41);
    std::cout << good.get() << "\\n";
    auto bad = std::async(std::launch::async, risky, -1);
    try {
        bad.get();
    } catch (const std::invalid_argument& error) {
        std::cout << "caught: " << error.what() << "\\n";
    }
    return 0;
}
''', '''42
caught: negative'''),
            quiz("Where does an exception thrown inside an async task appear?",
                 ["It terminates the program", "It is rethrown by future.get()",
                  "It is silently ignored", "It is printed by the thread"],
                 1, "The future carries the exception to whoever collects the result."),
           ]),

    lesson("17007", 17, "Tools", "Waiting for a Condition",
           "A condition variable lets a thread sleep until there is work.",
           ["Use std::condition_variable with a predicate.",
            "Explain why a predicate loop is required.",
            "Avoid a busy wait."],
           [exp("Sleep until told\n\n"
                "A thread that must wait for data could loop asking 'is it ready yet?', "
                "which burns a core and delays everything else. A condition variable "
                "instead parks the thread and wakes it when notified.\n\n"
                "The pattern is: lock, wait until the predicate is true, then take the "
                "data. The predicate is not optional: spurious wake-ups happen, and the "
                "condition may become false again before the thread resumes.\n\n"
                "notify_one wakes one waiting thread, notify_all wakes all of them. "
                "Notify after changing the shared state, normally outside the lock."),
            dfn("Condition variable", "A synchronisation object a thread can wait on "
                                      "until another thread signals that a condition may "
                                      "be true."),
            exp("Producer and consumer\n\n"
                "The consumer waits until ready is true, inside a predicate loop. The "
                "producer sets ready and notifies. The join at the end guarantees the "
                "output is complete before anything is printed.\n\n"
                "done is atomic so that reading it after the join involves no lock at "
                "all."),
            code('''#include <condition_variable>
#include <iostream>
#include <mutex>
#include <thread>

int main() {
    std::mutex gate;
    std::condition_variable ready_signal;
    bool ready = false;
    int payload = 0;

    std::thread consumer([&] {
        std::unique_lock<std::mutex> lock(gate);
        ready_signal.wait(lock, [&ready] { return ready; });
        std::cout << "received " << payload << "\\n";
    });

    std::thread producer([&] {
        {
            std::lock_guard<std::mutex> lock(gate);
            payload = 55;
            ready = true;
        }
        ready_signal.notify_one();
    });

    consumer.join();
    producer.join();
    return 0;
}
''', '''received 55'''),
            exp("Why the loop is not optional\n\n"
                "wait with a predicate is a loop: it re-checks after every wake-up. "
                "Without it, a wake-up that arrives for another reason, or a second "
                "consumer that took the item first, would leave the thread using data that "
                "is not there.\n\n"
                "The predicate is the condition, and the loop is the proof that the "
                "condition still holds when the thread proceeds."),
            CHALLENGE,
            code('''#include <condition_variable>
#include <iostream>
#include <mutex>
#include <thread>

int main() {
    std::mutex gate;
    std::condition_variable signal;
    int value = 0;
    bool ready = false;

    std::thread waiter([&] {
        std::unique_lock<std::mutex> lock(gate);
        signal.wait(lock, [&ready] { return ready; });
        std::cout << "value " << value << "\\n";
    });
    std::thread setter([&] {
        {
            std::lock_guard<std::mutex> lock(gate);
            value = 7;
            ready = true;
        }
        signal.notify_one();
    });
    waiter.join();
    setter.join();
    return 0;
}
''', '''value 7'''),
            quiz("Why must wait() be given a predicate?",
                 ["To make it faster", "Because wake-ups can be spurious or the condition "
                  "can change again", "Because mutexes require it",
                  "To allow several waiters"],
                 1, "The predicate is re-checked after each wake-up, which is the only way "
                    "to know the condition actually holds."),
           ]),

    lesson("17008", 17, "Judgement", "When Not to Use Threads",
           "Concurrency adds bugs faster than it adds speed.",
           ["Name the costs of adding threads.",
            "Recognise work that cannot be parallelised usefully.",
            "Prefer the simplest design that meets the requirement."],
           [exp("What it costs\n\n"
                "Threads bring races, deadlocks, and bugs that appear once in a thousand "
                "runs. They bring the need for locks, and locks serialise. They bring "
                "scheduling, which the program does not control.\n\n"
                "The work also has to be divisible. A single long calculation followed by "
                "a single output gains nothing from four threads; the parts must be "
                "independent and large enough that dividing them pays for the "
                "coordination.\n\n"
                "So the first question is never 'how do I use threads?' but 'is this "
                "actually slow, and is the cost in a part I can divide?'"),
            dfn("Amdahl's law", "The speed-up from parallelising is limited by the part "
                                "that must stay sequential: if a tenth is serial, no "
                                "number of threads gives more than ten times."),
            exp("The measurement decides\n\n"
                "The same total computed sequentially and in two halves gives the identical "
                "answer, which shows the shape of the decision without claiming a speed-up "
                "that the program cannot see.\n\n"
                "In practice you would measure both, and choose threads only when the "
                "numbers justify the added risk."),
            code('''#include <iostream>

long total_sequential(int count) {
    long total = 0;
    for (int i = 0; i < count; ++i) {
        total += i;
    }
    return total;
}

long total_range(int from, int to) {
    long total = 0;
    for (int i = from; i < to; ++i) {
        total += i;
    }
    return total;
}

int main() {
    const int count = 100;
    long whole = total_sequential(count);
    long halves = total_range(0, 50) + total_range(50, 100);
    std::cout << whole << "\\n";
    std::cout << (whole == halves ? "same answer, split in two" : "mismatch") << "\\n";
    return 0;
}
''', '''4950
same answer, split in two'''),
            exp("The order that avoids trouble\n\n"
                "Measure first. If a stage dominates, divide that stage along a boundary "
                "with no shared state. Share nothing, or share one thing with one lock. "
                "Only then consider threads.\n\n"
                "Most programs that seem to need concurrency actually need a faster "
                "algorithm, and that is a change with no new failure modes at all."),
            CHALLENGE,
            code('''#include <iostream>

int main() {
    const int threads = 1;
    std::cout << "using " << threads << " thread: no lock, no race, no deadlock\\n";
    return 0;
}
''', '''using 1 thread: no lock, no race, no deadlock'''),
            quiz("What limits the speed-up from adding threads?",
                 ["The number of cores only",
                  "The part of the work that must run sequentially",
                  "The size of the source file", "The compiler version"],
                 1, "Amdahl's law: serial work sets a ceiling that no amount of threading "
                    "can pass."),
           ]),
]
