"""Level 18 — Performance."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("18001", 18, "Measuring", "Measure, Do Not Guess",
           "The slow line is almost never the one you suspect.",
           ["Instrument a function to count its calls.",
            "Explain why intuition about performance is unreliable.",
            "Compare two implementations by counting work."],
           [exp("Guessing is wrong often enough to be useless\n\n"
                "Programmers reliably predict which function is slow, and are reliably "
                "wrong about which is slowest. The cost is usually where the code was "
                "written quickly, not where it looks complicated.\n\n"
                "So measure. The cheapest measurement is a counter: how many times was "
                "this called, how many comparisons did it make, how many allocations "
                "happened.\n\n"
                "A counter also survives compiler optimisation, unlike a stopwatch reading "
                "of a function that was optimised away."),
            dfn("Instrumentation", "Counting calls or operations inside the code so that "
                                   "the real cost can be reported instead of guessed."),
            exp("Counting calls\n\n"
                "A static counter incremented inside each function turns 'this feels "
                "slow' into two numbers. It costs one increment and answers the question "
                "with evidence.\n\n"
                "Here the supposedly simple function is the one called a thousand times, "
                "and the complicated one is called once."),
            code('''#include <iostream>

int cheap_calls = 0;
int heavy_calls = 0;

int cheap(int value) {
    ++cheap_calls;
    return value + 1;
}

long heavy(long value) {
    ++heavy_calls;
    long total = 0;
    for (long i = 0; i < value; ++i) {
        total += i;
    }
    return total;
}

int main() {
    long answer = 0;
    for (int i = 0; i < 1000; ++i) {
        answer += cheap(i);
    }
    answer += heavy(10);
    std::cout << "cheap called " << cheap_calls << " times\\n";
    std::cout << "heavy called " << heavy_calls << " time\\n";
    std::cout << answer << "\\n";
    return 0;
}
''', '''cheap called 1000 times
heavy called 1 time
500545'''),
            exp("Two algorithms, one count\n\n"
                "Comparing implementations by operation count needs no clock and gives "
                "the same answer on every machine. That is the honest way to say one "
                "approach does less work than another.\n\n"
                "Only after the count shows a real difference is it worth timing, and only "
                "with many repetitions and a warm cache."),
            CHALLENGE,
            code('''#include <iostream>
#include <numeric>
#include <vector>

int main() {
    std::vector<int> values(1000, 1);
    int manual = 0;
    for (int value : values) {
        manual += value;
    }
    int library = std::accumulate(values.begin(), values.end(), 0);
    std::cout << manual << " " << library << "\\n";
    std::cout << (manual == library ? "same result" : "different") << "\\n";
    return 0;
}
''', '''1000 1000
same result'''),
            quiz("Why is a counter more reliable than a stopwatch for comparing algorithms?",
                 ["Counters are easier to type", "The count does not depend on the "
                  "machine, the load or the day", "Stopwatches are inaccurate by law",
                  "The compiler removes counters"],
                 1, "A count is a property of the algorithm and the input; a time includes "
                    "everything else that was happening."),
           ]),

    lesson("18002", 18, "Memory", "Cache Locality",
           "Contiguous data is fast because the processor fetches it in blocks.",
           ["Explain what a cache line is.",
            "Contrast walking a vector with following linked nodes.",
            "Describe how layout beats cleverness."],
           [exp("Memory arrives in blocks\n\n"
                "A processor does not read one value at a time. It fetches a whole cache "
                "line, typically 64 bytes, and the next value in the same line costs "
                "almost nothing.\n\n"
                "So the order in which you touch memory matters enormously. A vector puts "
                "its elements next to each other; each fetch of a line brings several "
                "elements that are about to be needed.\n\n"
                "A linked list scatters its nodes wherever the allocator had room, so each "
                "step may fetch a new line and the processor waits."),
            dfn("Cache line", "The block of memory the processor transfers at once, "
                              "usually 64 bytes, holding several adjacent values."),
            exp("One block or many\n\n"
                "The vector's elements are contiguous, so the count of distinct memory "
                "blocks touched is a single line: eight ints fit in 64 bytes. That is why "
                "iteration over a vector is the fastest thing the machine can do.\n\n"
                "This is the reason the standard advice is to prefer contiguous containers "
                "even when the asymptotics look identical."),
            code('''#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{1, 2, 3, 4, 5, 6, 7, 8};
    std::cout << "element bytes " << sizeof(int) << "\\n";
    std::cout << "whole vector bytes " << values.size() * sizeof(int) << "\\n";
    std::cout << "fits in one 64-byte line "
              << ((values.size() * sizeof(int) <= 64) ? "yes" : "no") << "\\n";
    std::cout << (values.data() + 1 == &values[1] ? "elements are adjacent" : "scattered")
              << "\\n";
    return 0;
}
''', '''element bytes 4
whole vector bytes 32
fits in one 64-byte line yes
elements are adjacent'''),
            exp("Reading in the order it is stored\n\n"
                "Row-major order means a two-dimensional grid is stored row by row. "
                "Walking it in storage order touches consecutive memory; walking it column "
                "by column jumps a whole row on every step.\n\n"
                "Same number of additions, very different number of cache lines. The "
                "algorithm is identical and the data layout is not."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

int main() {
    const int rows = 3;
    const int cols = 4;
    std::vector<int> grid(static_cast<std::size_t>(rows * cols), 1);
    int total = 0;
    for (int row = 0; row < rows; ++row) {
        for (int col = 0; col < cols; ++col) {
            total += grid[static_cast<std::size_t>(row * cols + col)];
        }
    }
    std::cout << total << " over " << rows << " rows, storage order\\n";
    return 0;
}
''', '''12 over 3 rows, storage order'''),
            quiz("Why is iterating a vector usually faster than a linked list of the same length?",
                 ["Vectors hold fewer bytes per element",
                  "Adjacent elements share cache lines, so memory is fetched in fewer, "
                  "larger blocks",
                  "Linked lists are stored on disk", "Vectors use threads"],
                 1, "Contiguous layout means one fetch serves several elements; scattered "
                    "nodes may each cost a full memory transfer."),
           ]),

    lesson("18003", 18, "Memory", "Allocation Is Not Free",
           "Every allocation is a system call, a lock, and a search for space.",
           ["Explain why allocation costs more than a few instructions.",
            "Use reserve to avoid repeated reallocation.",
            "Recognise a pattern that allocates in a loop."],
           [exp("What an allocation involves\n\n"
                "A heap allocation finds a free block large enough, updates its own "
                "bookkeeping, and possibly asks the operating system for more memory. In a "
                "multi-threaded program it also takes a lock.\n\n"
                "That is hundreds of times the cost of an addition, and doing it inside a "
                "loop turns a fast program into a slow one.\n\n"
                "The standard guarantee you rely on is simple: if capacity is already "
                "sufficient, push_back does not reallocate."),
            dfn("Capacity", "How many elements a vector can hold before it must find a "
                            "bigger block. reserve sets it in advance."),
            exp("Reserve once, append many\n\n"
                "After reserve(100) the vector has room, so a hundred appends cause no "
                "reallocation at all. The count of reallocations here is zero, and the "
                "program can prove it rather than assume it.\n\n"
                "Without the reserve the vector would grow several times, each time "
                "copying or moving everything it already held."),
            code('''#include <iostream>
#include <vector>

int main() {
    std::vector<int> values;
    values.reserve(100);
    std::size_t capacity = values.capacity();
    int reallocations = 0;
    for (int i = 0; i < 100; ++i) {
        values.push_back(i);
        if (values.capacity() != capacity) {
            ++reallocations;
            capacity = values.capacity();
        }
    }
    std::cout << "size " << values.size() << "\\n";
    std::cout << "reallocations " << reallocations << "\\n";
    std::cout << "capacity at least 100 "
              << (values.capacity() >= 100 ? "yes" : "no") << "\\n";
    return 0;
}
''', '''size 100
reallocations 0
capacity at least 100 yes'''),
            exp("Allocating inside a loop\n\n"
                "A string rebuilt inside a loop allocates once per pass. Building into one "
                "string that already has room does all the work at once.\n\n"
                "The same rule applies to temporary containers, to returning large objects "
                "by value repeatedly, and to creating a new vector in every iteration of "
                "an inner loop."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>

int main() {
    std::string report;
    report.reserve(32);
    for (int i = 0; i < 5; ++i) {
        report += "x";
    }
    std::cout << report.size() << " characters\\n";
    std::cout << "capacity enough " << (report.capacity() >= 5 ? "yes" : "no") << "\\n";
    return 0;
}
''', '''5 characters
capacity enough yes'''),
            quiz("What does reserve(100) guarantee?",
                 ["The vector holds 100 elements", "Room for 100 elements, so appends "
                  "will not reallocate until size exceeds it",
                  "The vector is sorted", "The size becomes 100"],
                 1, "It sets capacity, not size: push_back stays free of reallocation "
                    "while size <= capacity."),
           ]),

    lesson("18004", 18, "Copies", "Avoiding Needless Copies",
           "Pass by const reference, move when you are done, and count what you saved.",
           ["Pass a large object by const reference.",
            "Move from an object you no longer need.",
            "Count copies and moves to prove the difference."],
           [exp("The copy you did not ask for\n\n"
                "Passing a string by value copies it, and the caller cannot see that "
                "happen. For a large string or a vector of a million elements that copy is "
                "the entire cost of the call.\n\n"
                "A const reference passes the same object without copying and without "
                "promising to leave it alone. That is the default for anything bigger than "
                "a couple of registers.\n\n"
                "When you genuinely own the value and are finished with it, std::move "
                "hands over its internals instead of copying."),
            dfn("Reference parameter", "A parameter written Type& or const Type&, which "
                                       "refers to the caller's object instead of copying "
                                       "it."),
            exp("Counting the difference\n\n"
                "A copy-counting type makes the cost visible: passing by value records one "
                "copy, passing by reference records none, and moving records a move "
                "instead of a copy.\n\n"
                "That is the whole habit in one example: look at the signature, then "
                "measure what it costs."),
            code('''#include <iostream>
#include <string>

struct Tracker {
    static int copies;
    std::string text;
    explicit Tracker(std::string value) : text(value) {}
    Tracker(const Tracker& other) : text(other.text) { ++copies; }
};
int Tracker::copies = 0;

void by_value(Tracker other) {
    (void)other;
}

void by_reference(const Tracker& other) {
    (void)other;
}

int main() {
    Tracker item("report");
    by_value(item);
    std::cout << "after by_value: " << Tracker::copies << "\\n";
    by_reference(item);
    std::cout << "after by_reference: " << Tracker::copies << "\\n";
    return 0;
}
''', '''after by_value: 1
after by_reference: 1'''),
            exp("Move instead of copy when the original is finished\n\n"
                "A move constructor takes the string's buffer instead of duplicating it, "
                "so the cost is independent of how much text there is.\n\n"
                "The rule for reading code: if a parameter is only read, make it const&. "
                "If it is taken to be stored, take it by value and std::move it into the "
                "member, which is the pattern the constructors in this course already "
                "use."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <utility>
#include <vector>

int main() {
    std::vector<std::string> names{"ada", "bo"};
    names.reserve(4);
    std::string extra = "cy";
    names.push_back(std::move(extra));
    std::cout << names.size() << " names\\n";
    std::cout << "last " << names.back() << "\\n";
    std::cout << "moved-from is " << (extra.empty() ? "empty" : "still holding text")
              << "\\n";
    return 0;
}
''', '''3 names
last cy
moved-from is empty'''),
            quiz("When is passing by value the right choice?",
                 ["Always, it is simpler", "When the function takes ownership and will "
                  "move the value into its own member",
                  "When the type is large", "Never"],
                 1, "Taking by value then moving into a member gives one copy from the "
                    "caller and none after; for large read-only data, const& is still "
                    "better."),
           ]),

    lesson("18005", 18, "Algorithms", "Algorithmic Cost Beats Micro-optimisation",
           "A better algorithm wins by orders of magnitude; a better loop wins by a few percent.",
           ["Compare linear and binary search by comparison count.",
            "State the growth rates you should recognise.",
            "Decide when a data structure change is the real optimisation."],
           [exp("The two levers\n\n"
                "You can make the same loop tighter, or you can replace it with an "
                "algorithm that does less work. The first changes a constant factor; the "
                "second changes how the cost grows.\n\n"
                "For a thousand items, binary search needs about ten comparisons and "
                "linear search up to a thousand. No amount of loop tuning closes a "
                "hundred-fold gap.\n\n"
                "So the order of work is: choose the right algorithm, choose the right "
                "data structure, and only then look at the inner loop."),
            dfn("Growth rate", "How cost rises with input size: O(1) constant, O(log n) "
                               "logarithmic, O(n) linear, O(n log n) sorting, O(n squared) "
                               "the naive nested loop."),
            exp("The same search, counted twice\n\n"
                "Both functions look for the last element of a sorted vector of a thousand "
                "values. One performs a thousand comparisons, the other about ten, and the "
                "counts are printed so the difference is not a claim but a measurement.\n\n"
                "Twenty halvings reach a million; doubling the data adds one comparison, "
                "not a thousand."),
            code('''#include <iostream>
#include <vector>

int linear_count(const std::vector<int>& data, int wanted) {
    int comparisons = 0;
    for (int value : data) {
        ++comparisons;
        if (value == wanted) {
            break;
        }
    }
    return comparisons;
}

int binary_count(const std::vector<int>& data, int wanted) {
    int low = 0;
    int high = static_cast<int>(data.size()) - 1;
    int comparisons = 0;
    while (low <= high) {
        ++comparisons;
        int middle = low + (high - low) / 2;
        if (data[static_cast<std::size_t>(middle)] == wanted) {
            return comparisons;
        }
        if (data[static_cast<std::size_t>(middle)] < wanted) {
            low = middle + 1;
        } else {
            high = middle - 1;
        }
    }
    return comparisons;
}

int main() {
    std::vector<int> data(1000);
    for (int i = 0; i < 1000; ++i) {
        data[static_cast<std::size_t>(i)] = i;
    }
    std::cout << "linear " << linear_count(data, 999) << "\\n";
    std::cout << "binary " << binary_count(data, 999) << "\\n";
    return 0;
}
''', '''linear 1000
binary 10'''),
            exp("The nested loop to watch for\n\n"
                "A loop inside a loop over the same data is quadratic: a hundred items "
                "cost ten thousand steps, and a thousand items cost a million. That is the "
                "shape that makes a program feel slow when the data grows.\n\n"
                "The fix is usually a map or a set that answers the inner question "
                "directly, turning a search into a lookup."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

int main() {
    std::vector<int> data{5, 3, 5, 3, 5};
    int pairs = 0;
    for (std::size_t i = 0; i < data.size(); ++i) {
        for (std::size_t j = i + 1; j < data.size(); ++j) {
            if (data[i] == data[j]) {
                ++pairs;
            }
        }
    }
    std::cout << pairs << " equal pairs from " << data.size() << " values\\n";
    return 0;
}
''', '''4 equal pairs from 5 values'''),
            quiz("Which change usually helps most?",
                 ["Replacing an O(n log n) algorithm with a tighter O(n squared) one",
                  "Replacing an O(n squared) algorithm with an O(n log n) or O(n) one",
                  "Adding more comments", "Using shorter variable names"],
                 1, "Changing the growth rate dominates; tuning constants helps only after "
                    "the algorithm is right."),
           ]),

    lesson("18006", 18, "Measuring", "Profiling Instead of Guessing",
           "Let the tool name the hot function, then look at why.",
           ["Describe what a profiler reports.",
            "Find a hot spot with a counter before reaching for a tool.",
            "Interpret a profile by share of total time."],
           [exp("What a profiler tells you\n\n"
                "A profiler samples the program while it runs and reports where the time "
                "went, as a share per function. The names at the top are the ones worth "
                "changing.\n\n"
                "It does not tell you why. A function can be hot because it is called a "
                "million times, or once and slowly, and those are different fixes.\n\n"
                "That distinction is why call counts and per-call cost are read together: "
                "count times cost per call is the total."),
            dfn("Hot spot", "The small part of the program where most of the time is "
                            "spent, as reported by a profiler."),
            exp("The arithmetic a profiler is doing\n\n"
                "One function called a thousand times at two units each costs two thousand. "
                "Another called once at five hundred costs five hundred. Sorting them by "
                "total cost, in the program, is what a profiler does with samples.\n\n"
                "Doing it by hand on a small program keeps the skill visible: total cost = "
                "calls times cost per call."),
            code('''#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

struct Sample {
    std::string name;
    int calls = 0;
    int cost_per_call = 0;
};

int main() {
    std::vector<Sample> samples{{"parse", 1000, 2}, {"render", 5, 40}, {"load", 1, 500}};
    std::sort(samples.begin(), samples.end(), [](const Sample& a, const Sample& b) {
        return a.calls * a.cost_per_call > b.calls * b.cost_per_call;
    });
    for (const Sample& sample : samples) {
        std::cout << sample.name << " total " << sample.calls * sample.cost_per_call
                  << "\\n";
    }
    return 0;
}
''', '''parse total 2000
load total 500
render total 200'''),
            exp("Fix the top, then measure again\n\n"
                "After the first fix the profile changes, and the new top entry stays put "
                "until it is fixed. Two rounds of this usually get most of the "
                "improvement, and the third round finds nothing worth the risk.\n\n"
                "Keeping the version that measured better, rather than the one that looked "
                "cleverer, is the whole method."),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> timings{40, 2, 500};
    std::sort(timings.begin(), timings.end());
    std::cout << "largest share: " << timings.back() << "\\n";
    std::cout << "total: " << timings[0] + timings[1] + timings[2] << "\\n";
    return 0;
}
''', '''largest share: 500
total: 542'''),
            quiz("A function is the hottest in the profile. What do you need next?",
                 ["Rewrite it immediately", "Know whether it is called often or is slow per "
                  "call", "Add more threads", "Compile with -O3"],
                 1, "Many cheap calls and one expensive call need completely different "
                    "fixes, and the profile alone does not say which."),
           ]),

    lesson("18007", 18, "The compiler", "What the Optimiser Can Do",
           "Compile-time work is free; undefined behaviour makes optimisation a gamble.",
           ["Use constexpr to compute at compile time.",
            "Explain why undefined behaviour can change program output.",
            "Describe what -O2 may change about your code."],
           [exp("Work done before the program runs\n\n"
                "A constexpr function can be evaluated by the compiler, so a table or a "
                "value costs nothing at run time. static_assert can then check the result "
                "while building.\n\n"
                "The optimiser also inlines small functions, hoists work out of loops and "
                "removes variables nothing reads. That is why timing at -O0 and -O2 gives "
                "different answers, and why counts are the honest measurement.\n\n"
                "None of this changes what a correct program prints."),
            dfn("constexpr", "A function or variable that may be evaluated during "
                             "compilation, so its value is fixed before the program "
                             "starts."),
            exp("Computed while building\n\n"
                "factorial is constexpr, so the table below is filled at compile time and "
                "the static_assert checks the answers during the build. Nothing is computed "
                "when the program runs.\n\n"
                "This is the cleanest kind of optimisation: no trade-off, no risk, and no "
                "change to the logic."),
            code('''#include <iostream>

constexpr long factorial(int value) {
    long result = 1;
    for (int i = 2; i <= value; ++i) {
        result *= i;
    }
    return result;
}

int main() {
    static_assert(factorial(5) == 120, "factorial must be correct");
    std::cout << factorial(5) << "\\n";
    std::cout << factorial(10) << "\\n";
    return 0;
}
''', '''120
3628800'''),
            exp("The dangerous side of optimisation\n\n"
                "When a program has undefined behaviour - reading past an array, using an "
                "uninitialised value, signed overflow - the compiler is allowed to assume "
                "it never happens. It may then delete the check that the code depends on, "
                "and the bug appears only in the optimised build.\n\n"
                "That is why 'it works in debug' is not evidence. The optimised build is "
                "where undefined behaviour becomes visible, and the fix is to remove the "
                "undefined behaviour, not the optimisation."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

int main() {
    constexpr int limit = 4;
    std::vector<int> values;
    values.reserve(static_cast<std::size_t>(limit));
    for (int i = 0; i < limit; ++i) {
        values.push_back(i * i);
    }
    int total = 0;
    for (int value : values) {
        total += value;
    }
    std::cout << total << " from " << limit << " values\\n";
    return 0;
}
''', '''14 from 4 values'''),
            quiz("Why can undefined behaviour change a program's output at -O2?",
                 ["Because -O2 adds new instructions",
                  "Because the compiler may assume it cannot happen and remove code that "
                  "relied on it",
                  "Because optimisation disables exceptions",
                  "Because -O2 changes the language"],
                 1, "Optimisation is reasoning from the rules, and undefined behaviour gives "
                    "the compiler freedom to assume the impossible case away."),
           ]),

    lesson("18008", 18, "Judgement", "A Performance Checklist",
           "Six questions in the right order, and the discipline to stop.",
           ["Follow a checklist in the order that pays.",
            "Decide when performance work is finished.",
            "Write code that is fast by default without being clever."],
           [exp("The order that works\n\n"
                "First: is it actually too slow? Measure. Second: is the algorithm right, "
                "or is it quadratic where linear exists? Third: is the data structure "
                "right for the operations being performed?\n\n"
                "Fourth: are there needless copies, and can reserve remove repeated "
                "allocations? Fifth, and only now: is the inner loop doing less than it "
                "could? Sixth: stop when the measurement says the remaining cost does not "
                "matter.\n\n"
                "Most real improvements come from steps two and three, and most wasted "
                "effort comes from starting at step five."),
            dfn("Premature optimisation", "Making code harder to read for speed that was "
                                          "never measured and may not matter."),
            exp("Fast by default\n\n"
                "The code that is fast without being clever: const references for large "
                "parameters, reserve when the count is known, move when the original is "
                "finished, contiguous containers, and algorithms from the library instead "
                "of hand-written loops.\n\n"
                "None of these makes the code harder to read. That is the difference "
                "between them and premature optimisation."),
            code('''#include <iostream>
#include <numeric>
#include <string>
#include <vector>

int main() {
    std::vector<int> values;
    values.reserve(5);
    for (int i = 1; i <= 5; ++i) {
        values.push_back(i);
    }
    const int total = std::accumulate(values.begin(), values.end(), 0);
    const std::string label = "total";
    std::cout << label << " " << total << "\\n";
    std::cout << "average " << static_cast<double>(total) / static_cast<double>(values.size())
              << "\\n";
    return 0;
}
''', '''total 15
average 3'''),
            exp("When to stop\n\n"
                "Stop when the measurement says the program meets its requirement, and "
                "when the next change would cost readability for a gain you cannot see.\n\n"
                "A program that is fast enough and readable will be maintained. A program "
                "that is fast and unreadable will be broken by the next person, including "
                "you, and the speed will go with it."),
            CHALLENGE,
            code('''#include <iostream>

int main() {
    const int steps = 6;
    const char* checklist[steps] = {"measure", "algorithm", "structure",
                                    "copies", "inner loop", "stop"};
    for (int i = 0; i < steps; ++i) {
        std::cout << i + 1 << ". " << checklist[i] << "\\n";
    }
    return 0;
}
''', '''1. measure
2. algorithm
3. structure
4. copies
5. inner loop
6. stop'''),
            quiz("Which step usually produces the largest improvement?",
                 ["Tuning the inner loop", "Choosing a better algorithm or data structure",
                  "Using shorter names", "Compiling with more flags"],
                 1, "Changing the growth rate or the structure dominates everything that "
                    "comes after it."),
           ]),
]
