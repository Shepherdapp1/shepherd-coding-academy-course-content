"""Compile every cpp block and compare its output with expected_output."""
import json, subprocess, sys, tempfile
from pathlib import Path

manifest = json.load(open(Path(__file__).resolve().parent / "manifest.json"))
problems = checked = 0
for item in manifest["items"]:
    if item.get("kind") != "lesson":
        continue
    for index, block in enumerate(item.get("body", [])):
        if block.get("kind") != "code" or block.get("language") != "cpp":
            continue
        checked += 1
        with tempfile.TemporaryDirectory() as tmp:
            src = Path(tmp) / "main.cpp"
            src.write_text(block["code"], encoding="utf-8")
            exe = Path(tmp) / "prog"
            build = subprocess.run(["g++", "-std=c++17", "-Wall", "-Wextra", "-pedantic", "-O0",
                                    str(src), "-o", str(exe)],
                                   capture_output=True, text=True)
            if build.returncode != 0:
                problems += 1
                print(f"COMPILE FAIL  {item['title']} block {index}")
                print("   " + build.stderr.strip().splitlines()[-1])
                continue
            if build.stderr.strip():
                problems += 1
                print(f"WARNING       {item['title']} block {index}: "
                      f"{build.stderr.strip().splitlines()[0][:90]}")
            run = subprocess.run([str(exe)], capture_output=True, text=True, timeout=20)
            expected = (block.get("expected_output") or "").strip()
            actual = run.stdout.strip()
            if actual != expected:
                problems += 1
                print(f"OUTPUT DIFF   {item['title']} block {index}")
                print(f"   expected: {expected!r}")
                print(f"   actual  : {actual!r}")
print(f"{checked} code blocks compiled and run; {problems} problem(s)")
sys.exit(1 if problems else 0)
