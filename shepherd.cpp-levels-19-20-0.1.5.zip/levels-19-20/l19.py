"""Level 19 — Design and Larger Programs."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("19001", 19, "Interfaces", "Separate the Interface from the Implementation",
           "Callers should need the promise, not the code behind it.",
           ["Write an abstract base class that declares a promise.",
            "Call through a base pointer and get the derived behaviour.",
            "Explain what a virtual destructor protects."],
           [exp("A promise, not a body\n\n"
                "An abstract class declares what a family of types can do and nothing "
                "about how. A pure virtual function, written = 0, has no body, so the "
                "class cannot be instantiated on its own.\n\n"
                "Callers are written against the base class and never mention the derived "
                "ones. Adding a second implementation later means changing no calling "
                "code at all.\n\n"
                "This is the foundation the patterns in this level are built on: code that "
                "depends on a promise is not coupled to any particular body."),
            dfn("Abstract class", "A class with at least one pure virtual function. It "
                                  "cannot be instantiated, only inherited from."),
            dfn("Virtual destructor", "A destructor declared virtual so that deleting "
                                      "through a base pointer destroys the derived part "
                                      "as well."),
            exp("One pointer, two behaviours\n\n"
                "Shape declares area() and name(). Square and Circle supply the bodies. "
                "main holds a Shape* and calls through it, getting the right answer for "
                "each without knowing which type it has.\n\n"
                "This is dynamic dispatch: the call is resolved at run time from the "
                "object, not from the pointer."),
            code('''#include <iostream>
#include <memory>
#include <string>

class Shape {
public:
    virtual ~Shape() = default;
    virtual double area() const = 0;
    virtual std::string name() const = 0;
};

class Square : public Shape {
public:
    explicit Square(double side) : side_(side) {}
    double area() const override { return side_ * side_; }
    std::string name() const override { return "square"; }
private:
    double side_;
};

class Circle : public Shape {
public:
    explicit Circle(double radius) : radius_(radius) {}
    double area() const override { return 3.14159 * radius_ * radius_; }
    std::string name() const override { return "circle"; }
private:
    double radius_;
};

int main() {
    std::unique_ptr<Shape> shape = std::make_unique<Square>(3.0);
    std::cout << shape->name() << " " << shape->area() << "\\n";
    shape = std::make_unique<Circle>(2.0);
    std::cout << shape->name() << " " << shape->area() << "\\n";
    return 0;
}
''', '''square 9
circle 12.5664'''),
            exp("The missing virtual destructor\n\n"
                "Delete a derived object through a base pointer whose destructor is not "
                "virtual, and only the base part is destroyed. The derived members leak, "
                "silently and permanently.\n\n"
                "Once a class has any virtual function it needs a virtual destructor. "
                "Writing = default costs nothing and closes the hole."),
            CHALLENGE,
            code('''#include <iostream>
#include <memory>

class Animal {
public:
    virtual ~Animal() = default;
    virtual const char* sound() const { return "..."; }
};

class Dog : public Animal {
public:
    const char* sound() const override { return "woof"; }
};

int main() {
    std::unique_ptr<Animal> pet = std::make_unique<Dog>();
    std::cout << pet->sound() << "\\n";
    return 0;
}
''', '''woof'''),
            quiz("What does = 0 on a virtual function mean?",
                 ["The function returns zero", "It is pure virtual: no body, so the class "
                  "is abstract", "It is an inline function", "It is private"],
                 1, "A pure virtual function makes the class abstract: derived types must "
                    "provide a body before anything can be instantiated."),
           ]),

    lesson("19002", 19, "Patterns", "The Factory",
           "One function decides which type you get, so the caller names none of them.",
           ["Use a function to create an object from a string.",
            "Explain what the caller stops depending on.",
            "Say when a factory is worth the indirection."],
           [exp("A name instead of a type\n\n"
                "A factory takes a description and returns an object, usually a "
                "unique_ptr to a base class. The caller says \"square\" and never mentions "
                "the Square class at all.\n\n"
                "That buys one important thing: the decision of which type to create lives "
                "in exactly one place. Adding a shape means editing the factory and "
                "nothing else.\n\n"
                "It also closes the interface for construction: an unknown name is "
                "rejected in one place with one message, instead of at every call site."),
            dfn("Factory function", "A function whose job is to create and return objects, "
                                    "so callers depend on a name or a parameter rather "
                                    "than on concrete types."),
            exp("The factory, and what it returns\n\n"
                "make_shape returns a unique_ptr<Shape> or null. The caller checks once and "
                "then uses the object as a Shape.\n\n"
                "Every addition to the shapes is confined to this one function, which is "
                "the property to look for when deciding whether a factory earns its "
                "place."),
            code('''#include <iostream>
#include <memory>
#include <string>

class Shape {
public:
    virtual ~Shape() = default;
    virtual double area() const = 0;
};

class Square : public Shape {
public:
    explicit Square(double side) : side_(side) {}
    double area() const override { return side_ * side_; }
private:
    double side_;
};

class Rect : public Shape {
public:
    Rect(double width, double height) : width_(width), height_(height) {}
    double area() const override { return width_ * height_; }
private:
    double width_;
    double height_;
};

std::unique_ptr<Shape> make_shape(const std::string& kind) {
    if (kind == "square") {
        return std::make_unique<Square>(3.0);
    }
    if (kind == "rect") {
        return std::make_unique<Rect>(2.0, 5.0);
    }
    return nullptr;
}

int main() {
    auto first = make_shape("square");
    auto second = make_shape("rect");
    auto third = make_shape("hexagon");
    std::cout << first->area() << "\\n";
    std::cout << second->area() << "\\n";
    std::cout << (third ? "made" : "unknown shape") << "\\n";
    return 0;
}
''', '''9
10
unknown shape'''),
            exp("When a factory is not worth it\n\n"
                "If only one type is ever created, a factory is a layer of indirection "
                "that hides a plain constructor. If the type is known at the call site and "
                "never varies, construct it there.\n\n"
                "The factory earns its place when the choice varies at run time or comes "
                "from data - a configuration file, a user command, a protocol message."),
            CHALLENGE,
            code('''#include <iostream>
#include <memory>

class Report {
public:
    virtual ~Report() = default;
    virtual const char* format() const = 0;
};

class Csv : public Report {
public:
    const char* format() const override { return "csv"; }
};

std::unique_ptr<Report> make(const char* kind) {
    if (std::string(kind) == "csv") {
        return std::make_unique<Csv>();
    }
    return nullptr;
}

int main() {
    auto report = make("csv");
    std::cout << report->format() << "\\n";
    return 0;
}
''', '''csv'''),
            quiz("What does a factory centralise?",
                 ["Memory use", "The decision of which concrete type to construct",
                  "Thread creation", "The compiler flags"],
                 1, "One function owns the decision, so adding a type touches one place "
                    "instead of every call site."),
           ]),

    lesson("19003", 19, "Patterns", "The Strategy",
           "Put the varying part behind an interface and let the caller choose it.",
           ["Implement behaviour behind an interface object.",
            "Swap the strategy at run time.",
            "Explain the difference from inheritance of the whole class."],
           [exp("The part that changes\n\n"
                "Two reports may differ only in how numbers are formatted. Copying the "
                "whole report class to change one step duplicates everything else and "
                "doubles the maintenance.\n\n"
                "A strategy puts the changing step behind a small interface and passes it "
                "in. The report itself never changes; only the collaborator does.\n\n"
                "This is composition instead of inheritance, and it is the reason the "
                "advice 'prefer composition' exists: behaviour can be swapped at run time "
                "only if it is an object rather than a base class."),
            dfn("Strategy", "A small interface for one varying step, passed in so the "
                            "calling code stays the same while the behaviour changes."),
            exp("Two formatters, one report\n\n"
                "Formatter declares format(). Plain and Bracketed implement it. Report "
                "holds a reference and calls it, so the same report type produces two "
                "different outputs.\n\n"
                "The strategy is chosen once, where the report is constructed, and the "
                "report code has no idea which one it got."),
            code('''#include <iostream>
#include <memory>
#include <string>

class Formatter {
public:
    virtual ~Formatter() = default;
    virtual std::string format(const std::string& value) const = 0;
};

class Plain : public Formatter {
public:
    std::string format(const std::string& value) const override { return value; }
};

class Bracketed : public Formatter {
public:
    std::string format(const std::string& value) const override {
        return "[" + value + "]";
    }
};

class Report {
public:
    explicit Report(const Formatter& formatter) : formatter_(formatter) {}
    void print(const std::string& value) const {
        std::cout << formatter_.format(value) << "\\n";
    }
private:
    const Formatter& formatter_;
};

int main() {
    Plain plain;
    Bracketed bracketed;
    Report first(plain);
    Report second(bracketed);
    first.print("total 42");
    second.print("total 42");
    return 0;
}
''', '''total 42
[total 42]'''),
            exp("A strategy can be a function\n\n"
                "When the varying step is a single action, a std::function or a lambda "
                "does the same job with less code. The class hierarchy is for when the "
                "strategy has state or several related operations.\n\n"
                "Choosing the lighter form is part of the skill: an interface with one "
                "method and no state is usually a mistake dressed as a design pattern."),
            CHALLENGE,
            code('''#include <functional>
#include <iostream>
#include <string>

class Report {
public:
    using Formatter = std::function<std::string(const std::string&)>;
    explicit Report(Formatter formatter) : formatter_(std::move(formatter)) {}
    void print(const std::string& value) const {
        std::cout << formatter_(value) << "\\n";
    }
private:
    Formatter formatter_;
};

int main() {
    Report loud([](const std::string& value) { return value + "!"; });
    loud.print("done");
    Report quiet([](const std::string& value) { return "(" + value + ")"; });
    quiet.print("done");
    return 0;
}
''', '''done!
(done)'''),
            quiz("Why can a strategy be swapped at run time while a base class cannot?",
                 ["Strategies are faster", "The behaviour is an object held by the caller, "
                  "not the object's own type", "Base classes are private",
                  "Strategies use templates"],
                 1, "An object's type is fixed when it is created; a collaborator it holds "
                    "can be replaced."),
           ]),

    lesson("19004", 19, "Patterns", "The Observer",
           "Notify a list of listeners without knowing any of them.",
           ["Store a list of callbacks and call each one.",
            "Add and remove observers at run time.",
            "Explain the lifetime problem with references to listeners."],
           [exp("Tell everyone who asked\n\n"
                "A subject keeps a list of observers and calls each one when something "
                "happens. It never knows what the observers do or how many there are.\n\n"
                "This is the shape behind event handlers, progress reporting and model "
                "updates in a user interface. The standard library gives you the "
                "callback itself through std::function.\n\n"
                "The interface between the two sides is one idea: something happened, "
                "here is the information."),
            dfn("Observer", "A callback registered with a subject, called whenever the "
                            "subject announces a change."),
            exp("Two listeners, one announcement\n\n"
                "The subject holds std::function callbacks. Each listener decides what to "
                "do with the value, and the subject calls them in the order they were "
                "added.\n\n"
                "The order matters twice: it makes the program deterministic, and it means "
                "a listener that removes others while being called will surprise you."),
            code('''#include <functional>
#include <iostream>
#include <vector>

class Counter {
public:
    using Listener = std::function<void(int)>;

    void subscribe(Listener listener) {
        listeners_.push_back(std::move(listener));
    }

    void tick() {
        ++value_;
        for (const Listener& listener : listeners_) {
            listener(value_);
        }
    }

private:
    int value_ = 0;
    std::vector<Listener> listeners_;
};

int main() {
    Counter counter;
    counter.subscribe([](int value) { std::cout << "total " << value << "\\n"; });
    counter.subscribe([](int value) { std::cout << "seen " << value << "\\n"; });
    counter.tick();
    counter.tick();
    return 0;
}
''', '''total 1
seen 1
total 2
seen 2'''),
            exp("The lifetime hazard\n\n"
                "If an observer is a reference or a pointer to an object, and that object "
                "is destroyed first, the next notification calls into freed memory. The "
                "subject has no way to know.\n\n"
                "Two common fixes: the observer unsubscribes in its own destructor, or the "
                "subject holds weak references and skips the expired ones. Either way, the "
                "question 'who outlives whom?' must be answered when the observer is "
                "registered, not when it crashes."),
            CHALLENGE,
            code('''#include <functional>
#include <iostream>
#include <vector>

int main() {
    std::vector<std::function<int(int)>> steps;
    steps.push_back([](int value) { return value + 1; });
    steps.push_back([](int value) { return value * 2; });
    int value = 3;
    for (const auto& step : steps) {
        value = step(value);
    }
    std::cout << value << "\\n";
    return 0;
}
''', '''8'''),
            quiz("What is the main hazard with observers held by reference?",
                 ["They are slow to call", "The observer may be destroyed before the "
                  "subject notifies it", "They cannot be sorted",
                  "They require threads"],
                 1, "A subject cannot detect a destroyed listener, so the registration "
                    "must come with a lifetime rule."),
           ]),

    lesson("19005", 19, "Design", "Dependency Direction",
           "Point your code at what it needs, not at what happens to it.",
           ["Explain why depending on an interface is safer than depending on a class.",
            "Inject a collaborator instead of creating it inside.",
            "Name the practical benefit in tests."],
           [exp("The direction of knowing\n\n"
                "If a class constructs its own database object, it depends on that "
                "concrete class forever. It cannot be tested without the database, and the "
                "database cannot be replaced.\n\n"
                "If the collaborator is an interface supplied from outside, the class "
                "depends only on the promise. In a test it can be given a fake; in "
                "production, the real one.\n\n"
                "This is sometimes called dependency injection, which sounds grander than "
                "it is: it means passing in what you need instead of building it on the "
                "spot."),
            dfn("Dependency injection", "Supplying an object's collaborators from outside "
                                        "rather than constructing them inside, so they "
                                        "can be replaced."),
            exp("A fake clock makes time testable\n\n"
                "Clock is an interface with now(). RealClock returns a fixed value here for "
                "clarity; in a program it would read the system clock. The report depends "
                "on the interface, so a test can supply a controlled time and get a "
                "predictable timestamp.\n\n"
                "That is the whole benefit: the test controls the input that reality would "
                "otherwise decide."),
            code('''#include <iostream>
#include <memory>
#include <string>

class Clock {
public:
    virtual ~Clock() = default;
    virtual int now() const = 0;
};

class FixedClock : public Clock {
public:
    explicit FixedClock(int value) : value_(value) {}
    int now() const override { return value_; }
private:
    int value_;
};

class Timestamp {
public:
    explicit Timestamp(const Clock& clock) : clock_(clock) {}
    std::string stamp() const { return "at " + std::to_string(clock_.now()); }
private:
    const Clock& clock_;
};

int main() {
    FixedClock morning(9);
    FixedClock evening(21);
    Timestamp first(morning);
    Timestamp second(evening);
    std::cout << first.stamp() << "\\n";
    std::cout << second.stamp() << "\\n";
    return 0;
}
''', '''at 9
at 21'''),
            exp("The cost, honestly\n\n"
                "An interface per collaborator is more types to write, and a pointer or "
                "reference to thread through the constructors. For a fifty-line program "
                "that is pure overhead.\n\n"
                "The cost is worth paying at the boundary where the outside world lives: "
                "the clock, the file system, the network, the user. Those are the things "
                "that make tests slow and flaky, so those are the things to inject."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>

class Greeter {
public:
    explicit Greeter(std::string name) : name_(std::move(name)) {}
    std::string greet() const { return "hello " + name_; }
private:
    std::string name_;
};

int main() {
    Greeter greeter("ada");
    std::cout << greeter.greet() << "\\n";
    return 0;
}
''', '''hello ada'''),
            quiz("What does injecting a collaborator let a test do?",
                 ["Run faster than light", "Supply a controlled version, such as a fixed "
                  "clock", "Remove the interface", "Avoid linking"],
                 1, "The test decides what the collaborator returns, so the outcome is "
                    "predictable without the real dependency."),
           ]),

    lesson("19006", 19, "Design", "Errors Across Layers",
           "Each layer decides what it can handle and passes the rest up unchanged.",
           ["Translate an error at a layer boundary.",
            "Keep one error type per layer rather than mixing them.",
            "Explain why a layer should not swallow a failure."],
           [exp("Who can do something about it\n\n"
                "A low layer knows that a file did not open. It does not know what the "
                "user should be told, whether to retry, or whether the program should "
                "stop. Those are the caller's decisions.\n\n"
                "So the low layer throws or returns a failure, and the layer that owns the "
                "decision handles it. A layer in between either passes it up unchanged or "
                "wraps it in its own type, adding context without losing the original.\n\n"
                "The one thing a layer must not do is swallow an error and carry on as if "
                "the work had succeeded."),
            dfn("Layer boundary", "The point where one part of a program hands work to "
                                  "another, and where error types are translated."),
            exp("A wrapped error keeps its cause\n\n"
                "The loader throws a plain error. The service catches it and throws its "
                "own type, mentioning the operation. The user interface catches the "
                "service error and prints a message for a human.\n\n"
                "Nothing is lost: the message still says what failed and why."),
            code('''#include <iostream>
#include <stdexcept>
#include <string>

struct LoadError : std::runtime_error {
    explicit LoadError(const std::string& text) : std::runtime_error(text) {}
};

struct ServiceError : std::runtime_error {
    explicit ServiceError(const std::string& text) : std::runtime_error(text) {}
};

std::string load_data(bool present) {
    if (!present) {
        throw LoadError("file missing");
    }
    return "rows";
}

std::string load_report(bool present) {
    try {
        return load_data(present);
    } catch (const LoadError& error) {
        throw ServiceError(std::string("could not build the report: ") + error.what());
    }
}

int main() {
    try {
        load_report(false);
    } catch (const ServiceError& error) {
        std::cout << "shown to user: " << error.what() << "\\n";
    }
    std::cout << "success path: " << load_report(true) << "\\n";
    return 0;
}
''', '''shown to user: could not build the report: file missing
success path: rows'''),
            exp("The swallow that hides a bug\n\n"
                "A catch that logs and continues is the most expensive mistake in "
                "error handling. The caller believes the work succeeded, the data is "
                "wrong, and the evidence is in a log nobody reads.\n\n"
                "If a layer catches, it must either handle the failure completely or "
                "rethrow. Logging and carrying on is neither."),
            CHALLENGE,
            code('''#include <iostream>
#include <stdexcept>

int read_count(int supplied) {
    if (supplied < 0) {
        throw std::invalid_argument("count cannot be negative");
    }
    return supplied;
}

int main() {
    try {
        std::cout << read_count(-2) << "\\n";
    } catch (const std::invalid_argument& error) {
        std::cout << "rejected: " << error.what() << "\\n";
    }
    std::cout << read_count(4) << "\\n";
    return 0;
}
''', '''rejected: count cannot be negative
4'''),
            quiz("What should a layer do with an error it cannot handle?",
                 ["Log it and continue", "Convert it to a default value",
                  "Pass it up, unchanged or wrapped with context", "Ignore it"],
                 1, "Passing it up keeps the decision with the layer that owns it; "
                    "swallowing it turns a visible failure into wrong data."),
           ]),

    lesson("19007", 19, "Design", "Testing a Layered Program",
           "Test the middle layers with fakes; test the edges rarely.",
           ["Write a fake for an interface collaborator.",
            "Test a layer without touching the file system.",
            "Explain why the fake belongs in the test file."],
           [exp("Where the tests belong\n\n"
                "The layer that holds your logic is where the bugs are, and it should be "
                "testable without a file, a clock or a user. That is what the injected "
                "interfaces from the previous lesson were for.\n\n"
                "A fake is a small implementation of the interface that returns a value "
                "you chose. It lives in the test, so it can be as simple and as wrong as "
                "the test needs.\n\n"
                "The edges - the real file read, the real clock - get one or two tests "
                "each, because they are thin and slow."),
            dfn("Fake", "A test-only implementation of an interface that returns "
                        "controlled values, so a layer can be tested without its real "
                        "dependencies."),
            exp("A service tested through a fake\n\n"
                "Storage is the interface: the service only asks for a count. FakeStorage "
                "returns a chosen number, so the test can check the summary logic without "
                "any disk access.\n\n"
                "Two fakes, two outcomes, one function under test. This is what makes the "
                "logic layer worth having."),
            code('''#include <iostream>
#include <string>

class Storage {
public:
    virtual ~Storage() = default;
    virtual int rows() const = 0;
};

class FakeStorage : public Storage {
public:
    explicit FakeStorage(int value) : value_(value) {}
    int rows() const override { return value_; }
private:
    int value_;
};

std::string summarise(const Storage& storage) {
    int count = storage.rows();
    if (count == 0) {
        return "no data";
    }
    return std::to_string(count) + " rows";
}

void check(const std::string& actual, const std::string& expected, const char* name) {
    std::cout << (actual == expected ? "PASS " : "FAIL ") << name << "\\n";
}

int main() {
    FakeStorage empty(0);
    FakeStorage some(12);
    check(summarise(empty), "no data", "empty summary");
    check(summarise(some), "12 rows", "row summary");
    return 0;
}
''', '''PASS empty summary
PASS row summary'''),
            exp("The test that needs no disk\n\n"
                "Nothing in this test opens a file, reads the clock or waits. It runs in "
                "microseconds and it fails for exactly one reason when it fails.\n\n"
                "That combination - fast and precise - is why the fake is worth writing. A "
                "test that needs the real file system is slow and fails for several "
                "reasons at once."),
            CHALLENGE,
            code('''#include <iostream>

class Clock {
public:
    virtual ~Clock() = default;
    virtual int hour() const = 0;
};

class FakeClock : public Clock {
public:
    explicit FakeClock(int hour) : hour_(hour) {}
    int hour() const override { return hour_; }
private:
    int hour_;
};

std::string greeting(const Clock& clock) {
    return clock.hour() < 12 ? "good morning" : "good afternoon";
}

int main() {
    FakeClock morning(8);
    FakeClock afternoon(15);
    std::cout << greeting(morning) << "\\n";
    std::cout << greeting(afternoon) << "\\n";
    return 0;
}
''', '''good morning
good afternoon'''),
            quiz("Why does a fake live in the test rather than in the program?",
                 ["It would be too slow", "It exists only to control a test, and the "
                  "program must never use it", "The linker forbids it",
                  "It needs the network"],
                 1, "A fake is a test double: simple, deliberate, and never shipped, so "
                    "nothing in production can accidentally depend on it."),
           ]),

    lesson("19008", 19, "Design", "A Worked Design",
           "Take one small requirement and separate it into parts you can name.",
           ["Turn a requirement into three named parts.",
            "Decide which part holds the logic.",
            "Predict the output of the assembled program."],
           [exp("Reading the requirement\n\n"
                "'Read temperature readings, ignore invalid ones, report the average' has "
                "three parts: reading, judging, reporting. Naming them is most of the "
                "design.\n\n"
                "The reading part is the edge: it deals with input and can be replaced by "
                "a fake. The judging part holds the rule and is pure. The reporting part "
                "produces text and is trivial to check.\n\n"
                "Notice what was not done: no base classes for the sake of it, no "
                "interface with one implementation. Three functions, each with one "
                "reason to exist."),
            dfn("Cohesion", "How strongly the parts of one function or class belong "
                            "together. A function with one job is cohesive and easy to "
                            "name."),
            exp("The three parts assembled\n\n"
                "valid() is a pure rule, average() is a pure calculation, and main connects "
                "them with a small list standing in for the reader.\n\n"
                "Every part can be tested with values written by hand. The program is "
                "small, and the shape would survive growing to a thousand lines."),
            code('''#include <iostream>
#include <vector>

bool valid(int reading) {
    return reading >= -50 && reading <= 60;
}

double average(const std::vector<int>& readings) {
    if (readings.empty()) {
        return 0.0;
    }
    int total = 0;
    for (int reading : readings) {
        total += reading;
    }
    return static_cast<double>(total) / static_cast<double>(readings.size());
}

int main() {
    std::vector<int> raw{20, -100, 22, 24, 999};
    std::vector<int> accepted;
    int rejected = 0;
    for (int reading : raw) {
        if (valid(reading)) {
            accepted.push_back(reading);
        } else {
            ++rejected;
        }
    }
    std::cout << "accepted " << accepted.size() << ", rejected " << rejected << "\\n";
    std::cout << "average " << average(accepted) << "\\n";
    return 0;
}
''', '''accepted 3, rejected 2
average 22'''),
            exp("What would change as it grows\n\n"
                "The reader becomes a function taking a filename, and it is the only part "
                "that changes. The rule and the calculation stay exactly as they are, "
                "which is the return on separating them.\n\n"
                "That is the test of a design: which parts will move when the requirement "
                "moves, and can you name them now."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

double mean(const std::vector<int>& values) {
    if (values.empty()) {
        return 0.0;
    }
    int total = 0;
    for (int value : values) {
        total += value;
    }
    return static_cast<double>(total) / static_cast<double>(values.size());
}

int main() {
    std::cout << mean({2, 4, 6}) << "\\n";
    std::cout << mean({}) << "\\n";
    return 0;
}
''', '''4
0'''),
            quiz("What is the sign of a design that will survive growth?",
                 ["It has many base classes",
                  "Its parts can be named by the job they do, and you can say which will "
                  "change",
                  "It is all in one function", "It uses threads"],
                 1, "Named responsibilities and a clear idea of which parts move with the "
                    "requirement are what make later change cheap."),
           ]),
]
