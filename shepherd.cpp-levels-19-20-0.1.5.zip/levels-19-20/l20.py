"""Level 20 — Mastery and Capstone."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("20001", 20, "Library mastery", "Time with chrono",
           "Measure elapsed time properly, and keep the clock behind an interface.",
           ["Use steady_clock to measure an interval.",
            "Explain why a steady clock is not a wall clock.",
            "Convert a duration to milliseconds."],
           [exp("Two kinds of clock\n\n"
                "system_clock reports calendar time and can jump backwards when the "
                "machine synchronises or the user changes the setting. steady_clock only "
                "moves forward, so it is the one for measuring intervals.\n\n"
                "A duration carries its own unit, so no floating-point arithmetic is "
                "needed to convert between seconds and milliseconds.\n\n"
                "The idiom is: take a start, do the work, take an end, subtract."),
            dfn("steady_clock", "A clock that never goes backwards, used for measuring "
                                "elapsed time. It says nothing about the date."),
            def_ := dfn("Duration", "A time span with a unit, such as milliseconds or "
                                    "seconds. Converting between units is exact."),
            exp("Measuring a span\n\n"
                "The difference between two time_points is a duration, and "
                "duration_cast makes the unit explicit. The measurement is real, and its "
                "value depends on the machine - which is the lesson from Level 18 about "
                "timing being the weakest evidence.\n\n"
                "That is why this example prints facts about the measurement rather than "
                "a number that could differ on your computer."),
            code('''#include <chrono>
#include <iostream>
#include <thread>

int main() {
    auto start = std::chrono::steady_clock::now();
    std::this_thread::sleep_for(std::chrono::milliseconds(20));
    auto end = std::chrono::steady_clock::now();
    auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(end - start);
    std::cout << (elapsed.count() >= 20 ? "at least 20 ms" : "shorter than 20 ms") << "\\n";
    std::cout << (elapsed.count() < 2000 ? "finished quickly" : "took too long") << "\\n";
    return 0;
}
''', '''at least 20 ms
finished quickly'''),
            exp("Sleeping and waiting\n\n"
                "this_thread::sleep_for parks the thread for a duration, and does not "
                "spin, so it costs no processor time. sleep_until waits for a specific "
                "point.\n\n"
                "In a program, sleeping is almost always the wrong tool: it makes the "
                "program guess how long work takes. Waiting for a result, a condition "
                "variable or a join is how the program waits for the actual event."),
            CHALLENGE,
            code('''#include <chrono>
#include <iostream>

int main() {
    std::chrono::milliseconds span(1500);
    auto seconds = std::chrono::duration_cast<std::chrono::seconds>(span);
    std::cout << span.count() << " ms\\n";
    std::cout << seconds.count() << " s when truncated\\n";
    return 0;
}
''', '''1500 ms
1 s when truncated'''),
            quiz("Which clock is correct for measuring how long a function took?",
                 ["system_clock", "steady_clock", "The wall clock", "Any of them"],
                 1, "steady_clock never jumps, so the difference between two readings is "
                    "an honest interval."),
           ]),

    lesson("20002", 20, "Library mastery", "Paths and Files with filesystem",
           "Path arithmetic, existence checks and directory listings without a platform API.",
           ["Join and inspect paths with std::filesystem::path.",
            "Test existence and file size.",
            "Explain what a path is not."],
           [exp("A path is text with rules\n\n"
                "std::filesystem::path understands separators, extensions and parent "
                "directories on every platform, so you do not write ifdefs for Windows "
                "and Linux.\n\n"
                "Joining is done with the / operator, which inserts the right separator. "
                "filename(), extension() and parent_path() answer questions about the "
                "text without touching a disk.\n\n"
                "A path is not a file. Whether anything exists at that path is a separate "
                "question, and one that can change a microsecond after you ask it."),
            dfn("path", "An object holding a file system location, with operations for "
                        "joining and taking it apart in a portable way."),
            exp("Path arithmetic, no disk needed\n\n"
                "The joins and the queries below work entirely on the text, so the example "
                "running anywhere says nothing about your disk.\n\n"
                "Only exists() and file_size() ask the file system, and both can fail or "
                "change between the question and the use."),
            code('''#include <filesystem>
#include <iostream>

int main() {
    std::filesystem::path root("data");
    auto file = root / "report.txt";
    std::cout << file.generic_string() << "\\n";
    std::cout << file.filename().string() << "\\n";
    std::cout << file.extension().string() << "\\n";
    std::cout << file.parent_path().string() << "\\n";
    std::cout << (file.is_absolute() ? "absolute" : "relative") << "\\n";
    return 0;
}
''', '''data/report.txt
report.txt
.txt
data
relative'''),
            exp("Asking the disk\n\n"
                "exists() and file_size() are the only calls that need real files. They "
                "can throw or report an error, and the answer can be stale immediately "
                "afterwards, so they are worth wrapping in the same kind of error handling "
                "you met in Level 12.\n\n"
                "create_directories does nothing if the directory already exists, which "
                "makes it safe to call on every run."),
            CHALLENGE,
            code('''#include <filesystem>
#include <iostream>

int main() {
    std::filesystem::path folder = std::filesystem::temp_directory_path() / "academy_demo";
    bool created = std::filesystem::create_directories(folder);
    std::cout << "exists: " << (std::filesystem::exists(folder) ? "yes" : "no") << "\\n";
    std::cout << "created now: " << (created ? "yes" : "already there") << "\\n";
    std::filesystem::remove_all(folder);
    std::cout << "removed\\n";
    return 0;
}
''', '''exists: yes
created now: yes
removed'''),
            quiz("What does the / operator do on two paths?",
                 ["Opens a file", "Joins them with the platform's separator",
                  "Divides their sizes", "Compares them"],
                 1, "It joins, inserting the correct separator for the platform."),
           ]),

    lesson("20003", 20, "Library mastery", "Randomness with random",
           "A generator and a distribution, and why rand() is not good enough.",
           ["Seed and use a random engine.",
            "Shape the output with a distribution.",
            "Explain why a fixed seed is useful in tests."],
           [exp("Engine and distribution\n\n"
                "The engine produces a stream of unpredictable bits; the distribution "
                "shapes them into numbers in the range you want. They are separate "
                "concerns, and mixing them is why rand() % 10 is a bad habit.\n\n"
                "mt19937 is the standard choice: fast, well tested, and with a long "
                "period. Seeding it from random_device gives different runs; seeding it "
                "with a constant gives the same run every time.\n\n"
                "A fixed seed is not a bug in a test. It makes randomness reproducible, so "
                "a failure can be investigated."),
            dfn("Engine", "The source of random bits, such as std::mt19937."),
            def_dist := dfn("Distribution", "A rule that maps the engine's output to a "
                                            "range or a shape, such as uniform_int_distribution."),
            exp("Reproducible randomness\n\n"
                "Two engines seeded with 42 produce identical sequences, which is what the "
                "example shows. That property is how a test involving randomness becomes "
                "deterministic.\n\n"
                "In a game or a simulation, seed from std::random_device instead, and "
                "every run differs."),
            code('''#include <iostream>
#include <random>

int main() {
    std::mt19937 first(42);
    std::mt19937 second(42);
    std::uniform_int_distribution<int> dice(1, 6);
    bool same = true;
    for (int i = 0; i < 5; ++i) {
        int a = dice(first);
        int b = dice(second);
        if (a != b) {
            same = false;
        }
        std::cout << a << " ";
    }
    std::cout << "\\n";
    std::cout << (same ? "same seed, same sequence" : "sequences differ") << "\\n";
    return 0;
}
''', '''3 5 6 2 5 
same seed, same sequence'''),
            exp("Shaping the output\n\n"
                "A uniform_int_distribution gives every value in its range an equal "
                "chance, with no modulo bias. A uniform_real_distribution does the same "
                "for doubles.\n\n"
                "Keep the engine alive between uses. Constructing a new engine in a loop "
                "reseeded from the clock produces repeated values, which is a classic "
                "and confusing bug."),
            CHALLENGE,
            code('''#include <iostream>
#include <random>

int main() {
    std::mt19937 engine(7);
    std::uniform_int_distribution<int> range(10, 20);
    int low = 100;
    int high = -100;
    for (int i = 0; i < 100; ++i) {
        int value = range(engine);
        if (value < low) { low = value; }
        if (value > high) { high = value; }
    }
    std::cout << "within range: " << (low >= 10 && high <= 20 ? "yes" : "no") << "\\n";
    return 0;
}
''', '''within range: yes'''),
            quiz("Why is rand() % 10 worse than a uniform distribution?",
                 ["It is slower", "It skews the results, favouring some values",
                  "It needs a seed", "It returns doubles"],
                 1, "Taking a remainder from a range that is not a multiple of 10 makes "
                    "some outcomes slightly more likely."),
           ]),

            lesson("20004", 20, "Library mastery", "Algorithms Worth Knowing",
           "The dozen standard algorithms that replace most hand-written loops.",
           ["Use count_if, any_of and all_of.",
            "Remove elements with the erase-remove idiom.",
            "Explain why the library loop is less likely to be wrong."],
           [exp("A vocabulary of loops\n\n"
                "Most hand-written loops are one of a few shapes: does any element match, "
                "do all of them, how many, find the first, remove the ones that match. The "
                "library has a name for each.\n\n"
                "Using the name removes the three places a loop can be wrong - the start, "
                "the end, and the increment - and it says what the code means instead of "
                "how it works.\n\n"
                "any_of, all_of and none_of also short-circuit, so they stop at the first "
                "answer rather than examining everything."),
            def_any := dfn("Predicate", "A function returning bool, passed to an algorithm "
                                        "to decide something about each element."),
            exp("Three questions, three names\n\n"
                "any_even stops at the first even value, all_positive must examine every "
                "value before answering true, and count_if examines all of them by nature.\n\n"
                "Each is one line and each has an obvious meaning to a reader who has seen "
                "the name before."),
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{3, 8, 5, 12};
    std::cout << (std::any_of(values.begin(), values.end(),
                              [](int v) { return v % 2 == 0; }) ? "has an even" : "all odd")
              << "\\n";
    std::cout << (std::all_of(values.begin(), values.end(),
                              [](int v) { return v > 0; }) ? "all positive" : "some negative")
              << "\\n";
    std::cout << std::count_if(values.begin(), values.end(),
                               [](int v) { return v > 4; }) << " above four\\n";
    return 0;
}
''', '''has an even
all positive
3 above four'''),
            exp("Removing from a vector\n\n"
                "remove_if does not remove anything: it moves the unwanted elements to "
                "the end and returns the new logical end. erase then cuts the tail off.\n\n"
                "Written separately, each half is wrong: remove_if alone leaves the "
                "container the same size, and erasing in a loop invalidates the "
                "iterators. The idiom is two lines and always correct."),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{1, 2, 3, 4, 5, 6};
    auto new_end = std::remove_if(values.begin(), values.end(),
                                  [](int v) { return v % 2 == 1; });
    values.erase(new_end, values.end());
    for (int value : values) {
        std::cout << value << " ";
    }
    std::cout << "\\n" << values.size() << " left\\n";
    return 0;
}
''', '''2 4 6 
3 left'''),
            quiz("What does remove_if actually do?",
                 ["Deletes the matching elements from the container",
                  "Moves the kept elements forward and returns the new end",
                  "Sorts the container", "Returns a count"],
                 1, "It rearranges, it does not resize: the container is unchanged until "
                    "erase cuts off the tail."),
           ]),

    lesson("20005", 20, "Design", "Type Erasure and Generic Boundaries",
           "Know when to write a template and when to hide the type behind an interface.",
           ["Choose between a template and an interface.",
            "Explain what a template costs at compile time.",
            "Describe type erasure in one sentence."],
           [exp("Two ways to be general\n\n"
                "A template is general at compile time: the compiler generates code for "
                "each type you use, so there is no run-time cost and no indirection. The "
                "price is compile time and code size, and the type must be known where it "
                "is used.\n\n"
                "An interface with virtual functions is general at run time: one "
                "implementation handles any derived type, but each call goes through a "
                "pointer and the types must share a base class.\n\n"
                "std::function is the third option: a value that can hold any callable "
                "without a common base, built by erasing the type. It is convenient and "
                "allocates, so it is chosen when the convenience matters."),
            def_ := dfn("Type erasure", "Hiding a concrete type behind a fixed interface so "
                                        "different types can be stored and used "
                                        "uniformly, decided at run time."),
            exp("The same job three ways\n\n"
                "A template sorts by type at compile time, an interface dispatches at run "
                "time, and std::function stores any callable of a given signature.\n\n"
                "The example shows the third, because it is the one that is easy to "
                "misuse: the callable has state and is copied, so a large lambda captures "
                "a large copy."),
            code('''#include <functional>
#include <iostream>
#include <vector>

int apply(const std::function<int(int)>& step, int value) {
    return step(value);
}

int main() {
    int offset = 5;
    auto add_offset = [offset](int value) { return value + offset; };
    std::vector<std::function<int(int)>> steps;
    steps.push_back(add_offset);
    steps.push_back([](int value) { return value * 2; });
    int result = 1;
    for (const auto& step : steps) {
        result = apply(step, result);
    }
    std::cout << result << "\\n";
    return 0;
}
''', '''12'''),
            exp("The rule of thumb\n\n"
                "Write a template when the code is the same for every type and the type "
                "is known where it is used: containers, algorithms, math.\n\n"
                "Use an interface when the types vary at run time or live in a plugin "
                "boundary. Use std::function when the thing being stored is a single "
                "action. Choosing the wrong one is not a correctness bug; it is a cost "
                "paid on every build or every call."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <vector>

template <typename T>
T larger(T a, T b) {
    return a > b ? a : b;
}

int main() {
    std::cout << larger(3, 9) << "\\n";
    std::cout << larger(std::string("apple"), std::string("pear")) << "\\n";
    return 0;
}
''', '''9
pear'''),
            quiz("What is the main cost of choosing a template?",
                 ["A run-time pointer indirection", "Compile time and code size for each "
                  "type used", "An allocation per call", "A virtual destructor"],
                 1, "Each instantiation is generated code, which is why templates cost at "
                    "build time rather than at run time."),
           ]),

    lesson("20006", 20, "Capstone", "The Capstone: Read the Requirement",
           "One small program, specified in writing before a line of code.",
           ["Turn a requirement into a written specification.",
            "Name the parts and their responsibilities.",
            "List the tests before writing any."],
           [exp("The requirement\n\n"
                "A reading log: each entry has a title and a score from 0 to 100. The "
                "program must accept entries, reject invalid ones, and report the count, "
                "the average and the highest score.\n\n"
                "That is the whole brief. Four sentences, and already there are decisions "
                "to make: what counts as invalid, what happens with no entries, and "
                "whether the average is rounded.\n\n"
                "Writing those decisions down before coding is the difference between a "
                "program that does what was asked and one that does what was assumed."),
            def_ := dfn("Specification", "A written statement of what the program must do, "
                                         "including the cases that are usually left to "
                                         "chance: empty input, invalid input, rounding."),
            exp("Decisions made explicit\n\n"
                "The decisions for this capstone, written before the code: a title must be "
                "non-empty; a score outside 0 to 100 is rejected; with no entries the "
                "average is 0 and the highest is 0; the average is printed with one "
                "decimal.\n\n"
                "Each decision becomes a test. That is the point of writing them down: "
                "they stop being opinions later."),
            code('''#include <iostream>

int main() {
    std::cout << "spec: title non-empty\\n";
    std::cout << "spec: score in 0..100\\n";
    std::cout << "spec: no entries means 0 and 0\\n";
    std::cout << "spec: average with one decimal\\n";
    return 0;
}
''', '''spec: title non-empty
spec: score in 0..100
spec: no entries means 0 and 0
spec: average with one decimal'''),
            exp("The shape of what comes next\n\n"
                "Four lessons remain: structure, implementation, tests, and review. Each "
                "one adds to the same small program rather than starting a new idea.\n\n"
                "The tests written here drive the implementation, not the other way "
                "round."),
            CHALLENGE,
            code('''#include <iostream>

int main() {
    std::cout << "parts: entry, log, report\\n";
    std::cout << "edge cases: 0, 5\\n";
    return 0;
}
''', '''parts: entry, log, report
edge cases: 0, 5'''),
            quiz("Why decide the empty and invalid cases before writing code?",
                 ["To save typing", "Because they are the cases the code will otherwise "
                  "decide by accident", "Because the compiler requires it",
                  "To make the program faster"],
                 1, "Left undecided, edge cases get whatever behaviour the first "
                    "implementation happens to produce, and that becomes the "
                    "specification by default."),
           ]),

    lesson("20007", 20, "Capstone", "The Capstone: Structure",
           "Three types and four functions, named before they are written.",
           ["Split a requirement into types and functions.",
            "Keep validation with the data it protects.",
            "Predict the output of the assembled structure."],
           [exp("Naming the parts\n\n"
                "Entry holds a title and a score. Log holds a collection of entries and "
                "the rule for accepting one. Report computes and prints the three numbers.\n\n"
                "Validation belongs with Entry, because that is the type that must never "
                "exist in an invalid state. If the rule lives in the caller, one caller "
                "will eventually forget it.\n\n"
                "Four functions: accept, count, average, highest. Each returns a value, so "
                "each can be tested without printing anything."),
            def_ := dfn("Invariant", "Something that must always be true about a type, "
                                     "such as an entry's score lying between 0 and 100."),
            exp("The structure in code\n\n"
                "make_entry returns an optional, so an invalid entry simply does not exist. "
                "Log::accept uses it, and the report functions are pure queries.\n\n"
                "Nothing here prints except the last few lines of main, which keeps every "
                "part testable."),
            code('''#include <iostream>
#include <optional>
#include <string>
#include <vector>

struct Entry {
    std::string title;
    int score = 0;
};

std::optional<Entry> make_entry(const std::string& title, int score) {
    if (title.empty() || score < 0 || score > 100) {
        return std::nullopt;
    }
    return Entry{title, score};
}

int main() {
    auto good = make_entry("first", 80);
    auto bad_title = make_entry("", 80);
    auto bad_score = make_entry("second", 101);
    std::cout << (good ? "accepted" : "rejected") << "\\n";
    std::cout << (bad_title ? "accepted" : "rejected") << "\\n";
    std::cout << (bad_score ? "accepted" : "rejected") << "\\n";
    return 0;
}
''', '''accepted
rejected
rejected'''),
            exp("The queries\n\n"
                "count, average and highest each take the collection and return a number. "
                "The empty case is answered inside each one, so no caller has to remember "
                "it.\n\n"
                "Returning a value rather than printing is what makes them testable, and "
                "it is the same rule from Level 15 about keeping logic out of main."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

int count(const std::vector<int>& values) {
    return static_cast<int>(values.size());
}

[[maybe_unused]] double average(const std::vector<int>& values) {
    if (values.empty()) {
        return 0.0;
    }
    int total = 0;
    for (int value : values) {
        total += value;
    }
    return static_cast<double>(total) / static_cast<double>(values.size());
}

int main() {
    std::vector<int> values{80, 90};
    std::cout << count(values) << " entries\\n";
    std::cout << average(values) << " average\\n";
    return 0;
}
''', '''2 entries
85 average'''),
            quiz("Where should the rule for a valid score live?",
                 ["In main", "With the type it protects, so no caller can forget it",
                  "In a comment", "In the test file only"],
                 1, "A type with an invariant keeps its own guard, which is the only way "
                    "every caller inherits it."),
           ]),

    lesson("20008", 20, "Capstone", "The Capstone: Tests and Review",
           "Prove the program, then read it as a stranger would.",
           ["Test the specification's four decisions.",
            "Read the code against a review checklist.",
            "Decide when the program is finished."],
           [exp("The tests come from the specification\n\n"
                "Four decisions were written down, so there are four checks: a good entry "
                "is accepted, an empty title is rejected, a score of 101 is rejected, and "
                "an empty log reports 0 and 0.\n\n"
                "They are written against the functions, not against printed text, so "
                "they stay valid if the output format changes.\n\n"
                "That is the whole discipline of this course in one place: decide, "
                "implement, prove."),
            def_ := dfn("Review checklist", "A short list read before calling work "
                                            "finished: names, ownership, errors, tests, "
                                            "and whether main is thin."),
            exp("The four checks\n\n"
                "Each check prints PASS or FAIL and names what it tested, and the program "
                "returns non-zero if anything failed so a script can tell.\n\n"
                "Add the report queries and the program has a specification, an "
                "implementation and a proof that agree with each other."),
            code('''#include <iostream>
#include <optional>
#include <string>

struct Entry {
    std::string title;
    int score = 0;
};

std::optional<Entry> make_entry(const std::string& title, int score) {
    if (title.empty() || score < 0 || score > 100) {
        return std::nullopt;
    }
    return Entry{title, score};
}

double average_of(int total, int count) {
    if (count == 0) {
        return 0.0;
    }
    return static_cast<double>(total) / static_cast<double>(count);
}

int failures = 0;

void check(bool actual, const char* name) {
    std::cout << (actual ? "PASS " : "FAIL ") << name << "\\n";
    if (!actual) {
        ++failures;
    }
}

int main() {
    check(make_entry("first", 80).has_value(), "good entry accepted");
    check(!make_entry("", 80).has_value(), "empty title rejected");
    check(!make_entry("second", 101).has_value(), "score above 100 rejected");
    check(average_of(0, 0) == 0.0, "empty log reports zero");
    return failures == 0 ? 0 : 1;
}
''', '''PASS good entry accepted
PASS empty title rejected
PASS score above 100 rejected
PASS empty log reports zero'''),
            exp("The review, and the end\n\n"
                "Read back: does every name say what it does, does every type protect its "
                "own invariant, is main thin, is every failure visible, does every written "
                "decision have a test?\n\n"
                "When the answers are yes, the program is finished - not when it has more "
                "features. That habit is what Level 20 is for, and it is the one worth "
                "carrying into everything after this course."),
            CHALLENGE,
            code('''#include <iostream>

int main() {
    const char* checklist[] = {"names say what they do", "types protect invariants",
                               "main is thin", "failures are visible",
                               "decisions have tests"};
    int done = 0;
    for (const char* item : checklist) {
        std::cout << "checked: " << item << "\\n";
        ++done;
    }
    std::cout << done << " of 5 reviewed\\n";
    return 0;
}
''', '''checked: names say what they do
checked: types protect invariants
checked: main is thin
checked: failures are visible
checked: decisions have tests
5 of 5 reviewed'''),
            quiz("When is a small program finished?",
                 ["When it has the most features", "When every decision in the "
                  "specification has a test that passes", "When it compiles",
                  "When it is under 100 lines"],
                 1, "The specification, the implementation and the proof agreeing is what "
                    "finished means."),
           ]),
]
