"""Assemble shepherd.cpp-levels-21-23 from the three level modules."""
import json
from pathlib import Path

import l21a, l21b, l21c
from kit import CID, VERSION

LESSON_GROUPS = l21a.LESSONS + l21b.LESSONS + l21c.LESSONS

MODULE_TITLES = {
    96: "Level 21 — The Memory Model and Undefined Behaviour",
    97: "Level 22 — Memory Layout",
    98: "Level 23 — Object Lifetime",
}

def normalise(entry):
    """Prose must contain real newlines. A literal backslash-n would be printed."""
    for block in entry["body"]:
        if block.get("kind") in {"explanation", "definition"}:
            for field in ("text",):
                value = block.get(field)
                if isinstance(value, str) and "\\n" in value:
                    block[field] = value.replace("\\n", "\n")
    return entry


lessons = []
for index, entry in enumerate(LESSON_GROUPS, 1):
    entry = normalise(dict(entry))
    level = entry.pop("_level")
    topic = entry.pop("_topic")
    entry["prerequisites"] = [lessons[-1]["id"]] if lessons else []
    entry["_level"] = level
    entry["_topic"] = topic
    lessons.append(entry)

items = [{
    "id": CID,
    "kind": "course",
    "title": "C++ Memory Model and Object Lifetime — Levels 21–23",
    "revision": 1,
    "summary": "16 lessons on what the standard actually promises: storage duration and "
               "object lifetime, happens-before and data races, relaxed, acquire-release and "
               "sequential consistency, undefined behaviour and how to detect it, the five "
               "regions of a program, stack frames, static initialisation order, object "
               "sizing, construction and destruction order, temporaries, storage reuse and "
               "unions.",
    "objectives": ["Reason about happens-before rather than hoping the timing works out.",
                   "Choose a memory order deliberately, and know why volatile is not one.",
                   "Recognise undefined behaviour and the tools that find it.",
                   "Say where each of your objects lives and what it costs.",
                   "Explain when an object begins and ends, and what reuses its storage."],
    "difficulty": "advanced",
    "estimated_minutes": 600,
}]
items.append({"id": f"{CID}.section.001", "kind": "section",
              "title": "Revision and Gap Fill", "revision": 1, "parent_id": CID})

topic_ids = {}
module_ids = {}

for entry in lessons:
    level, topic = entry.pop("_level"), entry.pop("_topic")
    if level not in module_ids:
        module_id = f"{CID}.module.{level:03d}"
        module_ids[level] = module_id
        items.append({"id": module_id, "kind": "module", "title": MODULE_TITLES[level],
                      "revision": 1, "parent_id": f"{CID}.section.001"})
    if (level, topic) not in topic_ids:
        number = sum(1 for (other_level, _) in topic_ids if other_level == level) + 1
        topic_id = f"{CID}.topic.{level}{number:02d}"
        topic_ids[(level, topic)] = topic_id
        items.append({"id": topic_id, "kind": "topic", "title": topic,
                      "revision": 1, "parent_id": module_ids[level]})
    entry["parent_id"] = topic_ids[(level, topic)]
    items.append(entry)

manifest = {
    "schema_version": 2,
    "format": "shepherd.course",
    "id": CID,
    "module_id": "programming-languages",
    "version": VERSION,
    "locale": "en",
    "subjects": [{"id": "programming-languages", "category": "language"}],
    "authors": ["Shepherd Coding Academy"],
    "license": "MIT",
    "authoring": {
        "specification_id": CID + ".spec",
        "specification_version": "1.0.0",
        "allocations": [{
            "batch_id": CID + ".batch.001",
            "section_id": CID + ".section.001",
            "allowed_ids": [item["id"] for item in items],
        }],
    },
    "batches": [{
        "id": CID + ".batch.001", "schema_version": 2, "course_id": CID,
        "specification_id": CID + ".spec", "specification_version": "1.0.0",
        "section_id": CID + ".section.001",
        "item_ids": [item["id"] for item in items],
        "author": "Shepherd Coding Academy",
    }],
    "items": items,
}
target = Path(__file__).resolve().parent / "manifest.json"
target.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
                  encoding="utf-8")
print(f"lessons: {len(lessons)} | items: {len(items)} | modules: {len(module_ids)} "
      f"| topics: {len(topic_ids)}")
