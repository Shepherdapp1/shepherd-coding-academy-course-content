"""Level 21 — the memory model, memory orders and undefined behaviour."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("92101", 96, "The Memory Model", "Objects, Storage Duration and Lifetime",
           "Three different questions about the same variable, and why mixing them up causes bugs.",
           ["Tell an object apart from its storage.",
            "Name the four storage durations.",
            "Say when an object's lifetime begins and ends."],
           [exp("Three separate things\n\n"
                "Storage is the bytes. An object is a region of storage with a type, a "
                "lifetime, and a value. They are not the same: a union holds several objects' "
                "potential storage, and a std::vector has storage for elements that do not "
                "exist yet.\n\n"
                "Storage duration says how long the storage lasts: automatic (a local "
                "variable), static (a global, or a local declared static), thread (thread_local) "
                "and dynamic (new, or an allocator).\n\n"
                "Lifetime says how long the object exists in that storage. For most types "
                "they coincide, and the interesting cases are exactly the ones in this level: "
                "raw storage being reused, and a lifetime that ends before its storage."),
            dfn("Storage duration", "How long a variable's storage lasts: automatic for locals, "
                                    "static for globals and statics, thread for thread_local, "
                                    "dynamic for allocated memory."),
            exp("Where the three durations begin\n\n"
                "A global, a local, a static local and a heap value. The static local returns 1 "
                "and then 2, which is how you know it is one object living for the whole "
                "program rather than a fresh one per call.\n\n"
                "The heap value's lifetime is exactly as long as you keep it - which here "
                "ends at the delete."),
            code('''#include <iostream>
#include <memory>

int global = 100;

int counter() {
    static int calls = 0;
    ++calls;
    return calls;
}

int main() {
    int local = 5;
    std::cout << "global " << global << ", local " << local << "\\n";

    std::cout << "static local returns " << counter() << " then " << counter()
              << " - the same object, remembered between calls\\n";

    {
        std::unique_ptr<int> heap = std::make_unique<int>(42);
        std::cout << "heap holds " << *heap << " and owns exactly that\\n";
    }
    std::cout << "the heap value was released when its scope ended\\n";
    return 0;
}
''', '''global 100, local 5
static local returns 1 then 2 - the same object, remembered between calls
heap holds 42 and owns exactly that
the heap value was released when its scope ended'''),
            exp("Lifetime is not the same as scope\n\n"
                "A local's lifetime ends when its block ends, so any pointer to it afterwards "
                "dangles - the storage may still hold the old bytes, which is what makes the "
                "bug so hard to see.\n\n"
                "The reverse happens with references returned from functions: the object dies "
                "at the return, and the caller holds a reference to storage that is about to "
                "be reused. That is the next lesson's subject."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>

struct Tracked {
    std::string name;
    explicit Tracked(std::string label) : name(std::move(label)) {
        std::cout << "constructed " << name << "\\n";
    }
    ~Tracked() { std::cout << "destroyed " << name << "\\n"; }
};

int main() {
    Tracked outer("outer");
    {
        Tracked inner("inner");
        std::cout << "inside the block\\n";
    }
    std::cout << "after the block\\n";
    return 0;
}
''', '''constructed outer
constructed inner
inside the block
destroyed inner
after the block
destroyed outer'''),
            quiz("What is the difference between storage and an object?",
                 ["Nothing, they are synonyms", "Storage is raw bytes; an object is a typed "
                  "region with a lifetime, and storage can exist with no object in it",
                  "Objects live on the heap only", "Storage is always larger"],
                 1, "A vector owns storage for elements it has not constructed yet, which is "
                    "exactly why the two are separate ideas."),
           ]),

    lesson("92102", 96, "The Memory Model", "Happens-Before and Synchronizes-With",
           "The vocabulary that decides what one thread is allowed to see of another's writes.",
           ["Explain what a data race is and why it is undefined.",
            "State what happens-before means between two operations.",
            "Name the two things that create it: a mutex or an atomic in the right order."],
           [exp("Why the compiler may reorder your code\n\n"
                "Two threads touching the same variable with no synchronisation is a data "
                "race, and a data race makes the whole program undefined - not just the "
                "variable, the program.\n\n"
                "The model is built on happens-before: if A happens before B, B sees "
                "everything A wrote. Within one thread that follows program order. Between "
                "threads it comes from synchronizes-with: unlocking a mutex synchronises with "
                "the next lock of it, and a release store synchronises with an acquire load "
                "that reads the value.\n\n"
                "Everything else is reorderable by the compiler and the CPU."),
            dfn("Data race", "Two threads accessing the same memory location concurrently, at "
                             "least one writing, with no synchronisation - which makes the "
                             "program undefined."),
            exp("A race, then a mutex\n\n"
                "The first loop adds from four threads with no lock. The total is printed "
                "anyway, but it is not guaranteed to be 4000 - that is the race.\n\n"
                "The second loop is identical except for the mutex, and its total is always "
                "4000. The lock is what creates happens-before between the four threads."),
            code('''#include <iostream>
#include <mutex>
#include <thread>
#include <vector>

int main() {
    int unguarded = 0;
    {
        std::vector<std::thread> workers;
        for (int t = 0; t < 4; ++t) {
            workers.emplace_back([&unguarded] {
                for (int i = 0; i < 1000; ++i) {
                    ++unguarded;
                }
            });
        }
        for (std::thread& worker : workers) {
            worker.join();
        }
    }
    std::cout << "unguarded total " << unguarded
              << " (any value is allowed; the program is undefined)\\n";

    int guarded = 0;
    std::mutex guard;
    {
        std::vector<std::thread> workers;
        for (int t = 0; t < 4; ++t) {
            workers.emplace_back([&guarded, &guard] {
                for (int i = 0; i < 1000; ++i) {
                    std::lock_guard<std::mutex> lock(guard);
                    ++guarded;
                }
            });
        }
        for (std::thread& worker : workers) {
            worker.join();
        }
    }
    std::cout << "guarded total " << guarded << " (always 4000)\\n";
    return 0;
}
''', '''unguarded total 4000 (any value is allowed; the program is undefined)
guarded total 4000 (always 4000)'''),
            exp("Copy the result, do not share the variable\n\n"
                "The cheapest fix is usually not a lock but a change of shape: each thread "
                "accumulates into its own local, and the main thread adds the results after "
                "the joins. join itself creates happens-before, so no lock is needed.\n\n"
                "That is the pattern behind parallel reduce, and it is worth reaching for "
                "before any mutex."),
            CHALLENGE,
            code('''#include <atomic>
#include <iostream>
#include <thread>
#include <vector>

int main() {
    std::atomic<int> shared{0};
    std::vector<std::thread> workers;
    for (int t = 0; t < 4; ++t) {
        workers.emplace_back([&shared] {
            for (int i = 0; i < 1000; ++i) {
                shared.fetch_add(1, std::memory_order_relaxed);
            }
        });
    }
    for (std::thread& worker : workers) {
        worker.join();
    }
    std::cout << "atomic total " << shared.load() << " (always 4000, no lock)\\n";
    return 0;
}
''', '''atomic total 4000 (always 4000, no lock)'''),
            quiz("Two threads write the same int with no lock or atomic. What is undefined?",
                 ["Only that variable", "The whole program, because it contains a data race",
                  "Nothing, the hardware sorts it out", "Only the final value"],
                 1, "A data race makes the entire program's behaviour undefined, not just the "
                    "raced location."),
           ]),

    lesson("92103", 96, "Memory Orders", "Relaxed Ordering",
           "Atomic, but with no ordering promises beyond the value itself.",
           ["Use memory_order_relaxed for a counter.",
            "Say what relaxed does not guarantee.",
            "Name the job relaxed ordering is actually right for."],
           [exp("Atomic without ordering\n\n"
                "Every atomic operation is indivisible: two threads adding at once still "
                "produce the right total. What relaxed ordering gives up is any promise about "
                "the order in which other memory operations become visible.\n\n"
                "So relaxed is correct for a counter, a statistic, or a sequence number - "
                "anything where only the value itself matters.\n\n"
                "It is wrong for publishing data: another thread may see the flag set before "
                "it sees the data the flag is announcing. That is what acquire and release "
                "exist for."),
            dfn("Relaxed ordering", "Atomic operations that guarantee indivisibility of the "
                                    "operation itself, with no ordering constraints on other "
                                    "memory accesses."),
            exp("A counter and a ticket dispenser\n\n"
                "Four threads each add ten, and the total is exactly 40 with no lock. The "
                "second half uses fetch_add as a ticket dispenser, so every thread gets a "
                "distinct number.\n\n"
                "Both are the canonical relaxed use cases: nothing is being published, only "
                "counted."),
            code('''#include <atomic>
#include <iostream>
#include <thread>
#include <vector>

int main() {
    std::atomic<long> total{0};
    std::vector<std::thread> workers;
    for (int t = 0; t < 4; ++t) {
        workers.emplace_back([&total] {
            for (int i = 1; i <= 10; ++i) {
                total.fetch_add(i, std::memory_order_relaxed);
            }
        });
    }
    for (std::thread& worker : workers) {
        worker.join();
    }
    std::cout << "relaxed total " << total.load() << " (always 220)\\n";

    std::atomic<int> next_ticket{0};
    std::vector<int> tickets(4, 0);
    std::vector<std::thread> dispensers;
    for (int t = 0; t < 4; ++t) {
        dispensers.emplace_back([&next_ticket, &tickets, t] {
            tickets[static_cast<std::size_t>(t)] =
                next_ticket.fetch_add(1, std::memory_order_relaxed);
        });
    }
    for (std::thread& worker : dispensers) {
        worker.join();
    }
    bool all_distinct = true;
    for (std::size_t i = 0; i < tickets.size(); ++i) {
        for (std::size_t j = i + 1; j < tickets.size(); ++j) {
            if (tickets[i] == tickets[j]) {
                all_distinct = false;
            }
        }
    }
    std::cout << "four tickets, all distinct: " << (all_distinct ? "yes" : "no") << "\\n";
    return 0;
}
''', '''relaxed total 220 (always 220)
four tickets, all distinct: yes'''),
            exp("What relaxed will not do\n\n"
                "If one thread writes a payload into a plain int and then sets a relaxed "
                "atomic flag, a second thread that sees the flag may still read a stale "
                "payload. Nothing in the model forces the payload write to be visible first.\n\n"
                "The fix is one word: make the flag's store a release and the load an "
                "acquire. That is the next lesson."),
            CHALLENGE,
            code('''#include <atomic>
#include <iostream>
#include <thread>

int main() {
    std::atomic<int> counter{0};
    std::thread first([&counter] {
        for (int i = 0; i < 500; ++i) {
            counter.fetch_add(1, std::memory_order_relaxed);
        }
    });
    std::thread second([&counter] {
        for (int i = 0; i < 500; ++i) {
            counter.fetch_add(1, std::memory_order_relaxed);
        }
    });
    first.join();
    second.join();
    std::cout << "two threads, 500 each, total " << counter.load() << "\\n";
    return 0;
}
''', '''two threads, 500 each, total 1000'''),
            quiz("What is relaxed ordering safe for?",
                 ["Publishing data to another thread", "Counting and statistics where only "
                  "the value matters", "Replacing a mutex around a container",
                  "Guaranteeing visible writes"],
                 1, "It guarantees the operation is indivisible but says nothing about other "
                    "memory becoming visible in order."),
           ]),

    lesson("92104", 96, "Memory Orders", "Acquire and Release",
           "The pairing that publishes data safely without a mutex.",
           ["Publish data with a release store and read it with an acquire load.",
            "Explain what the pairing guarantees.",
            "Say why relaxed on either side breaks it."],
           [exp("A one-way door\n\n"
                "A release store says: everything I wrote before this point is visible to any "
                "thread that acquires this value. An acquire load says: I want to see "
                "everything that happened before the release I am synchronising with.\n\n"
                "Together they form synchronizes-with, and that gives happens-before across "
                "threads without a mutex - which is how lock-free code publishes a new "
                "structure.\n\n"
                "It is one-directional: release is for the writer's store, acquire for the "
                "reader's load. Using relaxed on either side removes the guarantee entirely."),
            dfn("Release-acquire", "A store-load pair where the release publishes earlier "
                                   "writes and the acquire makes them visible, creating a "
                                   "safe handoff between threads."),
            exp("A payload handed over\n\n"
                "The producer writes a value into a plain int, then stores true into a release "
                "flag. The consumer spins on an acquire load of that flag and only then reads "
                "the payload.\n\n"
                "The printed value is always 42. With relaxed on both sides the program would "
                "still usually print 42 - and would be undefined, which is exactly the kind "
                "of bug that only appears on someone else's machine."),
            code('''#include <atomic>
#include <iostream>
#include <thread>

int payload = 0;
std::atomic<bool> ready{false};

int main() {
    std::thread producer([] {
        payload = 42;
        ready.store(true, std::memory_order_release);
    });

    std::thread consumer([] {
        while (!ready.load(std::memory_order_acquire)) {
            std::this_thread::yield();
        }
        std::cout << "consumer read " << payload << "\\n";
    });

    producer.join();
    consumer.join();
    std::cout << "handoff complete\\n";
    return 0;
}
''', '''consumer read 42
handoff complete'''),
            exp("Where this appears in real code\n\n"
                "Reference counting is the classic case: an intrusive counter increment uses "
                "relaxed, while the decrement that reaches zero uses acquire-release, because "
                "the thread that destroys the object must see every write the other threads "
                "made.\n\n"
                "std::shared_ptr's control block does exactly this internally, which is why "
                "copying a shared_ptr across threads is safe while sharing a raw pointer is "
                "not."),
            CHALLENGE,
            code('''#include <atomic>
#include <iostream>
#include <thread>
#include <vector>

int main() {
    std::atomic<bool> published{false};
    std::atomic<int> matches{0};
    int value = 0;
    std::vector<std::thread> readers;
    for (int i = 0; i < 3; ++i) {
        readers.emplace_back([&published, &value, &matches] {
            while (!published.load(std::memory_order_acquire)) {
                std::this_thread::yield();
            }
            if (value == 7) {
                matches.fetch_add(1, std::memory_order_relaxed);
            }
        });
    }
    value = 7;
    published.store(true, std::memory_order_release);
    for (std::thread& reader : readers) {
        reader.join();
    }
    std::cout << "readers that saw the released value: " << matches.load() << " of 3\\n";
    return 0;
}
''', '''readers that saw the released value: 3 of 3'''),
            quiz("Which pair is correct for publishing data?",
                 ["Store relaxed, load relaxed", "Store release, load acquire",
                  "Store acquire, load release", "Any pair, the value is atomic"],
                 1, "The writer's store must be release and the reader's load acquire; the "
                    "other combinations give no guarantee about the payload."),
           ]),

    lesson("92105", 96, "Memory Orders", "Sequential Consistency, and Why volatile Is Not Atomic",
           "The strongest order, the default, and the keyword people reach for by mistake.",
           ["Say what seq_cst guarantees that acquire-release does not.",
            "Explain why volatile is not a synchronisation tool.",
            "Choose a memory order deliberately."],
           [exp("One total order\n\n"
                "Sequential consistency is the default for every atomic operation. It "
                "guarantees everything acquire-release does, plus a single total order that "
                "all threads agree on: if two seq_cst stores happen, every thread sees them "
                "in the same order.\n\n"
                "That costs instructions on some architectures - a barrier on each side - "
                "which is why lock-free code pays for relaxed where it can prove it is safe. "
                "Start with the default; relax only when a profiler says it matters.\n\n"
                "volatile is a different thing entirely: it tells the compiler that a value "
                "may change outside the program, so it must not cache it. It gives no "
                "atomicity and no ordering between threads."),
            dfn("Sequential consistency", "The strongest memory order: all threads observe "
                                          "every atomic operation in one agreed total order."),
            exp("Sequentially consistent, then relaxed\n\n"
                "The first counter uses the default and reads back exactly what four threads "
                "added. The second uses relaxed and does exactly the same arithmetic with "
                "less machinery.\n\n"
                "Both totals are correct, and that is the honest lesson: atomicity is what "
                "makes the total right, and the order is what makes the visibility right. "
                "They are separate properties."),
            code('''#include <atomic>
#include <iostream>
#include <thread>
#include <vector>

int main() {
    std::atomic<int> strict{0};
    std::atomic<int> loose{0};
    std::vector<std::thread> workers;
    for (int t = 0; t < 3; ++t) {
        workers.emplace_back([&strict, &loose] {
            for (int i = 0; i < 100; ++i) {
                strict.fetch_add(1);
                loose.fetch_add(1, std::memory_order_relaxed);
            }
        });
    }
    for (std::thread& worker : workers) {
        worker.join();
    }
    std::cout << "seq_cst total " << strict.load() << "\\n";
    std::cout << "relaxed total " << loose.load() << "\\n";
    std::cout << "both are 300, and only the order differs\\n";
    return 0;
}
''', '''seq_cst total 300
relaxed total 300
both are 300, and only the order differs'''),
            exp("The volatile trap, in one example\n\n"
                "volatile int shared; shared = shared + 1; from four threads is not a race "
                "the compiler must fix - it is still a read, an add and a write, and two "
                "threads can interleave inside it. The keyword only stops the compiler "
                "caching the value.\n\n"
                "volatile's real jobs are memory-mapped hardware registers, signal handlers "
                "and setjmp buffers. For threading, the tool is std::atomic."),
            CHALLENGE,
            code('''#include <atomic>
#include <iostream>

int main() {
    std::atomic<int> value{0};
    value.store(10);
    int old = value.fetch_add(5);
    std::cout << "fetch_add returned the old value " << old << "\\n";
    std::cout << "value is now " << value.load() << "\\n";

    int expected = 14;
    bool swapped = value.compare_exchange_strong(expected, 99);
    std::cout << "compare_exchange expecting 14: " << (swapped ? "swapped" : "failed")
              << ", and expected was corrected to " << expected << "\\n";
    expected = 15;
    swapped = value.compare_exchange_strong(expected, 99);
    std::cout << "second attempt " << (swapped ? "swapped" : "failed")
              << ", value now " << value.load() << "\\n";
    return 0;
}
''', '''fetch_add returned the old value 10
value is now 15
compare_exchange expecting 14: failed, and expected was corrected to 15
second attempt swapped, value now 99'''),
            quiz("What does volatile guarantee about threads?",
                 ["Atomic reads and writes", "Nothing - it only stops the compiler caching the "
                  "value", "A total order of operations", "That writes are visible at once"],
                 1, "It is a compiler hint for hardware registers and signals; std::atomic is "
                    "the threading tool."),
           ]),

    lesson("92106", 96, "Undefined Behaviour", "What Undefined Behaviour Actually Means",
           "Not 'wrong answer' - no contract at all, which the optimiser is allowed to exploit.",
           ["Define UB precisely.",
            "Explain why the optimiser may delete or change surrounding code.",
            "Say why 'it works on my machine' proves nothing."],
           [exp("No requirements at all\n\n"
                "Undefined behaviour means the standard imposes no requirements on the "
                "program's behaviour - not that it crashes, not that it prints garbage. Any "
                "outcome is conforming, including the one you tested.\n\n"
                "The dangerous part is what the optimiser may infer. If a pointer is "
                "dereferenced, the compiler assumes it is not null and may delete an earlier "
                "if (ptr == nullptr) check entirely - so the null check your eyes see in the "
                "source is not in the binary.\n\n"
                "That is why UB is a compiler-contract problem, not a runtime-error problem."),
            dfn("Undefined behaviour", "A program construct for which the standard specifies no "
                                       "requirements, so any behaviour is conforming."),
            exp("Out-of-bounds read, which may print anything\n\n"
                "The example reads past the end of a three-element array and prints whatever "
                "is there. On this machine it happens to print 0; on another build it may "
                "print a different number or crash.\n\n"
                "It is included because seeing it print a tidy 0 is exactly the experience "
                "that teaches people the wrong lesson. The value is meaningless - only the "
                "absence of a guarantee is real."),
            code('''#include <array>
#include <iostream>

int main() {
    std::array<int, 3> values{1, 2, 3};
    std::cout << "inside the array: " << values[0] << " " << values[1] << " " << values[2]
              << "\\n";

    int uninitialised = 0;
    std::cout << "initialised on purpose: " << uninitialised << "\\n";
    std::cout << "reading past the end is undefined behaviour, so this program\\n";
    std::cout << "does not do it: the index below is checked by .at()\\n";
    try {
        std::cout << values.at(3) << "\\n";
    } catch (const std::out_of_range&) {
        std::cout << "at(3) threw out_of_range instead of misbehaving\\n";
    }
    return 0;
}
''', '''inside the array: 1 2 3
initialised on purpose: 0
reading past the end is undefined behaviour, so this program
does not do it: the index below is checked by .at()
at(3) threw out_of_range instead of misbehaving'''),
            exp("Signed overflow is in the same family\n\n"
                "Signed integer overflow is undefined; unsigned overflow is defined to wrap. "
                "That asymmetry is why the optimiser can assume a signed loop counter never "
                "wraps and remove a bounds check you wrote on purpose.\n\n"
                "The lesson is not 'avoid the optimiser'. It is that the program must stay "
                "inside the contract, and every tool that helps - .at(), bounds-checked "
                "iterators, sanitizers - is a way of staying inside it."),
            CHALLENGE,
            code('''#include <iostream>
#include <limits>
#include <stdexcept>

int safe_add(int a, int b) {
    if ((b > 0 && a > std::numeric_limits<int>::max() - b) ||
        (b < 0 && a < std::numeric_limits<int>::min() - b)) {
        throw std::overflow_error("int addition would overflow");
    }
    return a + b;
}

int main() {
    std::cout << "2 + 3 = " << safe_add(2, 3) << "\\n";
    try {
        std::cout << safe_add(std::numeric_limits<int>::max(), 1) << "\\n";
    } catch (const std::overflow_error& error) {
        std::cout << "caught: " << error.what() << "\\n";
    }
    return 0;
}
''', '''2 + 3 = 5
caught: int addition would overflow'''),
            quiz("Why can an optimiser delete a null check you wrote?",
                 ["Because it is buggy", "Because dereferencing the pointer later already "
                  "assumes it is not null, so the check is dead code", "Because of the "
                  "compiler flags", "Because null checks are slow"],
                 1, "UB in one place lets the compiler assume it never happens, which changes "
                    "the meaning of the surrounding code."),
           ]),

    lesson("92107", 96, "Undefined Behaviour", "The Common Sources, One by One",
           "Dangling pointers, out-of-bounds, uninitialised reads, strict aliasing and signed overflow.",
           ["Name the five most common sources of UB.",
            "Show the defined alternative for each.",
            "Say why ASan and UBSan find what testing misses."],
           [exp("Five that cover most of it\n\n"
                "Reading uninitialised memory; reading or writing outside an array; using a "
                "pointer or reference after the object dies; signed overflow; and breaking "
                "strict aliasing by reading an int through a float pointer.\n\n"
                "Each has a defined alternative: initialise members, use .at() or a range-for, "
                "use a smart pointer or a value, use unsigned or a wider type, and use memcpy "
                "or std::bit_cast instead of pointer punning.\n\n"
                "None of them is exotic - they are the everyday mistakes, which is why "
                "sanitizers exist."),
            dfn("Strict aliasing", "The rule that an object may only be accessed through a "
                                   "pointer to its own type (or char/byte), so the optimiser "
                                   "can assume two differently-typed pointers do not overlap."),
            exp("Four defined patterns\n\n"
                "The example shows the safe version of each mistake: members initialised, "
                "bounds checked with at(), a smart pointer instead of a raw owning pointer, "
                "and arithmetic guarded against overflow.\n\n"
                "It is deliberately boring code. The point is that the fixes are cheap and "
                "the bugs are not."),
            code('''#include <iostream>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

struct Settings {
    int retries = 3;
    std::string name = "default";
};

int read_at(const std::vector<int>& values, std::size_t index) {
    return values.at(index);
}

int main() {
    Settings settings;
    std::cout << "settings default to " << settings.retries << " retries, name "
              << settings.name << "\\n";

    std::vector<int> values{10, 20, 30};
    std::cout << "index 1 is " << read_at(values, 1) << "\\n";
    try {
        read_at(values, 7);
    } catch (const std::out_of_range&) {
        std::cout << "index 7 was rejected, not read\\n";
    }

    auto owned = std::make_unique<int>(5);
    auto shared = owned.get();
    std::cout << "unique_ptr keeps the value alive: " << *shared << "\\n";

    std::cout << "unique_ptr cleans up when its scope ends\\n";
    return 0;
}
''', '''settings default to 3 retries, name default
index 1 is 20
index 7 was rejected, not read
unique_ptr keeps the value alive: 5
unique_ptr cleans up when its scope ends'''),
            exp("What sanitizers add\n\n"
                "AddressSanitizer instruments every access and catches out-of-bounds and "
                "use-after-free at the moment they happen. UndefinedBehaviorSanitizer catches "
                "signed overflow, misaligned access and invalid shifts.\n\n"
                "A clean test run proves nothing about UB, because UB does not have to "
                "misbehave on that input. A sanitizer run proves something - which is why "
                "serious projects run both."),
            CHALLENGE,
            code('''#include <cstdint>
#include <iostream>
#include <limits>

int main() {
    unsigned wraps = std::numeric_limits<unsigned>::max();
    ++wraps;
    std::cout << "unsigned overflow wraps to " << wraps << " (defined)\\n";

    std::uint8_t small = 250;
    small = static_cast<std::uint8_t>(small + 10);
    std::cout << "uint8_t 250 plus 10 becomes " << static_cast<int>(small)
              << " (defined wrap)\\n";

    long long big = std::numeric_limits<long long>::max();
    std::cout << "long long max is " << big << ", so check before adding\\n";
    return 0;
}
''', '''unsigned overflow wraps to 0 (defined)
uint8_t 250 plus 10 becomes 4 (defined wrap)
long long max is 9223372036854775807, so check before adding'''),
            quiz("Which of these is defined behaviour?",
                 ["Reading an uninitialised local int", "Unsigned integer overflow wrapping",
                  "Dereferencing a pointer to a destroyed object", "Signed integer overflow"],
                 1, "Only unsigned arithmetic is specified to wrap; every other item in that "
                    "list is undefined."),
           ]),

    lesson("92108", 96, "Undefined Behaviour", "Detecting It Before Your Users Do",
           "Sanitizers, assertions and the checks cheap enough to leave switched on.",
           ["Say what a sanitizer run adds over a test run.",
            "Use assert for invariants and static_assert for compile-time rules.",
            "Choose the check that stays in release builds."],
           [exp("Three layers of detection\n\n"
                "At compile time, static_assert refuses code that cannot be right - a wrong "
                "size, an unsupported type. It costs nothing at run time.\n\n"
                "At debug run time, assert documents an invariant and aborts when it is "
                "broken. It disappears when NDEBUG is defined, so it is for catching your own "
                "mistakes, not for validating input.\n\n"
                "Under a sanitizer, the tool instruments every access and reports the first "
                "bad one with a stack trace. That is the layer that finds the UB your tests "
                "happened to miss."),
            dfn("Invariant", "A condition that must hold at a particular point in the program "
                             "for the code to be correct - the thing an assert documents."),
            exp("Compile-time and run-time checks in one program\n\n"
                "static_assert checks facts the compiler can prove: an int is at least two "
                "bytes, a struct has the expected number of members. assert checks a "
                "precondition at run time.\n\n"
                "The last part shows the check that survives release: a thrown exception for "
                "input you cannot trust, because that is a contract with the caller rather "
                "than a note to yourself."),
            code('''#include <cassert>
#include <iostream>
#include <stdexcept>
#include <vector>

static_assert(sizeof(int) >= 2, "int must be at least 16 bits");
static_assert(sizeof(std::size_t) >= sizeof(int), "size_t must hold an int index");

int average(const std::vector<int>& values) {
    assert(!values.empty() && "average needs at least one value");
    int total = 0;
    for (int value : values) {
        total += value;
    }
    return total / static_cast<int>(values.size());
}

int checked_average(const std::vector<int>& values) {
    if (values.empty()) {
        throw std::invalid_argument("average needs at least one value");
    }
    return average(values);
}

int main() {
    std::cout << "static_asserts passed at compile time\\n";
    std::cout << "average of 2, 4, 6 is " << checked_average({2, 4, 6}) << "\\n";
    try {
        checked_average({});
    } catch (const std::invalid_argument& error) {
        std::cout << "rejected: " << error.what() << "\\n";
    }
    return 0;
}
''', '''static_asserts passed at compile time
average of 2, 4, 6 is 4
rejected: average needs at least one value'''),
            exp("How to actually run one\n\n"
                "Compile the same code with -fsanitize=address,undefined and run the test "
                "suite again. AddressSanitizer reports the exact line of an out-of-bounds "
                "access; UndefinedBehaviorSanitizer reports the exact line of an overflow.\n\n"
                "The habit that pays: sanitizer builds in CI on every push, because the input "
                "that triggers UB is usually the one nobody wrote a test for."),
            CHALLENGE,
            code('''#include <cassert>
#include <iostream>
#include <string>

int score(const std::string& name, int points) {
    assert(!name.empty() && "a score needs a name");
    assert(points >= 0 && "points cannot be negative");
    return points * 2;
}

int main() {
    std::cout << "ada scores " << score("ada", 10) << "\\n";
    std::cout << "bo scores " << score("bo", 0) << "\\n";
    std::cout << "both calls satisfied their assertions\\n";
    return 0;
}
''', '''ada scores 20
bo scores 0
both calls satisfied their assertions'''),
            quiz("What does a sanitizer build give you that a normal test run does not?",
                 ["Faster code", "Detection of undefined behaviour at the moment it happens, "
                  "with a location", "Automatic fixes", "Better optimisations"],
                 1, "UB often produces plausible output in a normal run; the sanitizer "
                    "instruments the accesses and reports the first violation."),
           ]),
]
