"""Level 22 — memory layout and where things live."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("92201", 97, "Layout", "The Segments: Text, Data, BSS, Stack and Heap",
           "One program, five regions, and which of your variables lands in which.",
           ["Name the five regions of a running program.",
            "Say where a global, a static local, a stack object and a heap object live.",
            "Explain why the BSS exists at all."],
           [exp("Five regions\n\n"
                "Text holds the machine code - it is read-only and shared. Data holds "
                "globals and static locals that were given a non-zero starting value. BSS "
                "holds the zero-initialised ones: the kernel maps them in already zeroed, so "
                "the executable does not need to store megabytes of zeros - that is the whole "
                "reason BSS exists.\n\n"
                "The stack holds locals and call frames, growing and shrinking as functions "
                "run. The heap is the free store behind new and malloc, managed by the "
                "allocator.\n\n"
                "Everything in data and BSS lives for the whole program; everything on the "
                "stack lives until its frame pops."),
            dfn("BSS", "The part of the executable describing zero-initialised global and "
                       "static data. It stores sizes, not zeros, because the loader makes the "
                       "memory zero already."),
            exp("Behaviour you can observe without addresses\n\n"
                "A non-zero global, a huge zeroed array, a local and a heap value. The array "
                "is 200,000 ints and the program still starts instantly, because those zeros "
                "cost nothing in the executable.\n\n"
                "Do not print raw addresses to prove any of this: they change every run. "
                "Print behaviour instead - which is what the rest of this lesson does."),
            code('''#include <iostream>
#include <memory>
#include <numeric>
#include <vector>

int initialised_global = 7;
std::vector<int> huge_zeroed(200000);

int main() {
    int local = 3;
    std::cout << "data segment holds " << initialised_global << "\\n";
    std::cout << "bss holds " << huge_zeroed.size() << " zeros, sum "
              << std::accumulate(huge_zeroed.begin(), huge_zeroed.end(), 0) << "\\n";
    std::cout << "stack holds " << local << "\\n";
    auto on_heap = std::make_unique<int>(11);
    std::cout << "heap holds " << *on_heap << "\\n";
    std::cout << "all four are alive at the same moment\\n";
    return 0;
}
''', '''data segment holds 7
bss holds 200000 zeros, sum 0
stack holds 3
heap holds 11
all four are alive at the same moment'''),
            exp("Why the split matters\n\n"
                "Stack allocation is one pointer subtraction, so it is effectively free; heap "
                "allocation is a search through free lists, so it is not. That is the real "
                "reason to prefer a value on the stack to a new.\n\n"
                "Data and BSS are shared by every thread, which is why a mutable global is a "
                "synchronisation problem. The stack is per-thread, which is why locals are "
                "the safe default."),
            CHALLENGE,
            code('''#include <iostream>

int counter_storage = 0;

void bump() {
    static int total = 0;
    ++total;
    ++counter_storage;
    std::cout << "static total " << total << ", global " << counter_storage << "\\n";
}

int main() {
    bump();
    bump();
    bump();
    std::cout << "both live as long as the program\\n";
    return 0;
}
''', '''static total 1, global 1
static total 2, global 2
static total 3, global 3
both live as long as the program'''),
            quiz("Why does a large zero-initialised global array not bloat the executable?",
                 ["Because the compiler removes it", "Because it lives in BSS, which records "
                  "sizes and relies on the loader zeroing the memory", "Because it is on the "
                  "stack", "Because zeroes compress well"],
                 1, "BSS stores no data - only how much memory the loader must provide, "
                    "already zeroed."),
           ]),

    lesson("92202", 97, "Layout", "Stack Frames and the Direction of Growth",
           "What a call actually does to memory, shown without a single raw address.",
           ["Describe what a stack frame contains.",
            "Show that locals live in the frame that created them.",
            "Say what recursion does to the stack and how it ends."],
           [exp("One frame per call\n\n"
                "Calling a function pushes a frame holding the return address, the saved "
                "registers, the parameters that did not fit in registers, and the locals. "
                "Returning pops it, which is why a local's lifetime is exactly its frame's.\n\n"
                "Recursion is the same frame repeated. Each call adds one, which is why deep "
                "recursion ends in a stack overflow rather than a wrong answer.\n\n"
                "You cannot portably print the direction the stack grows, and it differs by "
                "architecture - so this lesson demonstrates frames by behaviour: addresses "
                "relative to each other, not their absolute values."),
            dfn("Stack frame", "The block of stack memory belonging to one function call, "
                               "holding its return address, saved state and locals."),
            exp("Frames going up and coming down\n\n"
                "Two functions print as they are entered and exited, plus a recursive count "
                "that reports the depth. The nesting order is the frame order, and the depth "
                "is how many frames are alive at once.\n\n"
                "The key line is the depth: it is exactly the recursion depth, no more."),
            code('''#include <iostream>

void deepest(int depth) {
    if (depth == 0) {
        std::cout << "reached the bottom\\n";
        return;
    }
    std::cout << "entering depth " << depth << "\\n";
    deepest(depth - 1);
    std::cout << "leaving depth " << depth << "\\n";
}

int frame_count(int n) {
    if (n == 0) {
        return 0;
    }
    return 1 + frame_count(n - 1);
}

int main() {
    deepest(3);
    std::cout << "four nested calls for depth 3\\n";
    std::cout << "frames alive for n=4: " << frame_count(4) << "\\n";
    return 0;
}
''', '''entering depth 3
entering depth 2
entering depth 1
reached the bottom
leaving depth 1
leaving depth 2
leaving depth 3
four nested calls for depth 3
frames alive for n=4: 4'''),
            exp("The size of the stack is finite\n\n"
                "On desktop systems it is typically a few megabytes per thread; on embedded "
                "targets it can be a few kilobytes. A recursive function that allocates a "
                "4 KB buffer per frame reaches the limit in about a thousand calls.\n\n"
                "That is why tree traversals and parsers are the classic stack-overflow "
                "suspects, and why the fix is an explicit stack in a container: the heap can "
                "grow, the call stack cannot."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

int sum_with_loop(const std::vector<int>& values) {
    int total = 0;
    for (int value : values) {
        total += value;
    }
    return total;
}

int sum_with_stack(const std::vector<int>& values) {
    std::vector<int> pending(values.rbegin(), values.rend());
    int total = 0;
    while (!pending.empty()) {
        total += pending.back();
        pending.pop_back();
    }
    return total;
}

int main() {
    std::vector<int> values{1, 2, 3, 4, 5};
    std::cout << "loop sum " << sum_with_loop(values) << "\\n";
    std::cout << "explicit stack sum " << sum_with_stack(values) << "\\n";
    std::cout << "neither uses recursion, so neither can overflow the call stack\\n";
    return 0;
}
''', '''loop sum 15
explicit stack sum 15
neither uses recursion, so neither can overflow the call stack'''),
            quiz("What happens when recursion gets too deep?",
                 ["The program slows down", "The call stack is exhausted and the program "
                  "terminates", "The compiler unrolls it", "Values are lost silently"],
                 1, "Each call needs a frame and the stack is a fixed size, so it runs out."),
           ]),

    lesson("92203", 97, "Layout", "Static Storage and Initialisation Order",
           "Globals are constructed before main and destroyed after it, in an order you must not rely on.",
           ["Say when globals are constructed and destroyed.",
            "Explain the static initialisation order problem.",
            "Use a function-local static to avoid it."],
           [exp("Before main, after main\n\n"
                "A global or static object is constructed before main begins and destroyed "
                "after main returns - unless it is declared static inside a function, in "
                "which case it is constructed on first use.\n\n"
                "The trap is order. Across translation units, the standard does not specify "
                "which global is constructed first. A global that uses another global is "
                "therefore reading an object that may not exist yet - the static "
                "initialisation order fiasco.\n\n"
                "Inside one translation unit the order is top to bottom, which is why "
                "single-file examples never show the bug."),
            dfn("Static initialisation order fiasco", "The undefined order in which global "
                                                      "objects from different files are "
                                                      "constructed, which breaks globals "
                                                      "that depend on each other."),
            exp("Logging construction and destruction\n\n"
                "Two objects with constructors and destructors that print. The output shows "
                "construction in declaration order and destruction in reverse - the mirror "
                "of the stack.\n\n"
                "The function-local static is constructed on first call, which is the fix "
                "for cross-file ordering: it cannot be used before it exists."),
            code('''#include <iostream>
#include <string>

struct Logger {
    std::string name;
    explicit Logger(std::string label) : name(std::move(label)) {
        std::cout << "constructing " << name << "\\n";
    }
    ~Logger() { std::cout << "destroying " << name << "\\n"; }
};

Logger first("first global");
Logger second("second global");

Logger& settings() {
    static Logger instance("lazy global");
    return instance;
}

int main() {
    std::cout << "main starts\\n";
    settings();
    std::cout << "main is about to return\\n";
    return 0;
}
''', '''constructing first global
constructing second global
main starts
constructing lazy global
main is about to return
destroying lazy global
destroying second global
destroying first global'''),
            exp("The rule to take away\n\n"
                "Never let a global's constructor depend on another global from a different "
                "file. If you need a shared object, expose it through a function that holds a "
                "local static - constructed on first use, destroyed after main, and safe from "
                "every file.\n\n"
                "That is the same Meyers singleton shape, and the reason the standard "
                "guarantees thread-safe initialisation for function-local statics."),
            CHALLENGE,
            code('''#include <iostream>

struct Registry {
    int entries = 0;
    Registry() { std::cout << "registry created\\n"; }
    void add() { ++entries; }
};

Registry& registry() {
    static Registry instance;
    return instance;
}

int main() {
    registry().add();
    registry().add();
    std::cout << "entries " << registry().entries << " (one object, three calls)\\n";
    std::cout << "same object each time: " << (&registry() == &registry() ? "yes" : "no")
              << "\\n";
    return 0;
}
''', '''registry created
entries 2 (one object, three calls)
same object each time: yes'''),
            quiz("Why is a function-local static safer than a global for a shared object?",
                 ["It is faster", "It is constructed on first use, so it cannot be used "
                  "before it exists", "It is thread local", "It is const"],
                 1, "Lazy construction sidesteps the unspecified cross-file initialisation "
                    "order entirely."),
           ]),

    lesson("92204", 97, "Layout", "Sizing a Class Up",
           "Why an empty class is one byte, why padding appears, and what you pay for a virtual function.",
           ["Explain why sizeof of an empty class is 1.",
            "Show how member order changes the size of a struct.",
            "Say what a vtable pointer costs."],
           [exp("Sizes you can predict\n\n"
                "Every object needs a distinct address, so an empty class still occupies one "
                "byte. Members are laid out in declaration order with padding inserted to "
                "keep each one aligned, which is why reordering the same members can change "
                "the total.\n\n"
                "A class with a virtual function holds a hidden pointer to its vtable - "
                "eight bytes on a 64-bit build - plus whatever its members need.\n\n"
                "These numbers are not trivia: they decide how much memory a container of a "
                "million objects costs."),
            dfn("Padding", "Unused bytes inserted between members so that each one starts at "
                           "an address its alignment requires."),
            exp("Four sizes, all predictable\n\n"
                "An empty struct is 1. Two chars are 2. A char followed by an int is 8 - "
                "one byte, three of padding, then four. An int followed by a char is also 8, "
                "because the struct itself must end aligned.\n\n"
                "The counts are printed with sizeof so the compiler is the source of truth "
                "rather than my memory."),
            code('''#include <iostream>

struct Empty {};

struct TwoChars {
    char a;
    char b;
};

struct CharThenInt {
    char a;
    int b;
};

struct IntThenChar {
    int a;
    char b;
};

struct WithVirtual {
    virtual ~WithVirtual() = default;
    int value;
};

int main() {
    std::cout << "empty            " << sizeof(Empty) << "\\n";
    std::cout << "two chars        " << sizeof(TwoChars) << "\\n";
    std::cout << "char then int    " << sizeof(CharThenInt) << "\\n";
    std::cout << "int then char    " << sizeof(IntThenChar) << "\\n";
    std::cout << "virtual plus int " << sizeof(WithVirtual) << "\\n";
    std::cout << "one char alone   " << sizeof(char) << "\\n";
    return 0;
}
''', '''empty            1
two chars        2
char then int    8
int then char    8
virtual plus int 16
one char alone   1'''),
            exp("Two practical consequences\n\n"
                "Pad to the front: in a hot array of small structs, putting the members in "
                "descending size order can remove padding entirely and shrink memory by a "
                "third - worth knowing before optimising anything else.\n\n"
                "Do not store a char as a member when a bool would do the same job in one "
                "byte with clearer intent; do not assume a struct is the size of its fields "
                "added up, because padding is invisible in the source but real in the cache."),
            CHALLENGE,
            code('''#include <iostream>

struct Padded {
    char tag;
    int weight;
    char flag;
};

struct Packed {
    int weight;
    char tag;
    char flag;
};

struct Aligned {
    alignas(16) int small;
};

int main() {
    std::cout << "declaration order   " << sizeof(Padded) << "\\n";
    std::cout << "reordered by size   " << sizeof(Packed) << "\\n";
    std::cout << "forced 16 alignment " << sizeof(Aligned) << "\\n";
    std::cout << "same fields, different memory\\n";
    return 0;
}
''', '''declaration order   12
reordered by size   8
forced 16 alignment 16
same fields, different memory'''),
            quiz("Why is sizeof of an empty class 1 rather than 0?",
                 ["For alignment", "So that two distinct objects have distinct addresses",
                  "To allow inheritance", "Because of the vtable"],
                 1, "A zero-size object could not be given a unique address, which arrays of "
                    "it would require."),
           ]),
]
