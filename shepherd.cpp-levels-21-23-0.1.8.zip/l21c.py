"""Level 23 — object lifetime."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("92301", 98, "Lifetime", "Construction and Destruction Order",
           "Members die in reverse order, bases go first, and what that means for your code.",
           ["Predict the order members are constructed and destroyed.",
            "Say when base and derived constructors run.",
            "Explain why a destructor must not use a member from another object."],
           [exp("Bottom up, then top down\n\n"
                "Inside one object, members are constructed in declaration order - not in the "
                "order of the initialiser list - and destroyed in the reverse. Base classes "
                "are constructed before members and destroyed after them.\n\n"
                "The rule matters because a constructor may use members declared before it, "
                "and a destructor may use members declared after it. Break that and you are "
                "reading an object that has already been destroyed.\n\n"
                "The initialiser list is not the order of construction; it is only where you "
                "write the values."),
            dfn("Declaration order", "The order members appear in the class body, which is the "
                                     "order they are constructed - regardless of the order in "
                                     "the constructor's initialiser list."),
            exp("A traced object\n\n"
                "Three members with traced constructors and destructors, declared C, A, B and "
                "initialised in the same order. The output follows the declaration - which, "
                "for a reader, is the only order that matters.\n\n"
                "That is the warning worth remembering: an initialiser list written in a "
                "different order than the declarations is legal but silently misleading, and "
                "the compiler will warn about it with -Wreorder for good reason."),
            code('''#include <iostream>
#include <string>

struct Traced {
    std::string name;
    explicit Traced(std::string label) : name(std::move(label)) {
        std::cout << "  construct " << name << "\\n";
    }
    ~Traced() { std::cout << "  destroy " << name << "\\n"; }
};

struct Widget {
    Traced third{"C"};
    Traced first{"A"};
    Traced second{"B"};

    Widget() {
        std::cout << "  widget body\\n";
    }
    ~Widget() { std::cout << "  widget destructor\\n"; }
};

int main() {
    std::cout << "creating the widget\\n";
    {
        Widget widget;
    }
    std::cout << "the widget is gone\\n";
    return 0;
}
''', '''creating the widget
  construct C
  construct A
  construct B
  widget body
  widget destructor
  destroy B
  destroy A
  destroy C
the widget is gone'''),
            exp("Bases and members together\n\n"
                "A derived object is built in a fixed sequence: base, then members, then the "
                "derived constructor body. Destruction is the exact reverse: derived body, "
                "members, base.\n\n"
                "That is why you can safely pass a reference to the base class inside a "
                "derived constructor - the base is already fully built - and why you must "
                "never call a virtual function from a constructor: the derived part does not "
                "exist yet, so the base version is called."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>

struct Base {
    explicit Base(std::string label) : name(std::move(label)) {
        std::cout << "base " << name << "\\n";
    }
    ~Base() { std::cout << "base gone\\n"; }
    std::string name;
};

struct Derived : Base {
    Derived() : Base("built first"), extra("member second") {
        std::cout << "derived body\\n";
    }
    ~Derived() { std::cout << "derived gone\\n"; }
    std::string extra;
};

int main() {
    {
        Derived object;
        std::cout << "object holds " << object.name << " and " << object.extra << "\\n";
    }
    std::cout << "done\\n";
    return 0;
}
''', '''base built first
derived body
object holds built first and member second
derived gone
base gone
done'''),
            quiz("A class declares members a, b, c but the initialiser list writes c, b, a. In what order are they constructed?",
                 ["c, b, a", "a, b, c - declaration order wins", "Undefined", "Alphabetical"],
                 1, "Initialiser lists set values; construction order always follows the "
                    "declarations."),
           ]),

    lesson("92302", 98, "Lifetime", "Temporary Objects and Lifetime Extension",
           "The temporaries you can name, the ones you cannot, and the one rule that rescues a dangling reference.",
           ["Say when a temporary is created and destroyed.",
            "Use a const reference to extend a temporary's lifetime.",
            "Spot the case where extension does not happen."],
           [exp("Temporaries live for the full expression\n\n"
                "A temporary - the result of a function returning by value, a conversion, or a "
                "brace-initialised object - normally dies at the end of the full expression "
                "that created it. Passing it to a function is therefore fine: it is alive for "
                "the whole call.\n\n"
                "Binding it to a const reference (or an rvalue reference) extends it to the "
                "lifetime of that reference. That is the one rescue.\n\n"
                "It does not extend through a function return, through a member reference, or "
                "through a reference inside a struct - those are the cases that dangle."),
            dfn("Temporary", "An unnamed object created by an expression, destroyed at the end "
                             "of the full expression unless its lifetime is extended by a "
                             "reference binding."),
            exp("Extended, not extended, and still safe\n\n"
                "The first block binds a temporary to a const reference and it survives to "
                "the end of the scope - the destructor runs there.\n\n"
                "The second block passes a temporary straight to a function that takes it by "
                "value: safe, because the temporary lives through the whole call.\n\n"
                "Both print their destruction at the point the standard requires."),
            code('''#include <iostream>
#include <string>

struct Tracer {
    std::string name;
    explicit Tracer(std::string label) : name(std::move(label)) {
        std::cout << "create " << name << "\\n";
    }
    ~Tracer() { std::cout << "destroy " << name << "\\n"; }
};

void by_value(Tracer tracer) {
    std::cout << "  inside by_value with " << tracer.name << "\\n";
}

int main() {
    {
        const Tracer& extended = Tracer("extended by a reference");
        std::cout << "still alive: " << extended.name << "\\n";
    }
    std::cout << "reference scope ended\\n";

    by_value(Tracer("lives through the call"));
    std::cout << "call finished\\n";
    return 0;
}
''', '''create extended by a reference
still alive: extended by a reference
destroy extended by a reference
reference scope ended
create lives through the call
  inside by_value with lives through the call
destroy lives through the call
call finished'''),
            exp("Where extension does not reach\n\n"
                "A function that returns a const reference to its own temporary compiles "
                "cleanly and returns a dangling reference - the object died at the return.\n\n"
                "A struct holding a const reference to a temporary has the same problem: the "
                "reference member does not extend anything past the full expression that "
                "created the struct. Returning by value avoids both, and modern C++ moves "
                "rather than copies, so it is cheap."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <vector>

std::string build_greeting(const std::string& name) {
    return "hello, " + name;
}

const std::string& bad_reference() {
    static const std::string safe = "this survives because it is static";
    return safe;
}

int main() {
    const std::string& greeting = build_greeting("ada");
    std::cout << greeting << " (the returned value was moved into the reference)\\n";

    std::vector<std::string> names{"bo", "cy"};
    for (const std::string& name : names) {
        std::cout << build_greeting(name) << "\\n";
    }
    std::cout << bad_reference() << "\\n";
    return 0;
}
''', '''hello, ada (the returned value was moved into the reference)
hello, bo
hello, cy
this survives because it is static'''),
            quiz("A function returns a const reference to a local variable. What happens?",
                 ["The lifetime is extended", "The reference dangles - the object died at the "
                  "return", "It is copied automatically", "It fails to compile"],
                 1, "Lifetime extension applies to reference bindings, not to returning a "
                    "reference to something local."),
           ]),

    lesson("92303", 98, "Lifetime", "Storage Reuse and placement new",
           "Putting an object into someone else's bytes - and why that is legal.",
           ["Use placement new to construct in a given buffer.",
            "Destroy an object without freeing its storage.",
            "Say what a union or a buffer of aligned storage really is."],
           [exp("Separating storage from construction\n\n"
                "new does two things: it obtains memory, then it constructs an object there. "
                "placement new does only the second - it constructs into storage you already "
                "own.\n\n"
                "That is how std::vector holds capacity it has not filled, how "
                "std::optional holds a value it may not have, and how a fixed-size buffer "
                "becomes a container without allocating.\n\n"
                "The other half is calling the destructor by hand when you are done, without "
                "freeing the storage. Getting one without the other is the bug."),
            dfn("Placement new", "The new-expression form new (ptr) T(args) that constructs an "
                                 "object into existing storage, performing no allocation."),
            exp("Four objects into one buffer\n\n"
                "A buffer sized for two Points, then each slot constructed with placement new. "
                "Only after all four exist do we read them.\n\n"
                "Reading a slot before constructing it would be undefined, which is the "
                "discipline this pattern demands - and the reason std::vector internally "
                "tracks how many slots are alive."),
            code('''#include <iostream>
#include <new>
#include <string>

struct Point {
    int x;
    int y;
    Point(int a, int b) : x(a), y(b) {
        std::cout << "constructed (" << x << "," << y << ")\\n";
    }
    ~Point() { std::cout << "destroyed (" << x << "," << y << ")\\n"; }
};

int main() {
    alignas(Point) unsigned char buffer[sizeof(Point) * 2];
    std::cout << "buffer is " << sizeof(buffer) << " bytes, holding raw storage\\n";

    Point* first = new (buffer) Point(1, 2);
    Point* second = new (buffer + sizeof(Point)) Point(3, 4);

    std::cout << "first " << first->x << "," << first->y << " second " << second->x << ","
              << second->y << "\\n";

    first->~Point();
    second->~Point();
    std::cout << "storage is still ours, the objects are gone\\n";
    return 0;
}
''', '''buffer is 16 bytes, holding raw storage
constructed (1,2)
constructed (3,4)
first 1,2 second 3,4
destroyed (1,2)
destroyed (3,4)
storage is still ours, the objects are gone'''),
            exp("Where you meet it in the standard library\n\n"
                "std::optional<T> is a buffer plus a bool. std::variant is a buffer plus a "
                "tag. std::vector's capacity is allocated storage with n constructed objects "
                "in it.\n\n"
                "Writing them by hand is a good exercise and a bad habit - the standard "
                "versions handle the exception-safety paths that are easy to get wrong."),
            CHALLENGE,
            code('''#include <iostream>
#include <new>
#include <string>

class Slot {
public:
    void put(const std::string& value) {
        if (!filled_) {
            new (&storage_) std::string(value);
            filled_ = true;
        } else {
            *reinterpret_cast<std::string*>(&storage_) = value;
        }
    }
    const std::string& get() const {
        return *reinterpret_cast<const std::string*>(&storage_);
    }
    bool filled() const { return filled_; }
    ~Slot() {
        if (filled_) {
            reinterpret_cast<std::string*>(&storage_)->~basic_string();
        }
    }
private:
    alignas(std::string) unsigned char storage_[sizeof(std::string)];
    bool filled_ = false;
};

int main() {
    Slot slot;
    std::cout << "filled before put: " << (slot.filled() ? "yes" : "no") << "\\n";
    slot.put("stored in raw bytes");
    std::cout << "filled after put: " << (slot.filled() ? "yes" : "no") << "\\n";
    std::cout << "value: " << slot.get() << "\\n";
    return 0;
}
''', '''filled before put: no
filled after put: yes
value: stored in raw bytes'''),
            quiz("What does placement new do that ordinary new does not?",
                 ["Nothing, they are the same", "It constructs into storage you already have, "
                  "performing no allocation", "It allocates more memory", "It skips the "
                  "constructor"],
                 1, "It separates construction from allocation, which is what containers with "
                    "unused capacity rely on."),
           ]),

    lesson("92304", 98, "Lifetime", "Unions, Variants and What Ends a Lifetime",
           "One buffer, several possible types, and the rules for switching between them.",
           ["Say what a union stores and what it does not track.",
            "Switch the active member correctly, including non-trivial types.",
            "Explain why std::variant is almost always the better answer."],
           [exp("One storage, one member at a time\n\n"
                "A union's size is the size of its largest member, and only one member is "
                "alive at a time. The union does not record which one - that is your job, "
                "which is exactly where the bugs live.\n\n"
                "Reading a member that is not the active one is undefined behaviour, and for "
                "class types you must construct and destroy them explicitly: a union does not "
                "call constructors or destructors for you.\n\n"
                "std::variant does all of that bookkeeping, throws std::bad_variant_access on "
                "a wrong read, and is the right tool unless you are writing the variant "
                "itself."),
            dfn("Active member", "The member of a union whose lifetime is current; reading any "
                                 "other member is undefined behaviour."),
            exp("A union with a tag, and a variant doing the same job\n\n"
                "The union plus an enum tag is the classic C pattern: the tag says which "
                "member is alive, and every read checks it first.\n\n"
                "The variant below stores the same two alternatives with none of that "
                "bookkeeping, and std::get throws instead of misbehaving when the type is "
                "wrong."),
            code('''#include <iostream>
#include <variant>

enum class Kind { number, text };

struct Tagged {
    Kind kind;
    union {
        int number;
        const char* text;
    };
};

void show(const Tagged& value) {
    if (value.kind == Kind::number) {
        std::cout << "number " << value.number << "\\n";
    } else {
        std::cout << "text " << value.text << "\\n";
    }
}

int main() {
    Tagged a{Kind::number, {}};
    a.number = 42;
    Tagged b{Kind::text, {}};
    b.text = "forty two";
    show(a);
    show(b);

    std::variant<int, const char*> safe = 42;
    std::cout << "variant holds " << std::get<int>(safe) << " at index "
              << safe.index() << "\\n";
    safe = "now text";
    std::cout << "variant holds " << std::get<const char*>(safe) << " at index "
              << safe.index() << "\\n";
    try {
        std::get<int>(safe);
    } catch (const std::bad_variant_access&) {
        std::cout << "wrong type was refused, not read\\n";
    }
    return 0;
}
''', '''number 42
text forty two
variant holds 42 at index 0
variant holds now text at index 1
wrong type was refused, not read'''),
            exp("What ends a lifetime\n\n"
                "An object's lifetime ends when its destructor runs, when its storage is "
                "released, or when the storage is reused by another object. After that the "
                "bytes may still look right - which is why use-after-free so often appears "
                "to work.\n\n"
                "This is why std::launder exists: after placement new into the same storage, "
                "an old pointer may not point to the new object according to the optimiser's "
                "assumptions. Modern containers use it; application code rarely needs it, and "
                "should prefer variant, optional and vector."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <variant>

using Value = std::variant<int, std::string>;

std::string describe(const Value& value) {
    if (std::holds_alternative<int>(value)) {
        return "int " + std::to_string(std::get<int>(value));
    }
    return "string " + std::get<std::string>(value);
}

int main() {
    Value first = 7;
    Value second = std::string("seven");
    std::cout << describe(first) << "\\n";
    std::cout << describe(second) << "\\n";
    std::cout << "index of the string alternative: " << second.index() << "\\n";
    std::cout << "visiting size: "
              << std::visit([](const auto& v) { return sizeof(v); }, first) << " bytes\\n";
    return 0;
}
''', '''int 7
string seven
index of the string alternative: 1
visiting size: 4 bytes'''),
            quiz("What does a union NOT do?",
                 ["Share storage between members", "Record which member is currently alive",
                  "Take the size of its largest member", "Allow class types"],
                 1, "Tracking the active member is the programmer's job - which is why "
                    "std::variant exists."),
           ]),
]
