"""Assemble shepherd.cpp-revision-01 from the three gap-fill modules."""
import json
from pathlib import Path

import r01a, r01b, r01c, r01d
from kit import CID, VERSION

LESSON_GROUPS = (r01a.LESSONS + r01d.CORE
                 + r01b.LESSONS + r01d.LIBRARY
                 + r01c.LESSONS + r01d.PRACTICE)

MODULE_TITLES = {
    90: "Language Core Gaps",
    91: "Standard Library Gaps",
    92: "Practice Gaps",
}

def normalise(entry):
    """Prose must contain real newlines. A literal backslash-n would be printed."""
    for block in entry["body"]:
        if block.get("kind") in {"explanation", "definition"}:
            for field in ("text",):
                value = block.get(field)
                if isinstance(value, str) and "\\n" in value:
                    block[field] = value.replace("\\n", "\n")
    return entry


lessons = []
for index, entry in enumerate(LESSON_GROUPS, 1):
    entry = normalise(dict(entry))
    level = entry.pop("_level")
    topic = entry.pop("_topic")
    entry["prerequisites"] = [lessons[-1]["id"]] if lessons else []
    entry["_level"] = level
    entry["_topic"] = topic
    lessons.append(entry)

items = [{
    "id": CID,
    "kind": "course",
    "title": "C++ Revision — Language Core and Library Gaps",
    "revision": 1,
    "summary": "28 revision lessons that close the gaps left between Levels 9 and 20: "
               "type aliases, decltype, value categories, alignment and byte order, bit "
               "masks, the missing algorithms, variant and any, string_view, the "
               "preprocessor, iterator-generic code, testing, and the topics the master "
               "roadmap lists that no earlier part reached.",
    "objectives": ["Name types exactly with using, decltype and structured bindings.",
                   "Use alignment, byte order and bit masks deliberately.",
                   "Reach for the algorithm you actually need, not only find and sort.",
                   "Write code that works on any container's iterators.",
                   "Test with fixtures, generated cases and property checks."],
    "difficulty": "advanced",
    "estimated_minutes": 600,
}]
items.append({"id": f"{CID}.section.001", "kind": "section",
              "title": "Revision and Gap Fill", "revision": 1, "parent_id": CID})

topic_ids = {}
module_ids = {}

for entry in lessons:
    level, topic = entry.pop("_level"), entry.pop("_topic")
    if level not in module_ids:
        module_id = f"{CID}.module.{level:03d}"
        module_ids[level] = module_id
        items.append({"id": module_id, "kind": "module", "title": MODULE_TITLES[level],
                      "revision": 1, "parent_id": f"{CID}.section.001"})
    if (level, topic) not in topic_ids:
        number = sum(1 for (other_level, _) in topic_ids if other_level == level) + 1
        topic_id = f"{CID}.topic.{level}{number:02d}"
        topic_ids[(level, topic)] = topic_id
        items.append({"id": topic_id, "kind": "topic", "title": topic,
                      "revision": 1, "parent_id": module_ids[level]})
    entry["parent_id"] = topic_ids[(level, topic)]
    items.append(entry)

manifest = {
    "schema_version": 2,
    "format": "shepherd.course",
    "id": CID,
    "module_id": "programming-languages",
    "version": VERSION,
    "locale": "en",
    "subjects": [{"id": "programming-languages", "category": "language"}],
    "authors": ["Shepherd Coding Academy"],
    "license": "MIT",
    "authoring": {
        "specification_id": CID + ".spec",
        "specification_version": "1.0.0",
        "allocations": [{
            "batch_id": CID + ".batch.001",
            "section_id": CID + ".section.001",
            "allowed_ids": [item["id"] for item in items],
        }],
    },
    "batches": [{
        "id": CID + ".batch.001", "schema_version": 2, "course_id": CID,
        "specification_id": CID + ".spec", "specification_version": "1.0.0",
        "section_id": CID + ".section.001",
        "item_ids": [item["id"] for item in items],
        "author": "Shepherd Coding Academy",
    }],
    "items": items,
}
target = Path(__file__).resolve().parent / "manifest.json"
target.write_text(json.dumps(manifest, indent=2, ensure_ascii=False) + "\n",
                  encoding="utf-8")
print(f"lessons: {len(lessons)} | items: {len(items)} | modules: {len(module_ids)} "
      f"| topics: {len(topic_ids)}")
