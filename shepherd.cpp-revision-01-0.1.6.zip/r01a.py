"""Gap fill part 1 of 3 — Language Core Gaps."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("90001", 90, "Names and enums", "Type Aliases: typedef and using",
           "Give a long type a short name, and read other people's code without guessing.",
           ["Write an alias with using.",
            "Explain how typedef differs from using.",
            "Say when an alias helps and when it hides too much."],
           [exp("A second name for one type\n\n"
                "using Score = int; does not create a new type. It creates another name "
                "for the same type, so a Score is an int in every way that matters to the "
                "compiler.\n\n"
                "The old form is typedef int Score; and it does the same job. The modern "
                "form is preferred because it reads left to right, and because it handles "
                "function pointers and templates where typedef becomes unreadable.\n\n"
                "Aliases exist so a reader can see the intent: a Score means a score, "
                "even though the machine sees an int."),
            dfn("Type alias", "A second name for an existing type, written with using or "
                              "typedef. It introduces no new type."),
            exp("The form that only using can express\n\n"
                "Adding the two numbers naively gives 57, because both sides are text: "
                "they concatenate. Convert before adding.\n\n"
                "An alias for a function pointer is the case where typedef is genuinely "
                "painful: with using it reads as the name followed by the signature."),
            code('''#include <iostream>
#include <string>

using Score = int;
typedef std::string Name;

Score double_score(Score value) {
    return value * 2;
}

int main() {
    Score first = 21;
    Name who = "ada";
    std::cout << who << " " << double_score(first) << "\\n";
    std::cout << sizeof(Score) << " bytes\\n";
    return 0;
}
''', '''ada 42
4 bytes'''),
            exp("Two names, one type\n\n"
                "Because the alias introduces nothing new, a function taking Score accepts "
                "an int and vice versa. There is no conversion and no protection.\n\n"
                "That is deliberate: an alias documents intent, it does not enforce it. If "
                "you want a type that cannot be mixed with its underlying type, that is a "
                "different tool — a wrapper struct — not an alias."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

template <typename T>
using Table = std::vector<std::vector<T>>;

int main() {
    Table<int> grid{{1, 2}, {3, 4}};
    std::cout << grid.size() << " rows\\n";
    std::cout << grid[1][0] << "\\n";
    return 0;
}
''', '''2 rows
3'''),
            quiz("What does using Score = int; create?",
                 ["A new type with its own rules", "Another name for the existing type int",
                  "A conversion function", "A class"],
                 1, "An alias is a synonym: the compiler still sees int, and no new type "
                    "exists."),
           ]),

    lesson("90002", 90, "Names and enums", "enum, enum class and Underlying Types",
           "Unguarded enums leak their names; scoped enums do not, and they can be typed.",
           ["Declare a scoped enum with a chosen underlying type.",
            "Explain what a plain enum leaks into the enclosing scope.",
            "Convert between an enum and its number deliberately."],
           [exp("Two kinds of enumeration\n\n"
                "A plain enum puts its names into the surrounding scope, converts to int "
                "without being asked, and lets two enums declare the same name only if you "
                "are unlucky with ordering. That is the C heritage.\n\n"
                "A scoped enum, written enum class, keeps its names inside the enum, does "
                "not convert implicitly, and can state its underlying type: uint8_t for a "
                "compact one, int by default.\n\n"
                "Use enum class almost always. Reach for a plain enum only when you are "
                "matching an existing C interface."),
            dfn("Underlying type", "The integer type an enumeration is stored as, chosen "
                                   "with enum class Colour : unsigned char."),
            exp("What the scoping buys\n\n"
                "With enum class, Traffic::Red and Light::Red can coexist, and neither is "
                "silently an int. Converting to the number requires a cast, which is "
                "written where a reader can see it.\n\n"
                "The underlying type is chosen here as unsigned char, so the enum occupies "
                "one byte instead of four — worth knowing when it is stored in a file or a "
                "packet."),
            code('''#include <iostream>

enum class Traffic : unsigned char { red, amber, green };
enum class Light : unsigned char { red, green };

int main() {
    Traffic signal = Traffic::amber;
    Light lamp = Light::red;
    std::cout << static_cast<int>(signal) << "\\n";
    std::cout << static_cast<int>(lamp) << "\\n";
    std::cout << sizeof(Traffic) << " byte\\n";
    std::cout << (signal == Traffic::amber ? "amber" : "not amber") << "\\n";
    return 0;
}
''', '''1
0
1 byte
amber'''),
            exp("Converting back from a number\n\n"
                "Reading a value from a file or a packet gives a number, and it may not be "
                "a valid enumerator. Converting it back is deliberate and must be checked: "
                "a cast alone accepts 99 as a valid Traffic.\n\n"
                "The function below validates the range first, which is the difference "
                "between parsing and hoping."),
            CHALLENGE,
            code('''#include <iostream>
#include <optional>

enum class Traffic : unsigned char { red, amber, green };

std::optional<Traffic> from_number(int value) {
    if (value < 0 || value > 2) {
        return std::nullopt;
    }
    return static_cast<Traffic>(value);
}

int main() {
    std::cout << (from_number(2).has_value() ? "valid" : "invalid") << "\\n";
    std::cout << (from_number(9).has_value() ? "valid" : "invalid") << "\\n";
    return 0;
}
''', '''valid
invalid'''),
            quiz("What does enum class change compared with a plain enum?",
                 ["It stores strings instead of numbers", "Its names stay inside the enum "
                  "and it does not convert to int implicitly", "It cannot be compared",
                  "It must have fewer than four values"],
                 1, "Scoping and the ban on implicit conversion are the two practical "
                    "differences, plus the ability to state the underlying type."),
           ]),

    lesson("90003", 90, "Deduction", "decltype and decltype(auto)",
           "Ask the compiler what a type is, and keep the difference between a value and a reference.",
           ["Use decltype to name the type of an expression.",
            "Explain why decltype accepts an expression that is not evaluated.",
            "Tell decltype apart from auto."],
           [exp("The type of an expression, exactly\n\n"
                "auto and decltype both deduce a type, but they answer different questions. "
                "auto follows the rules of assignment: it drops a reference and drops "
                "const. decltype reports the type of the expression precisely, including "
                "the reference.\n\n"
                "Nothing inside decltype is evaluated: the expression is only examined for "
                "its type. That is why it can name the result type of a function before any "
                "value exists.\n\n"
                "It is most useful in templates, where the type depends on a parameter you "
                "cannot spell."),
            dfn("decltype", "An operator that yields the declared type of an expression "
                            "without evaluating it, keeping references and const."),
            exp("Reference or not\n\n"
                "The same expression gives int through auto and int& through decltype, "
                "because the expression is an lvalue referring to an existing object.\n\n"
                "That difference is what makes decltype usable for returning references "
                "from a function template: with auto, the reference would be lost and the "
                "caller would get a copy without knowing it."),
            code('''#include <iostream>
#include <string>

int main() {
    int number = 7;
    auto by_auto = number;
    decltype(number) by_decltype = number;
    decltype((number)) by_reference = number;
    by_reference = 9;
    std::cout << typeid(by_auto).name() << " " << by_auto << "\\n";
    std::cout << typeid(by_decltype).name() << " " << by_decltype << "\\n";
    std::cout << "number is now " << number << "\\n";
    return 0;
}
''', '''i 7
i 7
number is now 9'''),
            exp("decltype(auto) keeps the reference\n\n"
                "decltype(auto) is the form to use when a name must have exactly the type "
                "of the expression - reference included - which is what a forwarding "
                "return type needs.\n\n"
                "The rule is the parentheses. An unparenthesised name gives its declared "
                "type, so decltype(auto) copy = sentence copies. A parenthesised name is an "
                "lvalue expression, so decltype(auto) reference = (sentence) is a "
                "reference.\n\n"
                "The rule of thumb: auto for a new local value, decltype(auto) for a type "
                "that must match an expression exactly."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>

int main() {
    std::string sentence = "hello world";
    decltype(auto) reference = (sentence);
    reference += "!";
    std::cout << "through the reference: " << sentence << "\\n";
    auto copy = sentence;
    copy += "?";
    std::cout << "through the copy:      " << sentence << "\\n";
    std::cout << "copy holds:            " << copy << "\\n";
    return 0;
}
''', '''through the reference: hello world!
through the copy:      hello world!
copy holds:            hello world!?'''),
            quiz("What does auto do that decltype does not?",
                 ["It evaluates the expression", "It drops references and top-level const",
                  "It requires a type name", "It works only with numbers"],
                 1, "auto follows the deduction rules for by-value initialisation; "
                    "decltype reports the expression's exact type."),
           ]),

    lesson("90004", 90, "Deduction", "Structured Bindings Done Properly",
           "Unpack a pair, a tuple or a struct in one declaration — and know what you get.",
           ["Unpack a pair and a struct with structured bindings.",
            "Explain whether the names are copies or references.",
            "Use the form that avoids copying a large member."],
           [exp("One declaration, several names\n\n"
                "auto [name, score] = entry; declares both names at once, taken from the "
                "pair's first and second or from the struct's members in order.\n\n"
                "The question that matters is what those names refer to. With plain auto, "
                "the whole object is copied and the names refer into the copy. With "
                "auto&, they refer into the original, so writing to them changes it.\n\n"
                "That single ampersand is the difference between reading and changing."),
            dfn("Structured binding", "A declaration that introduces several names at once "
                                      "from a pair, tuple, array or plain struct."),
            exp("Copy, reference, const reference\n\n"
                "The bound names are views into an object. With auto they view a copy, so "
                "assigning to score leaves the map untouched. With auto& they view the "
                "original, and the map changes.\n\n"
                "Note that the members are taken in declaration order, not by name, which "
                "is why structured bindings depend on the order of the struct."),
            code('''#include <iostream>
#include <string>
#include <utility>

struct Player {
    std::string name;
    int score;
};

int main() {
    Player player{"ada", 90};
    auto [name, score] = player;
    score = 0;
    std::cout << player.name << " " << player.score << "\\n";
    std::cout << name << " " << score << "\\n";

    auto& [same_name, same_score] = player;
    same_score = 75;
    std::cout << player.score << "\\n";
    return 0;
}
''', '''ada 90
ada 0
75'''),
            exp("The reference you want when the member is big\n\n"
                "Binding a std::string by value copies the text. const auto& avoids the "
                "copy and still cannot change it, which is the form to use in a loop over "
                "a container.\n\n"
                "This is the same rule as passing parameters, applied to unpacking: read "
                "with a const reference, write with a reference, and copy only when you "
                "mean to."),
            CHALLENGE,
            code('''#include <iostream>
#include <map>
#include <string>

int main() {
    std::map<std::string, int> scores{{"ada", 90}, {"bo", 81}};
    int total = 0;
    for (const auto& [name, score] : scores) {
        std::cout << name << "=" << score << " ";
        total += score;
    }
    std::cout << "\\ntotal " << total << "\\n";
    return 0;
}
''', '''ada=90 bo=81 
total 171'''),
            quiz("What do the names in auto [a, b] = pair; refer to?",
                 ["The original members, by reference", "Members of a copy of the pair",
                  "Nothing until assigned", "The pair's type"],
                 1, "Plain auto copies the whole object, so the names view the copy; "
                    "auto& makes them view the original."),
           ]),

    lesson("90005", 90, "Expressions", "Value Categories in One Lesson",
           "lvalue, prvalue and xvalue decide what can bind to what.",
           ["Name the value category of a simple expression.",
            "Explain which expressions can be moved from.",
            "Describe why std::move is a cast to an xvalue."],
           [exp("Three answers to one question\n\n"
                "Every expression has a value category, and the category decides what it "
                "can bind to. An lvalue has a name you can keep using: a variable. A "
                "prvalue produces a fresh temporary with no home: 2 + 3.\n\n"
                "An xvalue is an object that is about to expire - typically something you "
                "wrote std::move around. It still exists, but you have promised not to "
                "use it afterwards.\n\n"
                "The practical consequence: only an lvalue binds to T&, an rvalue "
                "reference binds to the other two, and moving is only possible from "
                "something the compiler believes will not be used again."),
            dfn("Value category", "lvalue, prvalue or xvalue: a classification of every "
                                  "expression that decides what it can bind to and "
                                  "whether it may be moved from."),
            exp("Seeing the categories in code\n\n"
                "A reference overload pair shows which category arrived: the named "
                "variable goes to the const& version, the arithmetic goes to &&, and "
                "std::move turns the named variable into an xvalue so it takes the second "
                "path too.\n\n"
                "Nothing is moved here; the print is only reporting the category the "
                "compiler chose."),
            code('''#include <iostream>
#include <string>
#include <utility>

void describe(const std::string&) { std::cout << "lvalue\\n"; }
void describe(std::string&&) { std::cout << "rvalue\\n"; }

int main() {
    std::string name = "ada";
    describe(name);
    describe(name + "!");
    describe(std::move(name));
    static_cast<void>(name);
    return 0;
}
''', '''lvalue
rvalue
rvalue'''),
            exp("Why the xvalue exists\n\n"
                "Without a third category there would be no way to say 'this object still "
                "exists and I still have its address, but I am finished with it'. That is "
                "exactly the promise a move constructor needs in order to take its "
                "internals.\n\n"
                "std::move is therefore a cast to an xvalue and nothing more. std::forward "
                "is the other half of the story: it preserves the category through a "
                "function, which is what makes forwarding work."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <utility>
#include <vector>

int main() {
    std::vector<std::string> names;
    std::string kept = "ada";
    names.push_back(kept);
    names.push_back(std::move(kept));
    names.push_back(std::string("cy"));
    std::cout << names.size() << " names\\n";
    std::cout << "kept is now " << (kept.empty() ? "empty" : "unchanged") << "\\n";
    return 0;
}
''', '''3 names
kept is now empty'''),
            quiz("What is std::move(a) in terms of value categories?",
                 ["A copy of a", "An xvalue referring to a",
                  "A prvalue temporary", "An lvalue"],
                 1, "It is a cast to an rvalue reference, giving an xvalue: the object "
                    "still exists but may be moved from."),
           ]),

    lesson("90006", 90, "Memory", "Alignment, alignof and Padding",
           "Objects start at addresses the processor likes, and the gaps cost memory.",
           ["Query alignment with alignof.",
            "Explain why a struct is larger than the sum of its members.",
            "Reorder members to reduce padding."],
           [exp("Addresses have rules\n\n"
                "A type has an alignment requirement: an int usually needs a 4-byte "
                "boundary, a double 8. The compiler inserts padding between members so "
                "every member starts where the hardware requires.\n\n"
                "That is why sizeof of a struct is often larger than the sum of its "
                "members. The wasted bytes are real: a million of those structs wastes "
                "megabytes.\n\n"
                "alignof answers what a type requires; alignas asks for more."),
            dfn("Alignment", "The byte boundary an object's address must satisfy. "
                             "alignof(Type) reports it; alignas(N) requests it."),
            exp("Where the bytes go\n\n"
                "Two chars and an int: the chars occupy 1 and 2 bytes, then padding fills "
                "up to 4, and the int takes 4. The total is 8 rather than 6.\n\n"
                "Reordering the members so the int comes first gives the same total here. "
                "The saving appears when the sizes are more varied, and measuring is how "
                "you find it."),
            code('''#include <iostream>

struct Loose {
    char first;
    int number;
    char second;
};

struct Tight {
    int number;
    char first;
    char second;
};

int main() {
    std::cout << sizeof(char) << " " << alignof(char) << "\\n";
    std::cout << sizeof(int) << " " << alignof(int) << "\\n";
    std::cout << sizeof(double) << " " << alignof(double) << "\\n";
    std::cout << sizeof(Loose) << " " << sizeof(Tight) << "\\n";
    return 0;
}
''', '''1 1
4 4
8 8
12 8'''),
            exp("Asking for more\n\n"
                "alignas(16) forces an object onto a 16-byte boundary, which is what SIMD "
                "instructions and some hardware buffers require. The cost is more memory, "
                "and it is only worth paying when a device or an instruction set asks for "
                "it.\n\n"
                "A struct also takes the alignment of its most demanding member, which is "
                "why adding a double can double the size of a small struct."),
            CHALLENGE,
            code('''#include <iostream>

struct alignas(16) Aligned {
    int values[2];
};

int main() {
    std::cout << alignof(Aligned) << " alignment\\n";
    std::cout << sizeof(Aligned) << " bytes\\n";
    std::cout << (sizeof(Aligned) % alignof(Aligned) == 0 ? "size is a multiple"
                                                          : "odd size") << "\\n";
    return 0;
}
''', '''16 alignment
16 bytes
size is a multiple'''),
            quiz("Why is a struct often larger than the sum of its members?",
                 ["The compiler adds a header", "Padding is inserted so each member meets "
                  "its alignment requirement", "Names are stored in it",
                  "It reserves room for methods"],
                 1, "Members must start at suitably aligned addresses, and the gaps are "
                    "counted in sizeof."),
           ]),

    lesson("90007", 90, "Memory", "Bytes, std::byte and Endianness",
           "Look at an object as raw bytes, and see which end comes first.",
           ["Inspect an object through std::byte.",
            "Explain endianness in one sentence.",
            "Name the reason byte order matters at a boundary."],
           [exp("The object, byte by byte\n\n"
                "std::byte is a distinct type for raw memory: it is not a number, so it "
                "cannot be accidentally added or printed as a character. It exists so that "
                "byte inspection is visibly different from arithmetic.\n\n"
                "Reading an int through unsigned char pointers shows which byte holds the "
                "least significant part. On almost every machine you will meet, the "
                "least significant byte comes first: little endian.\n\n"
                "That matters the moment bytes leave the program - to a file, a network, "
                "or another machine."),
            dfn("Endianness", "The order in which the bytes of a multi-byte value are "
                              "stored: little endian puts the least significant first, big "
                              "endian the most significant first."),
            exp("What the bytes look like\n\n"
                "The number 0x01020304 has four bytes. Written out one at a time on a "
                "little-endian machine they read 04 03 02 01: the value's least significant "
                "byte appears first in memory.\n\n"
                "The program prints whether the machine is little endian rather than "
                "assuming it, which is the habit worth taking away."),
            code('''#include <cstddef>
#include <cstdint>
#include <iostream>

int main() {
    std::uint32_t value = 0x01020304;
    const auto* bytes = reinterpret_cast<const unsigned char*>(&value);
    for (std::size_t i = 0; i < sizeof(value); ++i) {
        std::cout << std::hex << static_cast<int>(bytes[i]) << " ";
    }
    std::cout << std::dec << "\\n";
    std::cout << ((bytes[0] == 0x04) ? "little endian" : "big endian") << "\\n";
    std::cout << sizeof(std::byte) << " byte per std::byte\\n";
    return 0;
}
''', '''4 3 2 1 
little endian
1 byte per std::byte'''),
            exp("Why a boundary changes everything\n\n"
                "Inside one program the byte order is whatever the machine does, and "
                "nobody cares. The moment bytes are written to a file that another program "
                "reads, or sent to a machine of the other kind, the order must be agreed "
                "and converted deliberately.\n\n"
                "This is the reason file formats and network protocols state their byte "
                "order in the specification rather than leaving it to the machine."),
            CHALLENGE,
            code('''#include <cstddef>
#include <iostream>

int main() {
    int value = 1;
    const auto* bytes = reinterpret_cast<const unsigned char*>(&value);
    bool little = bytes[0] == 1;
    std::cout << (little ? "least significant byte first" : "most significant byte first")
              << "\\n";
    std::cout << "size " << sizeof(value) << "\\n";
    return 0;
}
''', '''least significant byte first
size 4'''),
            quiz("Why must byte order be agreed when writing a file format?",
                 ["Because files are always big endian", "Because machines differ, and the "
                  "reader may store the opposite order", "Because text needs it",
                  "Because the compiler chooses"],
                 1, "Inside one process the order is invisible; across a boundary it "
                    "decides what the numbers mean."),
           ]),

    lesson("90008", 90, "Memory", "Bit Masks, Flags and bitset",
           "Pack several true/false facts into one number and read them back.",
           ["Set, clear and test a bit with a mask.",
            "Explain the shifts that build a mask.",
            "Use std::bitset when the width is known."],
           [exp("One bit, one fact\n\n"
                "A mask is a number with a single bit set: 1u << 3 is the fourth bit. The "
                "three operations are and for testing, or for setting, and and-not for "
                "clearing.\n\n"
                "Written this way, eight independent facts fit in one byte instead of "
                "eight bools, which matters in file formats, protocols and anything "
                "measuring memory.\n\n"
                "The habit that prevents confusion: always write the shift, never the "
                "decimal 8. The reader should see which bit is meant."),
            dfn("Bit mask", "A value with specific bits set, used with &, | and ~ to test, "
                            "set or clear those bits."),
            exp("The three operations\n\n"
                "flags starts at zero. Setting the bits for read and write gives 3, since "
                "they are bits 0 and 1. Testing read with a mask gives a non-zero result, "
                "and clearing it leaves write set.\n\n"
                "The test compares against a mask, not against zero, so it stays correct "
                "when other bits are also set."),
            code('''#include <iostream>

int main() {
    unsigned int flags = 0;
    const unsigned int read_bit = 1u << 0;
    const unsigned int write_bit = 1u << 1;
    const unsigned int exec_bit = 1u << 2;

    flags |= read_bit;
    flags |= write_bit;
    std::cout << flags << "\\n";
    std::cout << ((flags & read_bit) ? "read on" : "read off") << "\\n";
    flags &= ~read_bit;
    std::cout << ((flags & read_bit) ? "read on" : "read off") << "\\n";
    std::cout << ((flags & exec_bit) ? "exec on" : "exec off") << "\\n";
    return 0;
}
''', '''3
read on
read off
exec off'''),
            exp("When the width is known\n\n"
                "std::bitset<8> gives names to the operations and prints the bits, which "
                "makes the intent clear and the debugging easy. The size is fixed at "
                "compile time, which is exactly when it is the right tool.\n\n"
                "It also answers questions you would otherwise write loops for: count, "
                "any, all, and to_string."),
            CHALLENGE,
            code('''#include <bitset>
#include <iostream>

int main() {
    std::bitset<8> flags;
    flags.set(0);
    flags.set(3);
    std::cout << flags << "\\n";
    std::cout << flags.count() << " bits set\\n";
    std::cout << (flags.test(3) ? "bit 3 is on" : "bit 3 is off") << "\\n";
    flags.flip(0);
    std::cout << flags.to_string() << "\\n";
    return 0;
}
''', '''00001001
2 bits set
bit 3 is on
00001000'''),
            quiz("What does flags & ~mask do?",
                 ["Sets the masked bit", "Clears the masked bit", "Flips every bit",
                  "Tests the masked bit"],
                 1, "~mask inverts the mask so the and clears exactly that bit and leaves "
                    "the rest alone."),
           ]),
]
