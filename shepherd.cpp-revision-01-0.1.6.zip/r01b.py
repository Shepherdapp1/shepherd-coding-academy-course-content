"""Gap fill part 2 of 3 — Standard Library Gaps."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("91001", 91, "Iterators", "Iterator Categories and Invalidation",
           "What an iterator can do decides which algorithms accept it.",
           ["Name the five iterator categories in order of power.",
            "Explain what invalidation is and give one example.",
            "Say why cbegin and cend exist."],
           [exp("A ladder of abilities\n\n"
                "Iterators are ranked by what they can do. An input iterator can only be "
                "read once, forwards. A forward iterator can be read repeatedly. A "
                "bidirectional iterator can also go backwards. A random-access iterator can "
                "jump by an offset, and a contiguous one guarantees the elements are "
                "adjacent in memory.\n\n"
                "Every algorithm states the category it needs, and that is why std::sort "
                "refuses a std::list: sorting needs random access, and a list only offers "
                "bidirectional.\n\n"
                "A vector's iterators are contiguous, a deque's are random access but not "
                "contiguous, and a list's are bidirectional."),
            dfn("Iterator category", "The set of operations an iterator supports, which "
                                     "decides the algorithms it can be given to."),
            dfn("Invalidation", "A change to the container that makes existing iterators "
                                "point at nothing valid."),
            exp("What grows, what breaks\n\n"
                "Growing a vector may move its whole buffer, so every iterator into it "
                "becomes invalid: using one afterwards is undefined behaviour. A deque's "
                "iterators survive growth at the ends but not insertion in the middle.\n\n"
                "rbegin and rend walk a container from the last element to the first "
                "without copying it or reversing it, which is the answer to 'print it "
                "backwards' in one line.\n\n"
                "cbegin and cend return const iterators, which cannot be used to modify "
                "what they point at. That is a promise to the reader, checked by the "
                "compiler."),
            code('''#include <deque>
#include <iostream>
#include <list>
#include <string>
#include <vector>

int main() {
    std::vector<int> values{1, 2, 3};
    auto it = values.begin();
    std::cout << *it << " at index " << (it - values.begin()) << "\\n";
    values.reserve(10);
    values.push_back(4);
    it = values.begin();
    std::cout << *it << " at index " << (it - values.begin()) << " after reserve\\n";

    std::list<std::string> names{"ada", "bo"};
    for (auto iterator = names.cbegin(); iterator != names.cend(); ++iterator) {
        std::cout << *iterator << " ";
    }
    std::cout << "\\n";

    std::vector<int> backwards{1, 2, 3};
    for (auto it = backwards.rbegin(); it != backwards.rend(); ++it) {
        std::cout << *it << " ";
    }
    std::cout << "<- reverse iterators\\n";

    std::deque<int> both{1, 2};
    std::cout << (both.begin() < both.end() ? "random access" : "?") << "\\n";
    return 0;
}
''', '''1 at index 0
1 at index 0 after reserve
ada bo 
3 2 1 <- reverse iterators
random access'''),
            exp("The rule to remember\n\n"
                "Any operation that can reallocate invalidates every iterator into the "
                "container; any operation that inserts or erases invalidates those at and "
                "after the point of change for most containers.\n\n"
                "The practical habit is to re-take an iterator after modifying a "
                "container, rather than holding one across a modification."),
            CHALLENGE,
            code('''#include <iostream>
#include <iterator>
#include <list>
#include <vector>

int main() {
    std::vector<int> values{1, 2, 3, 4};
    std::cout << std::distance(values.begin(), values.end()) << " steps\\n";
    std::list<int> chain{1, 2, 3};
    std::cout << std::distance(chain.begin(), chain.end()) << " steps\\n";
    auto middle = std::next(values.begin(), 2);
    std::cout << *middle << "\\n";
    return 0;
}
''', '''4 steps
3 steps
3'''),
            quiz("Which container cannot be given to std::sort?",
                 ["std::vector", "std::deque", "std::list", "A built-in array"],
                 2, "A list provides bidirectional but not random-access iterators, and "
                    "std::sort requires random access."),
           ]),

    lesson("91002", 91, "Algorithms", "Copy, Fill, Replace, Rotate",
           "The modification algorithms, and the one that silently does nothing you expect.",
           ["Copy a range between containers.",
            "Fill and replace in place.",
            "Rotate a range around a point."],
           [exp("Moving values around\n\n"
                "std::copy writes one range into another, std::fill sets every element to "
                "one value, and std::replace swaps every match for a new value.\n\n"
                "std::rotate turns a range so that a chosen element becomes the first. It "
                "is the honest way to move a block to the front without an insert and an "
                "erase.\n\n"
                "All of them are the loop you would have written, with the boundary cases "
                "already handled."),
            dfn("Range", "A pair of iterators marking where work starts and where it "
                         "stops. The end is not included."),
            exp("Rotate in practice\n\n"
                "Rotating to begin at the middle turns 1 2 3 4 5 into 3 4 5 1 2. That is "
                "one call instead of a hand-written three-step shuffle.\n\n"
                "The output range of copy must already have room. copy does not resize a "
                "destination container, and writing past its end is undefined behaviour."),
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{1, 2, 3, 4, 5};
    std::rotate(values.begin(), values.begin() + 2, values.end());
    for (int value : values) {
        std::cout << value << " ";
    }
    std::cout << "\\n";

    std::vector<int> copy_of(5);
    std::copy(values.begin(), values.end(), copy_of.begin());
    std::cout << copy_of[0] << " " << copy_of[4] << "\\n";

    std::replace(copy_of.begin(), copy_of.end(), 4, 40);
    std::cout << copy_of[1] << "\\n";
    return 0;
}
''', '''3 4 5 1 2 
3 2
40'''),
            exp("Filling and resizing together\n\n"
                "std::fill does not add elements either. To make a container of a given "
                "size, ask for the size at construction and fill afterwards, or use "
                "resize first.\n\n"
                "This is the one place where the library is less forgiving than it looks: "
                "it works on whatever room you have already given it."),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> values(4);
    std::fill(values.begin(), values.end(), 7);
    std::fill_n(values.begin() + 1, 2, 0);
    for (int value : values) {
        std::cout << value << " ";
    }
    std::cout << "\\n";
    std::cout << std::count(values.begin(), values.end(), 7) << " sevens\\n";
    return 0;
}
''', '''7 0 0 7 
2 sevens'''),
            quiz("What does std::copy do if the destination is too small?",
                 ["It grows the destination", "It throws",
                  "It writes past the end — undefined behaviour", "It stops early"],
                 1, "The library writes where you tell it; giving it too little room is "
                    "a memory error, not an exception."),
           ]),

    lesson("91003", 91, "Algorithms", "Sorting Beyond sort",
           "Get the top three, or put one element where it belongs, without sorting everything.",
           ["Use partial_sort for the smallest few.",
            "Use nth_element to find a median without a full sort.",
            "Explain when these beat a full sort."],
           [exp("Sorting less than everything\n\n"
                "A full sort of a million values to read the top three is wasted work. "
                "partial_sort orders only the first few and leaves the rest alone, which is "
                "the right tool for a leaderboard.\n\n"
                "nth_element is stranger and more useful: it puts the element that belongs "
                "at position n in that position, with smaller values before it and larger "
                "after - without sorting either side. That is how a median is found in "
                "linear time on average.\n\n"
                "Both are the same call shape as sort, and both are easy to forget."),
            dfn("nth_element", "An algorithm that positions one element correctly and "
                               "partitions the rest around it, without ordering them."),
            exp("The leaderboard and the median\n\n"
                "partial_sort with third as the end orders exactly the first three. From "
                "the six values the smallest three are 1, 4 and 5, in order.\n\n"
                "nth_element on the middle position gives 5, the median, and the halves "
                "are partitioned but not sorted - which is all a median needs."),
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{9, 4, 7, 1, 8, 5};
    std::vector<int> top(values);
    std::partial_sort(top.begin(), top.begin() + 3, top.end());
    std::cout << top[0] << " " << top[1] << " " << top[2] << "\\n";

    std::vector<int> middle(values);
    std::nth_element(middle.begin(), middle.begin() + 3, middle.end());
    std::cout << "median " << middle[3] << "\\n";

    std::cout << (std::is_sorted(middle.begin(), middle.end()) ? "sorted" : "only partitioned")
              << "\\n";
    return 0;
}
''', '''1 4 5
median 7
only partitioned'''),
            exp("When it matters\n\n"
                "On six values none of this matters. On a million rows, partial_sort of "
                "the first ten is a small fraction of the work of a full sort, and "
                "nth_element is linear against n log n.\n\n"
                "The cost of these algorithms is also why they exist: the library gives "
                "you the cheaper operation when you ask for less."),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> scores{55, 91, 70, 88, 64};
    std::partial_sort(scores.begin(), scores.begin() + 2, scores.end(),
                      [](int a, int b) { return a > b; });
    std::cout << scores[0] << " " << scores[1] << "\\n";
    std::cout << scores.size() << " scores in total\\n";
    return 0;
}
''', '''91 88
5 scores in total'''),
            quiz("What does nth_element guarantee?",
                 ["The whole range is sorted", "Only the first n elements are sorted",
                  "The element at position n is correct and the range is partitioned "
                  "around it", "Nothing"],
                 2, "It partitions: everything before is not greater and everything after "
                    "is not smaller, but neither side is ordered."),
           ]),

    lesson("91004", 91, "Algorithms", "Searching Beyond find",
           "Find the first match of a condition, or the exact place to insert.",
           ["Use find_if with a predicate.",
            "Use upper_bound and lower_bound for a sorted range.",
            "Say what the returned iterator means when nothing matches."],
           [exp("Matching a condition\n\n"
                "find matches a value; find_if matches a condition you supply, so it can "
                "ask 'which one is negative' or 'which name is longer than five'. It "
                "returns the first match, or end() when none exists.\n\n"
                "Because it returns an iterator rather than a value, the caller learns both "
                "whether something matched and where it was.\n\n"
                "The end() answer is the one to handle explicitly. Dereferencing end() is "
                "undefined behaviour and is the classic bug in search code."),
            dfn("Predicate", "A callable returning bool that an algorithm uses to decide "
                             "about each element."),
            exp("The insertion point\n\n"
                "In a sorted range, lower_bound gives the first element not less than the "
                "value, and upper_bound gives the first element greater than it. The "
                "difference between them is how many elements equal the value.\n\n"
                "That pair is how you find the position to insert while keeping the range "
                "sorted, without inserting and re-sorting."),
            code('''#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

int main() {
    std::vector<std::string> names{"ada", "bo", "cy", "dee"};
    auto longer = std::find_if(names.begin(), names.end(),
                               [](const std::string& name) { return name.size() > 2; });
    std::cout << (longer != names.end() ? *longer : "none") << "\\n";

    std::vector<int> values{10, 20, 20, 20, 30};
    auto first = std::lower_bound(values.begin(), values.end(), 20);
    auto last = std::upper_bound(values.begin(), values.end(), 20);
    std::cout << (first - values.begin()) << " to " << (last - values.begin()) << "\\n";
    std::cout << (last - first) << " equal values\\n";
    return 0;
}
''', '''ada
1 to 4
3 equal values'''),
            exp("Insertion without sorting afterwards\n\n"
                "insert takes an iterator position, and lower_bound finds the right one. "
                "On a vector this is a linear move of the tail, which is still far cheaper "
                "than sorting again.\n\n"
                "On a set, insert does this for you and the whole question disappears - "
                "which is the hint that a set may be the better structure."),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> values{10, 20, 30};
    auto place = std::lower_bound(values.begin(), values.end(), 25);
    values.insert(place, 25);
    for (int value : values) {
        std::cout << value << " ";
    }
    std::cout << "\\n" << (std::is_sorted(values.begin(), values.end()) ? "still sorted"
                                                                       : "out of order") << "\\n";
    return 0;
}
''', '''10 20 25 30 
still sorted'''),
            quiz("What does find_if return when nothing matches?",
                 ["nullptr", "A default-constructed iterator", "The end iterator",
                  "The last element"],
                 1, "It returns end(), which must be compared against before anything is "
                    "dereferenced."),
           ]),

    lesson("91005", 91, "Algorithms", "Numeric Algorithms",
           "Accumulate, reduce and inner_product: the loops over numbers you keep writing.",
           ["Sum a range with accumulate and with reduce.",
            "Compute a dot product with inner_product.",
            "Explain why the starting value decides the result type."],
           [exp("The starting value decides everything\n\n"
                "accumulate takes an initial value and applies addition left to right. The "
                "initial value's type is the type of the result, so starting with 0 for a "
                "list of doubles silently truncates the total.\n\n"
                "reduce does the same job in unspecified order, which lets it be faster "
                "and means the operation must be associative. For plain addition the answer "
                "is the same.\n\n"
                "inner_product combines two ranges: it multiplies element by element and "
                "accumulates the results."),
            dfn("Accumulate", "A left-to-right fold over a range, starting from a value you "
                              "provide. The result takes the starting value's type."),
            exp("Two ways to add\n\n"
                "Both sums agree because addition is associative. The third line shows the "
                "truncation trap: an int starting value turns three halves into 1.\n\n"
                "inner_product with two vectors gives 1*4 + 2*5 + 3*6, the dot product."),
            code('''#include <iostream>
#include <numeric>
#include <vector>

int main() {
    std::vector<int> values{1, 2, 3};
    std::cout << std::accumulate(values.begin(), values.end(), 0) << "\\n";
    std::cout << std::reduce(values.begin(), values.end(), 0) << "\\n";
    std::cout << std::inner_product(values.begin(), values.end(), values.begin(), 0)
              << "\\n";

    std::vector<double> halves{0.5, 0.5, 0.5};
    std::cout << std::accumulate(halves.begin(), halves.end(), 0) << " truncated\\n";
    std::cout << std::accumulate(halves.begin(), halves.end(), 0.0) << " kept\\n";
    return 0;
}
''', '''6
6
14
0 truncated
1.5 kept'''),
            exp("Where the fold earns its place\n\n"
                "A hand-written sum loop has four places to get wrong: the start, the end, "
                "the step and the accumulator. accumulate has none of them, and it reads as "
                "its own name.\n\n"
                "You can also pass an operation: multiplication gives a product, and a "
                "lambda gives anything else you need."),
            CHALLENGE,
            code('''#include <iostream>
#include <numeric>
#include <string>
#include <vector>

int main() {
    std::vector<int> values{2, 3, 4};
    std::cout << std::accumulate(values.begin(), values.end(), 1,
                                 [](int a, int b) { return a * b; }) << "\\n";
    std::vector<std::string> words{"a", "b", "c"};
    std::cout << std::accumulate(words.begin(), words.end(), std::string(),
                                 [](const std::string& a, const std::string& b) {
                                     return a + b;
                                 }) << "\\n";
    return 0;
}
''', '''24
abc'''),
            quiz("Why does accumulate(doubleList, 0) return 0?",
                 ["It rounds down", "The result type is the starting value's type, so "
                  "each sum is truncated into an int", "The list is empty",
                  "accumulate cannot add doubles"],
                 1, "Start with 0.0 and the accumulator is a double for the whole fold."),
           ]),

    lesson("91006", 91, "Utilities", "variant, any and optional",
           "Three ways to hold 'one of several things', and when each is right.",
           ["Store one of a fixed set of types with std::variant.",
            "Use std::any for a type that is genuinely unknown.",
            "Explain why std::optional is not the same idea."],
           [exp("One of a known set\n\n"
                "std::variant<int, std::string> holds exactly one of those two, and the set "
                "is fixed at compile time. That makes it the type-safe replacement for a "
                "union, and it can also tell you which one it currently holds.\n\n"
                "std::any holds any type at all, decided at run time. Reading it back "
                "requires naming the type you expect, and a wrong guess throws.\n\n"
                "std::optional is a different question: it holds a T or nothing. It is not "
                "used to choose between types."),
            dfn("variant", "A type that holds exactly one value from a fixed list of types, "
                           "chosen at run time but checked by the compiler."),
            exp("Reading it back safely\n\n"
                "holds_alternative asks which one is in there. get<T> throws if you ask for "
                "the wrong one, and get_if returns a pointer, or null, without throwing.\n\n"
                "std::any works the same way with any_cast, except the set of possible "
                "types is unknown, so the check is entirely your responsibility."),
            code('''#include <any>
#include <iostream>
#include <string>
#include <variant>

int main() {
    std::variant<int, std::string> value = 42;
    std::cout << (std::holds_alternative<int>(value) ? "holding an int" : "holding text")
              << "\\n";
    value = std::string("text");
    std::cout << std::get<std::string>(value) << "\\n";

    std::any anything = 7;
    std::cout << std::any_cast<int>(anything) << "\\n";
    std::cout << (anything.type() == typeid(int) ? "it is an int" : "something else") << "\\n";
    return 0;
}
''', '''holding an int
text
7
it is an int'''),
            exp("Choosing between them\n\n"
                "variant when you know the set of possibilities and want the compiler to "
                "check every use - a parser's value, a configuration setting, a protocol "
                "message.\n\n"
                "any only when the set is genuinely open, such as a general-purpose "
                "property bag. And optional when the only question is whether a value is "
                "there at all.\n\n"
                "If you find yourself using any, the usual answer is that an interface or a "
                "variant would be clearer."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <variant>

int main() {
    std::variant<int, double, std::string> setting = 2.5;
    std::cout << std::get<double>(setting) << "\\n";
    setting = std::string("on");
    std::cout << std::get<std::string>(setting) << "\\n";
    auto pointer = std::get_if<int>(&setting);
    std::cout << (pointer ? "an int" : "not an int") << "\\n";
    return 0;
}
''', '''2.5
on
not an int'''),
            quiz("What is std::optional for?",
                 ["Choosing between several types", "Holding a T or nothing",
                  "Holding any type at all", "Storing a pointer"],
                 1, "It answers presence, not which type: a value that may be absent."),
           ]),

    lesson("91007", 91, "Utilities", "string_view and span",
           "Look at text and arrays without copying them — and know when the view goes stale.",
           ["Pass a string_view to read text without copying.",
            "Explain what a view does not own.",
            "Say why span is the same idea for arrays."],
           [exp("A window, not a container\n\n"
                "std::string_view is a pointer and a length into text that belongs to "
                "someone else. Passing one avoids a copy, which is why it is the right "
                "parameter type for a function that only reads text.\n\n"
                "It does not own the characters and does not keep them alive. A view of a "
                "temporary, or of a string that is later modified, points at nothing "
                "valid - and unlike a vector's iterator, nothing warns you.\n\n"
                "substr and the comparison operators work as they do on a string, without "
                "allocating."),
            dfn("string_view", "A non-owning reference to a contiguous sequence of "
                               "characters, with a pointer and a length."),
            exp("Reading without copying\n\n"
                "The function takes a view, so passing a string literal and passing a "
                "std::string both work with no conversion and no allocation.\n\n"
                "The second line is the caution: a view over a temporary string is "
                "dangling the moment the temporary dies. Keeping the view in a variable "
                "does not extend that lifetime."),
            code('''#include <iostream>
#include <string>
#include <string_view>

std::size_t vowels(std::string_view text) {
    std::size_t count = 0;
    for (char letter : text) {
        if (letter == 'a' || letter == 'e' || letter == 'i' || letter == 'o' || letter == 'u') {
            ++count;
        }
    }
    return count;
}

int main() {
    std::string word = "shepherd";
    std::cout << vowels(word) << "\\n";
    std::cout << vowels("academy") << "\\n";
    std::string_view start = word;
    std::cout << start.substr(0, 4) << "\\n";
    std::cout << sizeof(std::string_view) << " bytes\\n";
    return 0;
}
''', '''2
3
shep
16 bytes'''),
            exp("span is the same idea for arrays\n\n"
                "std::span<T> is a view over a contiguous range of T: an array, a vector's "
                "data, or part of either. It carries the length, so a function taking a "
                "span cannot walk off the end by mistake.\n\n"
                "It arrived in C++20, so it cannot be run in this version of the app. The "
                "text example below has no Run button for that reason; once the app accepts "
                "a per-block standard it becomes an ordinary runnable example."),
            CHALLENGE,
            code('''#include <span>
#include <iostream>

void show(std::span<const int> values) {
    for (int value : values) {
        std::cout << value << " ";
    }
    std::cout << "\\n";
}

int main() {
    int data[3] = {1, 2, 3};
    show(data);
    show({data, 2});
    return 0;
}
''', '''1 2 3 
1 2 ''', language="text"),
            quiz("What does a string_view not do?",
                 ["Provide substr", "Compare text", "Own or keep alive the characters",
                  "Report its size"],
                 1, "It is a pointer and a length: the characters belong to somebody else, "
                    "and a stale view is a dangling view."),
           ]),

    lesson("91008", 91, "Utilities", "pair, tuple, optional, variant: Choosing",
           "Four ways to hold several or no values, and the one question that decides.",
           ["Choose between pair, tuple, optional and variant.",
            "Explain what a std::function adds.",
            "Say when a struct is clearer than a tuple."],
           [exp("The question that decides\n\n"
                "Are these values all present, and do they have different types? Then a "
                "struct or a pair: a struct when the members need names, a pair when there "
                "are two and the meaning is obvious.\n\n"
                "May the value be absent? Then optional. May it be one of several types? "
                "Then variant. Is it a callable you want to store? Then std::function.\n\n"
                "A tuple of four unnamed elements is technically correct and almost always "
                "the wrong choice: get<2> tells a reader nothing, while a struct's member "
                "name does."),
            dfn("std::function", "A value that can hold any callable with a given "
                                 "signature, at the cost of an indirection."),
            exp("All of them in one program\n\n"
                "A pair holds a name and a score, an optional holds a score that may be "
                "missing, a variant holds either a number or a message, and a function "
                "holds a callable that is chosen at run time.\n\n"
                "Each is one line, and each answers a different question - which is why "
                "the choice is about meaning rather than about which one compiles."),
            code('''#include <functional>
#include <iostream>
#include <optional>
#include <string>
#include <utility>
#include <variant>

int main() {
    std::pair<std::string, int> entry{"ada", 90};
    std::cout << entry.first << "=" << entry.second << "\\n";

    std::optional<int> maybe;
    std::cout << maybe.value_or(-1) << "\\n";

    std::variant<int, std::string> result = std::string("failed");
    std::cout << std::get<std::string>(result) << "\\n";

    std::function<int(int)> operation = [](int value) { return value * 3; };
    std::cout << operation(5) << "\\n";
    return 0;
}
''', '''ada=90
-1
failed
15'''),
            exp("The struct that should have been\n\n"
                "When the members have names that a reader needs, write the struct. It "
                "costs four lines and removes every get<0> / get<1> from the code.\n\n"
                "The library types are for the cases where the shape is obvious: a key and "
                "a value, a result or nothing, a value or an error."),
            CHALLENGE,
            code('''#include <iostream>
#include <optional>
#include <string>

struct Reading {
    std::string sensor;
    std::optional<int> value;
};

int main() {
    Reading good{"outside", 21};
    Reading broken{"outside", std::nullopt};
    std::cout << good.value.value_or(-999) << "\\n";
    std::cout << (broken.value ? "has a value" : "no reading") << "\\n";
    return 0;
}
''', '''21
no reading'''),
            quiz("When is a struct clearer than a tuple?",
                 ["Always", "When the members need names to be understood",
                  "When there are more than three members", "Never"],
                 1, "A named member says what it holds; get<2> does not."),
           ]),
]
