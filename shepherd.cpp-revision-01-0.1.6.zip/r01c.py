"""Gap fill part 3 of 3 — Practice Gaps."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("92001", 92, "Testing", "The Testing Frameworks",
           "GoogleTest, Catch2 and doctest, and what a framework gives you that a counter cannot.",
           ["Name what a test framework provides.",
            "Compare a hand-written check with a framework assertion.",
            "Say when the hand-written harness is still enough."],
           [exp("What a framework adds\n\n"
                "A framework gives you four things a counter does not: an assertion that "
                "reports the file and line, automatic registration of tests so there is no "
                "list to maintain, a filter to run one test by name, and a report a build "
                "server can read.\n\n"
                "The big three for C++ are GoogleTest, Catch2 and doctest. Catch2 and "
                "doctest are header-only, which makes them the least friction to start "
                "with; GoogleTest is the most common in industry and comes with mocks.\n\n"
                "They cannot be installed by the app, so the runnable example below is the "
                "same idea hand-written - every one of these frameworks is a refinement of "
                "this shape."),
            dfn("Test framework", "A library that registers tests, provides assertions with "
                                  "useful failure messages, and reports results."),
            exp("The same test, two ways\n\n"
                "A framework line reads CHECK_EQUAL(add(2, 2), 4), and on failure it prints "
                "both values, the expression and the location. The hand-written version "
                "prints both values and a line number.\n\n"
                "The difference is the discovery - the framework finds the tests itself - "
                "and a report a machine can read."),
            code('''#include <iostream>
#include <string>

int failures = 0;

#define CHECK_EQUAL(actual, expected)                                       \\
    do {                                                                    \\
        auto checked_actual = (actual);                                     \\
        auto checked_expected = (expected);                                 \\
        if (checked_actual != checked_expected) {                           \\
            ++failures;                                                     \\
            std::cout << "line " << __LINE__ << ": FAIL " << #actual        \\
                      << " got " << checked_actual << " expected "          \\
                      << checked_expected << "\\n";                          \\
        }                                                                   \\
    } while (false)

int add(int a, int b) { return a + b; }

int main() {
    CHECK_EQUAL(add(2, 2), 4);
    CHECK_EQUAL(add(0, 0), 0);
    CHECK_EQUAL(add(2, 2), 5);
    std::cout << failures << " failure(s)\\n";
    return 0;
}
''', '''line 23: FAIL add(2, 2) got 4 expected 5
1 failure(s)'''),
            exp("When the hand-written one is enough\n\n"
                "For a single lesson or a fifty-line tool, the counter from Level 13 costs "
                "nothing and has no dependency. A framework earns its place when there are "
                "dozens of tests, several files, or a build server reading the output.\n\n"
                "The idea is identical either way: give it a value, compare, report where "
                "it disagreed."),
            CHALLENGE,
            code('''#include <iostream>

#define CHECK(condition)                                                   \\
    do {                                                                   \\
        if (!(condition)) {                                                \\
            std::cout << "FAIL " << #condition << " at " << __LINE__ << "\\n"; \\
            return 1;                                                      \\
        }                                                                  \\
    } while (false)

int main() {
    CHECK(2 + 2 == 4);
    CHECK(3 * 3 == 9);
    std::cout << "all checks passed\\n";
    return 0;
}
''', '''all checks passed'''),
            quiz("What does a framework provide that a hand-written check does not?",
                 ["Faster code", "Test discovery, location in the message, and machine-"
                  "readable reports", "A compiler", "Memory management"],
                 1, "Registration, richer failure messages and reporting are the practical "
                    "additions."),
           ]),

    lesson("92002", 92, "Testing", "Fixtures and Parameterised Tests",
           "Set up once, run many times with different values.",
           ["Write a fixture that prepares a known state.",
            "Run one check against a table of inputs.",
            "Explain what a parameterised test removes."],
           [exp("The same setup, many tests\n\n"
                "Several tests of one function need the same starting state: a filled "
                "container, a temporary directory, a configured object. Without a fixture "
                "that setup is copied into each test and drifts.\n\n"
                "A fixture is a function or a struct that prepares that state and hands it "
                "over, so each test starts from the same place.\n\n"
                "A parameterised test goes further: one body, a table of inputs and "
                "expected outputs. The failure message names which row disagreed."),
            dfn("Fixture", "A shared, repeatable setup that every test starts from, so the "
                           "tests differ only in what they check."),
            exp("One body, four rows\n\n"
                "The table holds four cases, and each is checked by the same code. Adding a "
                "fifth case is one line.\n\n"
                "Without it, four near-identical tests would differ only in two constants - "
                "which is where a copy-paste mistake hides."),
            code('''#include <iostream>
#include <string>
#include <vector>

struct Case {
    std::string name;
    int input;
    int expected;
};

int failures = 0;

void run(int input, int expected, const std::string& name) {
    int actual = input * input;
    if (actual != expected) {
        ++failures;
        std::cout << "FAIL " << name << ": " << input << " squared gave " << actual << "\\n";
    }
}

int main() {
    std::vector<Case> cases{{"zero", 0, 0}, {"one", 1, 1}, {"negative", -3, 9},
                            {"large", 10, 99}};
    for (const Case& item : cases) {
        run(item.input, item.expected, item.name);
    }
    std::cout << failures << " failure(s) out of " << cases.size() << " cases\\n";
    return 0;
}
''', '''FAIL large: 10 squared gave 100
1 failure(s) out of 4 cases'''),
            exp("Fixtures that own a resource\n\n"
                "A fixture is most valuable when the setup is expensive or must be undone: "
                "a temporary directory created and removed, a database transaction rolled "
                "back, a file written and deleted.\n\n"
                "In a framework that is a struct's constructor and destructor. Hand-written, "
                "it is the same idea with an explicit setup and teardown around the tests."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

struct Fixture {
    std::vector<int> values{1, 2, 3};
    int setup_calls = 1;
};

int main() {
    Fixture fixture;
    std::cout << fixture.values.size() << " prepared values\\n";
    std::cout << (fixture.values.front() == 1 ? "PASS front is 1" : "FAIL") << "\\n";
    std::cout << (fixture.setup_calls == 1 ? "PASS setup ran once" : "FAIL") << "\\n";
    return 0;
}
''', '''3 prepared values
PASS front is 1
PASS setup ran once'''),
            quiz("What does a parameterised test remove?",
                 ["The need for assertions", "Copies of one test body that differ only in "
                  "constants", "The compiler", "The fixture"],
                 1, "One body plus a table of cases replaces near-identical tests and "
                    "reports which row failed."),
           ]),

    lesson("92003", 92, "Testing", "Property-Based Testing by Hand",
           "Instead of one example, state the rule and check it on many inputs.",
           ["State a property that must always hold.",
            "Check a property over many generated values.",
            "Explain what a counterexample gives you."],
           [exp("A rule instead of an example\n\n"
                "An example test says reverse({1,2,3}) is {3,2,1}. A property test says "
                "reversing twice returns the original - and then checks it on a thousand "
                "arrays the machine invents.\n\n"
                "The property is a statement that must always be true, and the generator "
                "supplies the cases a person would not think to write: empty, one element, "
                "duplicates, negatives.\n\n"
                "When it fails, it hands you a specific input that broke the rule. That "
                "counterexample is the whole value of the technique."),
            dfn("Property", "A statement that must hold for every valid input, checked "
                            "against many generated inputs rather than a fixed example."),
            exp("Two properties for sort\n\n"
                "The first property: after sorting, the number of elements is unchanged. "
                "The second: the result is in order. Both are checked against forty "
                "shuffled arrays built by the program.\n\n"
                "Neither property says what the sorted values are - they say what must be "
                "true of any correct sort, which is exactly what a test should say."),
            code('''#include <algorithm>
#include <iostream>
#include <random>
#include <vector>

int main() {
    std::mt19937 engine(1234);
    std::uniform_int_distribution<int> sizes(0, 20);
    std::uniform_int_distribution<int> values(-100, 100);
    int checked = 0;
    int broken = 0;
    for (int round = 0; round < 40; ++round) {
        std::vector<int> data(static_cast<std::size_t>(sizes(engine)));
        for (int& value : data) {
            value = values(engine);
        }
        auto original = data;
        std::sort(data.begin(), data.end());
        ++checked;
        if (data.size() != original.size() || !std::is_sorted(data.begin(), data.end())) {
            ++broken;
        }
    }
    std::cout << checked << " cases checked\\n";
    std::cout << broken << " broke a property\\n";
    return 0;
}
''', '''40 cases checked
0 broke a property'''),
            exp("Why this finds what examples miss\n\n"
                "A person writing examples writes three, four and five. A generator writes "
                "empty, one element, all duplicates, and negative values that expose a "
                "comparison using the wrong operator.\n\n"
                "The seed is fixed here so the run is reproducible, which matters: a "
                "property test that fails once in a thousand runs is a bug report you "
                "cannot act on unless you can replay it."),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <random>
#include <string>

int main() {
    std::mt19937 engine(7);
    std::uniform_int_distribution<int> sizes(0, 10);
    std::uniform_int_distribution<int> letters(0, 25);
    int broken = 0;
    for (int round = 0; round < 30; ++round) {
        std::string text;
        int length = sizes(engine);
        for (int i = 0; i < length; ++i) {
            text += static_cast<char>('a' + letters(engine));
        }
        std::string copy = text;
        std::reverse(copy.begin(), copy.end());
        std::reverse(copy.begin(), copy.end());
        if (copy != text) {
            ++broken;
        }
    }
    std::cout << (broken == 0 ? "reversing twice is identity" : "property broken") << "\\n";
    return 0;
}
''', '''reversing twice is identity'''),
            quiz("What does a failing property test give you?",
                 ["A stack trace", "A specific input that broke the rule",
                  "A list of all bugs", "A faster build"],
                 1, "The counterexample is the artefact: an input you can replay and debug."),
           ]),

    lesson("92004", 92, "Testing", "Fuzz Testing by Hand",
           "Feed it garbage on purpose, and make sure it never crashes.",
           ["Explain what fuzzing looks for.",
            "Generate malformed input and check the program survives.",
            "Distinguish a crash from a wrong answer."],
           [exp("Hostile input, on purpose\n\n"
                "A fuzzer generates malformed, truncated and random input to see whether "
                "the program crashes. It is not looking for wrong answers - it is looking "
                "for memory errors, hangs and unhandled exceptions.\n\n"
                "The property being tested is simple and absolute: for any bytes at all, "
                "the program must either reject them or process them, and never crash.\n\n"
                "Real fuzzers use coverage feedback to get deeper into the code. A "
                "hand-written version with random bytes already finds the missing checks."),
            dfn("Fuzz testing", "Feeding malformed or random input to a program to find "
                                "crashes, hangs and unhandled errors rather than wrong "
                                "results."),
            exp("Reject, do not crash\n\n"
                "The parser below accepts digits only and reports how many it saw. "
                "Random bytes are fed in and the count comes out.\n\n"
                "The important line is that invalid input produces a rejection, not an "
                "exception escaping main and not a corrupted value."),
            code('''#include <cctype>
#include <iostream>
#include <random>
#include <string>

int parse_count(const std::string& text) {
    int count = 0;
    for (char letter : text) {
        if (std::isdigit(static_cast<unsigned char>(letter))) {
            ++count;
        }
    }
    return count;
}

int main() {
    std::mt19937 engine(99);
    std::uniform_int_distribution<int> byte(0, 255);
    int survived = 0;
    for (int round = 0; round < 50; ++round) {
        std::string input;
        int length = round % 12;
        for (int i = 0; i < length; ++i) {
            input += static_cast<char>(byte(engine));
        }
        int digits = parse_count(input);
        if (digits >= 0 && digits <= static_cast<int>(input.size())) {
            ++survived;
        }
    }
    std::cout << survived << " hostile inputs handled\\n";
    return survived == 50 ? 0 : 1;
}
''', '''50 hostile inputs handled'''),
            exp("The bug fuzzing usually finds\n\n"
                "Most fuzzing findings in C++ are off-by-one reads on truncated input: the "
                "code expects three fields, receives one, and reads past the end.\n\n"
                "The fix is never a try/catch around main. It is a length check before the "
                "read, which is the same defensive parsing from Level 14."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>

int first_digit(const std::string& text) {
    for (char letter : text) {
        if (letter >= '0' && letter <= '9') {
            return letter - '0';
        }
    }
    return -1;
}

int main() {
    std::cout << first_digit("") << "\\n";
    std::cout << first_digit("abc") << "\\n";
    std::cout << first_digit("x7y") << "\\n";
    std::cout << (first_digit(std::string(200, 'z')) == -1 ? "long junk rejected" : "bad")
              << "\\n";
    return 0;
}
''', '''-1
-1
7
long junk rejected'''),
            quiz("What is fuzz testing looking for?",
                 ["Wrong answers", "Crashes, hangs and unhandled errors on malformed input",
                  "Slow code", "Missing comments"],
                 1, "Correctness is the other tests' job; fuzzing finds the input that "
                    "makes the program die."),
           ]),

    lesson("92005", 92, "Preprocessor", "#include, #define and #ifdef",
           "The one tool that runs before the compiler, and the few jobs it should still have.",
           ["Use #include and explain what it does literally.",
            "Write a function-like macro and the parentheses it needs.",
            "Use #ifdef for platform differences."],
           [exp("Text before compiling\n\n"
                "The preprocessor does one thing: it edits text before the compiler sees "
                "it. #include pastes a file in, #define substitutes a token, and #ifdef "
                "keeps or drops a block.\n\n"
                "It knows nothing about types, scope or syntax, which is why macros can "
                "produce errors that make no sense at the place they are reported.\n\n"
                "The modern advice is to use it for three jobs only: including headers, "
                "guarding headers, and conditional compilation for different platforms."),
            dfn("Preprocessor", "The first translation phase. It performs textual "
                                "substitution, file inclusion and conditional compilation "
                                "before the compiler parses anything."),
            exp("The macro that must be wrapped\n\n"
                "BAD_HALF(x) is written without parentheses around its parameter, so "
                "BAD_HALF(4 + 2) expands to 4 + 2 / 2. Division binds tighter than "
                "addition, so the result is 5 instead of 3.\n\n"
                "The body needs parentheses around each parameter and around the whole "
                "replacement, which is what GOOD_HALF does.\n\n"
                "This is the classic macro bug, and the reason a constexpr function is "
                "almost always the better answer: it has a type, and its arguments are "
                "evaluated by rules instead of by text substitution."),
            code('''#include <iostream>

#define BAD_HALF(x) x / 2
#define GOOD_HALF(x) ((x) / 2)

int main() {
    std::cout << BAD_HALF(4 + 2) << " bad: 4 + 2 / 2 is 5, not 3\\n";
    std::cout << GOOD_HALF(4 + 2) << " good: (4 + 2) / 2 is 3\\n";
    std::cout << GOOD_HALF(10) << " good: (10) / 2 is 5\\n";
    return 0;
}
''', '''5 bad: 4 + 2 / 2 is 5, not 3
3 good: (4 + 2) / 2 is 3
5 good: (10) / 2 is 5'''),
            exp("Conditional compilation\n\n"
                "#ifdef keeps a block only when a name is defined, which is how one source "
                "file handles Windows and Linux, or a debug build and a release build.\n\n"
                "The cost is that the compiler sees only one version of the code, so the "
                "other branch is not syntax-checked at all. That is why a platform-specific "
                "branch can lie dormant for months and break the day it is compiled."),
            CHALLENGE,
            code('''#include <iostream>

#define ACADEMY_VERSION 3
#define ACADEMY_BUILD 9

int main() {
#if defined(ACADEMY_VERSION) && ACADEMY_VERSION >= 3
    std::cout << "version 3 or later\\n";
#else
    std::cout << "older version\\n";
#endif
    std::cout << "build " << ACADEMY_BUILD << "\\n";
    return 0;
}
''', '''version 3 or later
build 9'''),
            quiz("Why must a function-like macro wrap its parameters in parentheses?",
                 ["To make it faster", "Because substitution is textual and precedence is "
                  "not respected", "Because macros cannot take arguments otherwise",
                  "To allow recursion"],
                 1, "Expansion happens before parsing, so without parentheses the "
                    "surrounding operators apply to the pieces."),
           ]),

    lesson("92006", 92, "Preprocessor", "Macro Pitfalls and Variadic Macros",
           "Double evaluation, variadic macros and the one thing macros can do that nothing else can.",
           ["Explain double evaluation in a macro.",
            "Write a variadic macro that forwards its arguments.",
            "Say which macro uses are still justified."],
           [exp("The argument evaluated twice\n\n"
                "A macro substitutes text, so an argument used twice runs twice. "
                "SQUARE(next()) becomes ((next()) * (next())): the first call returns 1, "
                "the second returns 2, and the answer is 2 with the counter at 2 - which "
                "looks like a broken counter.\n\n"
                "A function evaluates its arguments once, which is one of several reasons "
                "an inline function beats a macro whenever it can do the job.\n\n"
                "It is also why the standard library's assert is written so carefully: a "
                "macro that doubled its argument would break the program it was checking."),
            dfn("Double evaluation", "A macro argument appearing more than once in the "
                                     "expansion, so any side effect in it happens more "
                                     "than once."),
            exp("Variadic macros\n\n"
                "__VA_ARGS__ forwards however many arguments the caller gave, which is how "
                "logging macros accept a format and any number of values.\n\n"
                "This is the one job macros still do better than anything else: capture "
                "__LINE__ at the call site. A function would report its own location "
                "instead of the caller's, and that is why the macro hands the line to a "
                "real function to do the printing."),
            code('''#include <iostream>
#include <string>

int counter = 0;

int next() {
    ++counter;
    return counter;
}

void log_line(int line, const std::string& message) {
    std::cout << line << ": " << message << "\\n";
}

#define SQUARE(x) ((x) * (x))
#define LOG(...) log_line(__LINE__, __VA_ARGS__)

int main() {
    int squared = SQUARE(next());
    std::cout << squared << " from counter " << counter << "\\n";
    counter = 0;
    int once = next();
    std::cout << (once * once) << " from counter " << counter << "\\n";
    LOG("logged from a macro");
    return 0;
}
''', '''2 from counter 2
1 from counter 1
24: logged from a macro'''),
            exp("The three uses worth keeping\n\n"
                "Include guards, conditional compilation, and logging macros that capture "
                "the line number. Everything else - constants, small functions, type "
                "aliases - has a better tool in the language.\n\n"
                "That is not style preference: the compiler can check a constexpr function, "
                "give it a type, and debug it. It cannot do any of that for substituted "
                "text."),
            CHALLENGE,
            code('''#include <iostream>

#define CHECK(condition)                                                   \\
    do {                                                                   \\
        if (!(condition)) {                                                \\
            std::cout << "failed at line " << __LINE__ << "\\n";            \\
        }                                                                  \\
    } while (false)

int main() {
    CHECK(1 + 1 == 2);
    CHECK(1 + 1 == 3);
    std::cout << "done\\n";
    return 0;
}
''', '''failed at line 12
done'''),
            quiz("What does SQUARE(next()) do that a function would not?",
                 ["Nothing different", "Calls next() twice, because the argument appears "
                  "twice in the expansion", "Fails to compile", "Skips the call"],
                 1, "Textual substitution duplicates the expression, and its side effects "
                    "happen once per appearance."),
           ]),

    lesson("92007", 92, "Iterators", "Writing an Algorithm for Any Iterator",
           "Take a template parameter so your function works on arrays, vectors and lists.",
           ["Write a function that takes two iterators.",
            "Explain why the type is a template parameter.",
            "Predict which containers it works with."],
           [exp("Say what you need, not what you have\n\n"
                "A function taking std::vector<int>& works only for one container. One "
                "taking two iterators works for anything that supports the operations it "
                "uses - and says so in its signature.\n\n"
                "This is exactly how the standard algorithms are written, which is why "
                "std::count works on a vector, an array, and a list without a single "
                "overload.\n\n"
                "The template parameter is the iterator type, deduced at the call."),
            dfn("Iterator pair", "The (begin, end) parameters that let one function work "
                                 "on any container without knowing which one it is."),
            exp("One function, three containers\n\n"
                "total_of takes two iterators of the same type and adds whatever they "
                "point at. An array's pointers, a vector's iterators and a list's "
                "iterators all work unchanged.\n\n"
                "Nothing here knows what a vector is, which is the whole point."),
            code('''#include <iostream>
#include <list>
#include <vector>

template <typename Iterator>
int total_of(Iterator begin, Iterator end) {
    int total = 0;
    for (Iterator it = begin; it != end; ++it) {
        total += *it;
    }
    return total;
}

int main() {
    int numbers[3] = {1, 2, 3};
    std::vector<int> values{4, 5, 6};
    std::list<int> chain{7, 8, 9};
    std::cout << total_of(numbers, numbers + 3) << "\\n";
    std::cout << total_of(values.begin(), values.end()) << "\\n";
    std::cout << total_of(chain.begin(), chain.end()) << "\\n";
    return 0;
}
''', '''6
15
24'''),
            exp("The limits of the signature\n\n"
                "The function only uses *, ++ and !=, so it accepts input iterators and "
                "anything above them. If it used it[n] it would demand random access, and "
                "the list would no longer compile.\n\n"
                "That is the choice to make consciously: require the least the algorithm "
                "needs, and it works with the most containers."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

template <typename Iterator, typename Predicate>
Iterator first_match(Iterator begin, Iterator end, Predicate matches) {
    for (Iterator it = begin; it != end; ++it) {
        if (matches(*it)) {
            return it;
        }
    }
    return end;
}

int main() {
    std::vector<int> values{1, 4, 9, 16};
    auto found = first_match(values.begin(), values.end(), [](int v) { return v > 5; });
    std::cout << (found != values.end() ? *found : -1) << "\\n";
    std::cout << (found - values.begin()) << " steps in\\n";
    return 0;
}
''', '''9
2 steps in'''),
            quiz("Why does one iterator-based function work on many containers?",
                 ["Because containers share a base class", "Because the iterator type is a "
                  "template parameter deduced at the call", "Because it copies the "
                  "container", "Because iterators are all the same type"],
                 1, "The function is generated for each iterator type, as long as that type "
                    "supports the operations the body uses."),
           ]),

    lesson("92008", 92, "Revision", "Where These Gaps Sit in the Roadmap",
           "What this part closed, and what is still open.",
           ["Name the master topics this part closed.",
            "Say which gaps remain in levels 9-20.",
            "Decide whether the next part is gap fill or new levels."],
           [exp("What was closed\n\n"
                "This part taught type aliases (T039), enum underlying types (T038), "
                "iterator categories and invalidation (T041, T042), decltype (T049), value "
                "categories (T100), alignment (T096), object representation and byte order "
                "(T097), bit manipulation (T098), structured bindings (T052), the missing "
                "algorithms (T043-T047), inner_product and reduce (T046), variant/any with "
                "string_view (T114), and the testing topics (T129, T130).\n\n"
                "Each one is a named gap, closed with lessons, examples and quizzes rather "
                "than a mention in passing."),
            dfn("Done", "In this course: the topic has its own lesson, at least one runnable "
                        "example, and a quiz question."),
            exp("What is still open\n\n"
                "Graphs and graph algorithms (T077, T083), dynamic programming (T084), the "
                "remaining sorts (T081), heaps and balanced trees (T076), tries, allocators "
                "and std::pmr (T108, T109), ranges and views as runnable C++20 (T111-T113), "
                "memory ordering (T093), the concurrency additions (T090), modules (T106), "
                "and the whole of levels 21-55.\n\n"
                "Two of those - ranges and memory ordering - are waiting on the app's 0.3.9 "
                "so their examples can run as C++20 instead of being read as text."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <vector>

int main() {
    std::vector<std::string> closed{"type aliases", "decltype", "value categories",
                                    "alignment", "byte order", "bit masks",
                                    "iterator categories", "variant and any",
                                    "test frameworks", "property tests"};
    std::vector<std::string> open{"graphs", "dynamic programming", "allocators",
                                  "ranges", "memory ordering", "modules"};
    std::cout << closed.size() << " closed in this part\\n";
    std::cout << open.size() << " still open in levels 9-20\\n";
    return 0;
}
''', '''10 closed in this part
6 still open in levels 9-20'''),
            exp("The order to take them in\n\n"
                "A second gap-fill part for graphs, dynamic programming, the sorts, heaps, "
                "allocators and pmr - all of which are C++17 and need no app change.\n\n"
                "Then the app's 0.3.9 for ranges, memory ordering and the rest of modern "
                "C++, and after that the master's own levels 21-55 in order, eight levels "
                "at a time."),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <vector>

int main() {
    std::vector<int> gaps{9, 20};
    std::cout << "levels covered so far: " << gaps.front() << " to " << gaps.back() << "\\n";
    std::cout << (std::is_sorted(gaps.begin(), gaps.end()) ? "in order" : "out of order")
              << "\\n";
    return 0;
}
''', '''levels covered so far: 9 to 20
in order'''),
            quiz("When is a master topic finished in this course?",
                 ["When it is mentioned in a lesson", "When it has its own lesson with a "
                  "runnable example and a quiz", "When the roadmap lists it",
                  "When the app installs"],
                 1, "Mentioned-in-passing is what produced the gaps in the first place; a "
                    "lesson, an example and a quiz is the bar."),
           ]),
]
