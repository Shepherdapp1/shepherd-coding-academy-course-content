"""Extra lessons that close the last subtopics of T043-T047, T098, T114 and T130."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

CORE = [
    lesson("90009", 90, "Representation", "Bit Fields",
           "Several small flags in one integer - and why the layout is not portable.",
           ["Declare a struct with bit fields.",
            "Read and write each flag without touching its neighbours.",
            "Say why the byte layout is not portable."],
           [exp("Bits named one by one\n\n"
                "A bit field declares how many bits a member occupies. Three fields of "
                "one, three and four bits total eight bits, so the compiler packs them into "
                "one byte-sized unit instead of three separate integers.\n\n"
                "This is how hardware registers, protocol headers and file formats are "
                "described: each bit has a job, and a flag's name is easier to read than a "
                "mask written by hand.\n\n"
                "The trade is space for control: you cannot take the address of a bit "
                "field, and where each field sits inside the integer is decided by the "
                "compiler, not by the language."),
            dfn("Bit field", "A struct member that occupies a stated number of bits rather "
                             "than a whole object, packed with its neighbours into the same "
                             "storage unit."),
            exp("What is guaranteed and what is not\n\n"
                "Setting one field leaves the others alone - that is guaranteed. Assigning "
                "five to a two-bit field silently keeps the low bits - that is a narrowing "
                "you must check yourself.\n\n"
                "The compiler helps here: assigning a constant 40 into the five-bit "
                "field warns that the value changes, which is why the example reads the "
                "number from a variable - the truncation is the same, but it happens "
                "quietly the way it does in real code.\n\n"
                "What is not guaranteed is order and padding. Whether ready sits in the "
                "lowest bit, and how many bytes the struct takes, varies between compilers "
                "and even between options on the same compiler. Reading such a struct "
                "straight off a network packet is therefore a bug waiting for a different "
                "build.\n\n"
                "The portable route is the mask-and-shift code from the earlier lesson: "
                "state the bit position yourself instead of asking the compiler to choose."),
            code('''#include <iostream>

struct Permissions {
    unsigned read : 1;
    unsigned write : 1;
    unsigned execute : 1;
    unsigned level : 5;
};

int main() {
    Permissions permissions{};
    permissions.read = 1;
    permissions.level = 3;
    std::cout << "read " << permissions.read << " write " << permissions.write
              << " execute " << permissions.execute << " level " << permissions.level
              << "\\n";

    permissions.read = 0;
    permissions.write = 1;
    std::cout << "after the change read " << permissions.read << " write "
              << permissions.write << " level " << permissions.level << "\\n";

    volatile int requested = 40;
    permissions.level = requested;
    std::cout << "40 in five bits became " << permissions.level << "\\n";
    return 0;
}
''', '''read 1 write 0 execute 0 level 3
after the change read 0 write 1 level 3
40 in five bits became 8'''),
            exp("Where they belong\n\n"
                "Bit fields are the right tool for a register map inside one program, and "
                "the wrong tool for data that leaves it. For anything written to a file or "
                "sent over a socket, write each byte explicitly - the mask and shift code, "
                "or a serialisation function - and the format stops depending on who "
                "compiled it."),
            CHALLENGE,
            code('''#include <iostream>

struct Status {
    unsigned ready : 1;
    unsigned busy : 1;
    unsigned code : 6;
};

int main() {
    Status status{};
    status.code = 21;
    status.busy = 1;
    std::cout << "ready " << status.ready << " busy " << status.busy
              << " code " << status.code << "\\n";
    int total = status.ready + status.busy + status.code;
    std::cout << "sum of the fields is " << total << "\\n";
    return 0;
}
''', '''ready 0 busy 1 code 21
sum of the fields is 22'''),
            quiz("What does the language guarantee about bit fields?",
                 ["The byte order and padding", "That each field holds its bits and setting "
                  "one leaves the others alone", "That the struct is one byte",
                  "That they can be addressed"],
                 1, "Bit values and independence are guaranteed; placement, padding and "
                    "total size are implementation-defined."),
           ]),
]

LIBRARY = [
    lesson("91009", 91, "Algorithms", "The Algorithms People Skip",
           "binary_search, stable_sort, remove/erase, iota and the min/max family.",
           ["Search a sorted range with binary_search.",
            "Choose stable_sort when equal elements must keep their order.",
            "Remove elements with the erase-remove idiom."],
           [exp("Five slots worth filling\n\n"
                "Most code uses find, sort and for_each and stops there. The rest of the "
                "header covers the work that follows: deciding whether a value is present "
                "in a sorted range, sorting without disturbing equal elements, deleting "
                "elements safely, generating a sequence, and reducing a range to its "
                "smallest and largest element.\n\n"
                "None of these needs a loop you write yourself, and each has a name a "
                "reader already knows."),
            dfn("Erase-remove idiom", "std::remove moves the elements to keep to the front "
                                      "and returns the new logical end; erase then "
                                      "shortens the container. remove alone never changes "
                                      "the container's size."),
            exp("Sorted search, stable sort, and a generated range\n\n"
                "binary_search answers only yes or no, so use it when presence is the "
                "question and lower_bound when the position matters.\n\n"
                "stable_sort keeps equal elements in their original order, which is the "
                "reason it exists: the plain sort is free to reorder them.\n\n"
                "iota fills a range with 1, 2, 3 ... which is the shortest way to get an "
                "index sequence for a test or a report."),
            code('''#include <algorithm>
#include <iostream>
#include <numeric>
#include <string>
#include <vector>

int main() {
    std::vector<int> sorted{10, 20, 30, 40, 50};
    std::cout << std::boolalpha;
    std::cout << "30 present: " << std::binary_search(sorted.begin(), sorted.end(), 30)
              << "\\n";
    std::cout << "35 present: " << std::binary_search(sorted.begin(), sorted.end(), 35)
              << "\\n";

    std::vector<int> sequence(5);
    std::iota(sequence.begin(), sequence.end(), 1);
    for (int value : sequence) {
        std::cout << value << " ";
    }
    std::cout << "\\n";
    std::cout << "smallest " << *std::min_element(sequence.begin(), sequence.end())
              << " largest " << *std::max_element(sequence.begin(), sequence.end()) << "\\n";
    std::cout << "all positive: "
              << std::all_of(sequence.begin(), sequence.end(),
                             [](int v) { return v > 0; })
              << " any over ten: "
              << std::any_of(sequence.begin(), sequence.end(),
                             [](int v) { return v > 10; })
              << " none negative: "
              << std::none_of(sequence.begin(), sequence.end(),
                              [](int v) { return v < 0; })
              << "\\n";
    return 0;
}
''', '''30 present: true
35 present: false
1 2 3 4 5 
smallest 1 largest 5
all positive: true any over ten: false none negative: true'''),
            exp("Stable order, and removing for real\n\n"
                "stable_sort sorts by one key while preserving the order produced by a "
                "previous sort - sort by name, then stable_sort by department, and each "
                "department lists its people alphabetically.\n\n"
                "remove_if does not delete anything: it shuffles the survivors forward and "
                "returns where the kept range ends. erasing from that point to end() is the "
                "step that changes the size, which is why every remove call is followed by "
                "erase in real code."),
            code('''#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

int main() {
    std::vector<int> numbers{5, 1, 4, 2, 3};
    std::sort(numbers.begin(), numbers.end());
    std::cout << "sorted: ";
    for (int value : numbers) {
        std::cout << value << " ";
    }
    std::cout << "\\n";

    auto kept_end = std::remove_if(numbers.begin(), numbers.end(),
                                   [](int v) { return v % 2 == 0; });
    std::cout << "after remove_if, size is " << numbers.size() << " and the kept range has "
              << (kept_end - numbers.begin()) << "\\n";
    numbers.erase(kept_end, numbers.end());
    std::cout << "after erase, size is " << numbers.size() << " holding: ";
    for (int value : numbers) {
        std::cout << value << " ";
    }
    std::cout << "\\n";

    std::vector<std::string> words{"pear", "fig"};
    std::vector<std::string> moved(2);
    std::move(words.begin(), words.end(), moved.begin());
    std::cout << "moved holds " << moved[0] << " " << moved[1]
              << " and the first word is now empty: "
              << (words[0].empty() ? "yes" : "no") << "\\n";
    return 0;
}
''', '''sorted: 1 2 3 4 5 
after remove_if, size is 5 and the kept range has 3
after erase, size is 3 holding: 1 3 5 
moved holds pear fig and the first word is now empty: yes'''),
            exp("Stability, run twice\n\n"
                "Sort the people by name first, then stable_sort by department. Each "
                "department comes out in name order because stable_sort never swaps equal "
                "elements past each other.\n\n"
                "Plain sort would be free to scramble them, and the output would look "
                "random even though the sort was correct."),
            code('''#include <algorithm>
#include <iostream>
#include <string>
#include <vector>

struct Person {
    std::string name;
    std::string department;
};

int main() {
    std::vector<Person> people{{"ada", "research"}, {"bo", "support"},
                               {"cy", "research"}, {"dee", "support"},
                               {"eve", "research"}};
    std::sort(people.begin(), people.end(),
              [](const Person& a, const Person& b) { return a.name < b.name; });
    std::stable_sort(people.begin(), people.end(),
                     [](const Person& a, const Person& b) {
                         return a.department < b.department;
                     });
    for (const Person& person : people) {
        std::cout << person.department << ": " << person.name << "\\n";
    }
    return 0;
}
''', '''research: ada
research: cy
research: eve
support: bo
support: dee'''),
            exp("Two things called move\n\n"
                "std::move in <algorithm> copies elements from one range to another, moving "
                "each one; std::move in <utility> is only a cast that makes an object "
                "eligible to be moved from. The first is an algorithm with iterators, the "
                "second is a request.\n\n"
                "Reading that distinction once saves a long afternoon: the cast does not "
                "move anything by itself, and the algorithm needs three iterators."),
            CHALLENGE,
            code('''#include <algorithm>
#include <iostream>
#include <numeric>
#include <vector>

int main() {
    std::vector<int> values{4, 8, 15, 16, 23, 42};
    std::cout << (std::binary_search(values.begin(), values.end(), 15) ? "found" : "absent")
              << "\\n";
    std::vector<int> index(4);
    std::iota(index.begin(), index.end(), 0);
    std::cout << "index count " << index.size() << " starting at " << index.front() << "\\n";
    std::cout << (std::all_of(values.begin(), values.end(), [](int v) { return v > 0; })
                      ? "all above zero" : "something is not")
              << "\\n";
    return 0;
}
''', '''found
index count 4 starting at 0
all above zero'''),
            quiz("After std::remove_if, why must you call erase?",
                 ["To free memory immediately", "Because remove_if only moves the kept "
                  "elements forward and returns the new end; the size is unchanged",
                  "To sort the survivors", "To avoid undefined behaviour"],
                 1, "The size only changes when the tail is erased; remove alone leaves the "
                    "moved-from elements in place."),
           ]),

    lesson("91010", 91, "Utilities", "function, reference_wrapper and expected",
           "Store any callable, hold a reference where a reference cannot go, and see what is coming.",
           ["Store a lambda, a function or a functor in one std::function.",
            "Put a reference in a container with reference_wrapper.",
            "Say what std::expected changes about error reporting."],
           [exp("One type for every callable\n\n"
                "A lambda, a function pointer and an object with operator() have three "
                "different types. std::function<Return(Args...)> can hold any of them, which "
                "is how callbacks, command tables and event handlers are stored in one "
                "container.\n\n"
                "The cost is indirect: the call goes through a wrapper, and a large captured "
                "lambda may cause an allocation. For a hot loop, a template parameter is "
                "free; std::function is for the places where the callable must share a type."),
            dfn("reference_wrapper", "A copyable object that behaves like a reference, "
                                     "which lets references live in containers and be "
                                     "passed by value."),
            exp("A reference that a container can hold\n\n"
                "std::vector<int&> is ill-formed: a reference is not an object and cannot be "
                "stored. std::vector<std::reference_wrapper<int>> is fine, and std::ref "
                "makes one without spelling the type.\n\n"
                "Writing through the wrapper writes through to the original, which is what "
                "makes it a view of something that lives elsewhere rather than a copy."),
            code('''#include <functional>
#include <iostream>
#include <string>
#include <vector>

int add_one(int value) { return value + 1; }

struct Doubler {
    int operator()(int value) const { return value * 2; }
};

int main() {
    std::vector<std::function<int(int)>> steps;
    steps.push_back(add_one);
    steps.push_back(Doubler{});
    steps.push_back([](int value) { return value * value; });
    int result = 3;
    for (const auto& step : steps) {
        result = step(result);
    }
    std::cout << "after three steps: " << result << "\\n";

    int first = 1;
    int second = 2;
    std::vector<std::reference_wrapper<int>> views{std::ref(first), std::ref(second)};
    for (auto& view : views) {
        view.get() *= 10;
    }
    std::cout << "originals are now " << first << " and " << second << "\\n";
    return 0;
}
''', '''after three steps: 64
originals are now 10 and 20'''),
            exp("Where this is going: std::expected\n\n"
                "C++23 adds std::expected<T, E>, which holds either a value or an error and "
                "forces the caller to look at both - the return-based alternative to "
                "exceptions for failures you expect.\n\n"
                "It is not available in this course's C++17 toolchain, so it appears in this "
                "lesson as text only. The pattern it replaces is the bool-and-out-parameter "
                "pair from Level 14, and the pattern it is closest to is std::optional with "
                "a reason attached."),
            CHALLENGE,
            code('''#include <functional>
#include <iostream>
#include <string>

int apply_twice(const std::function<int(int)>& step, int value) {
    return step(step(value));
}

int main() {
    std::cout << apply_twice([](int v) { return v + 5; }, 3) << "\\n";
    std::cout << apply_twice([](int v) { return v * 3; }, 4) << "\\n";
    int target = 7;
    auto reference = std::ref(target);
    reference.get() += 1;
    std::cout << "target is now " << target << "\\n";
    return 0;
}
''', '''13
36
target is now 8'''),
            quiz("Why can std::function hold a lambda and a function pointer together?",
                 ["Because lambdas are converted into function pointers", "Because it is a "
                  "type-erasing wrapper with one call signature", "Because it uses templates "
                  "at the call site", "Because both are classes"],
                 1, "It stores the callable behind one fixed signature, so everything with "
                    "that signature shares a type."),
           ]),
]

PRACTICE = [
    lesson("92009", 92, "Testing", "Test Doubles",
           "Feed the code a fake collaborator so the test controls the world.",
           ["Replace a real dependency with a fake.",
            "Check that a collaborator was called, not only what was returned.",
            "Say when a mock is worth the extra machinery."],
           [exp("The dependency you cannot control\n\n"
                "A function that reads the clock, writes a file or charges a card cannot be "
                "tested on demand: the clock keeps moving, the file is not there, the card "
                "is real.\n\n"
                "The fix is not a testing trick, it is design: take the dependency as a "
                "parameter. The test then passes a fake that behaves the way the test "
                "needs, and the production code passes the real one.\n\n"
                "A stub returns canned answers. A mock also records what it was asked, so "
                "the test can assert that an operation happened."),
            dfn("Test double", "A stand-in for a real dependency - stub, fake or mock - used "
                               "so a test can control and observe what the code under test "
                               "interacts with."),
            exp("A fake that records\n\n"
                "Notifier is an interface with one virtual function. The test supplies "
                "RecordingNotifier, which counts the calls and remembers the message.\n\n"
                "The assertion is about behaviour, not output: the alert function was asked "
                "to notify exactly once, with the right text. That is what a mock framework "
                "automates, and what a hand-written double already does."),
            code('''#include <iostream>
#include <string>
#include <vector>

class Notifier {
public:
    virtual ~Notifier() = default;
    virtual void send(const std::string& message) = 0;
};

class RecordingNotifier : public Notifier {
public:
    void send(const std::string& message) override {
        messages.push_back(message);
    }
    std::vector<std::string> messages;
};

void alert(Notifier& notifier, int temperature) {
    if (temperature > 80) {
        notifier.send("overheating");
    }
}

int main() {
    RecordingNotifier recorder;
    alert(recorder, 90);
    alert(recorder, 20);
    std::cout << "messages sent: " << recorder.messages.size() << "\\n";
    std::cout << "first message: "
              << (recorder.messages.empty() ? "none" : recorder.messages.front()) << "\\n";
    return 0;
}
''', '''messages sent: 1
first message: overheating'''),
            exp("When a mock is worth it\n\n"
                "A hand-written double is ten lines and needs no library, which is why this "
                "lesson uses one. A mocking framework such as GoogleMock earns its place "
                "when there are dozens of expectations, strict ordering requirements, or "
                "many interfaces to fake.\n\n"
                "What never changes is the design rule underneath: the code under test must "
                "accept its collaborators from outside. A test that needs a framework to "
                "reach inside a hard-wired dependency is a design smell first."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>

class Clock {
public:
    virtual ~Clock() = default;
    virtual int hour() const = 0;
};

class FixedClock : public Clock {
public:
    explicit FixedClock(int fixed) : value(fixed) {}
    int hour() const override { return value; }
private:
    int value;
};

std::string greeting(const Clock& clock) {
    return clock.hour() < 12 ? "good morning" : "good afternoon";
}

int main() {
    FixedClock morning(9);
    FixedClock evening(19);
    std::cout << greeting(morning) << "\\n";
    std::cout << greeting(evening) << "\\n";
    return 0;
}
''', '''good morning
good afternoon'''),
            quiz("What makes a class testable with a double?",
                 ["A virtual destructor alone", "Taking its collaborators as parameters "
                  "instead of creating them inside", "Being a template",
                  "Having no private members"],
                 1, "Injection is the design change; the double is only what the test passes "
                    "in once that is possible."),
           ]),
]
