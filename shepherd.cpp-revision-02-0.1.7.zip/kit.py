"""Shared helpers for the C++ revision batch, part 2."""
import json

CID = "shepherd.cpp-revision-02"
VERSION = "0.1.7"


def exp(text):
    return {"kind": "explanation", "text": text}


def dfn(term, text):
    return {"kind": "definition", "term": term, "text": text}


def code(source, expected, language="cpp"):
    return {"kind": "code", "language": language, "code": source,
            "expected_output": expected}


def quiz(question, options, correct, explanation):
    payload = {"question": question, "options": options,
               "correct_index": correct, "explanation": explanation}
    return {"kind": "explanation",
            "text": "SHEPHERD_QUIZ_V1:" + json.dumps(payload, ensure_ascii=False)}


CHALLENGE = exp("Guided coding challenge\n\nThe example is deliberately small. Write "
                "it yourself with your own values, change one thing, and predict the "
                "output before you run it.")


def lesson(suffix, level, topic, title, summary, objectives, body):
    return {
        "id": f"{CID}.lesson.{suffix}",
        "kind": "lesson",
        "title": title,
        "revision": 1,
        "summary": summary,
        "objectives": objectives,
        "difficulty": "intermediate",
        "estimated_minutes": 25,
        "extensions": {"org.shepherd.cpp-standard": "C++17"},
        "body": body,
        "_level": level,
        "_topic": topic,
    }
