"""Gap fill part 2, module 93 — linear structures and trees."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("93001", 93, "Linear Structures", "Dynamic Arrays and Linked Lists by Hand",
           "The two ways to hold a sequence, built once so the costs stop being abstract.",
           ["Grow an array by doubling and say what that costs.",
            "Walk a singly linked list and insert without shifting.",
            "Say which of the two is right for a given job."],
           [exp("Two layouts, two cost profiles\n\n"
                "A dynamic array keeps its elements side by side, so reading by index is one "
                "multiplication and a load. Growing it means allocating a bigger block and "
                "moving everything, which is why the capacity doubles rather than growing by "
                "one: doubling makes the average cost per append constant.\n\n"
                "A linked list keeps each element in its own node with a pointer to the "
                "next. Inserting is a pointer change, but reaching the thousandth element "
                "means following a thousand pointers, and every node costs a pointer of "
                "overhead.\n\n"
                "Both are shown here in their smallest honest form."),
            dfn("Amortised cost", "The average cost per operation over a long run. Doubling "
                                  "on growth makes push_back amortised constant even though "
                                  "individual appends occasionally copy everything."),
            exp("Doubling, and a list that only rewires\n\n"
                "The array prints its capacity each time it doubles, which is four times for "
                "thirty pushes rather than thirty times.\n\n"
                "The list prints the same values in order. There is no capacity and no "
                "copying - only a new node at the front."),
            code('''#include <iostream>
#include <memory>
#include <vector>

class DynamicArray {
public:
    void push_back(int value) {
        if (size_ == capacity_) {
            grow();
        }
        data_[size_++] = value;
    }
    int operator[](std::size_t index) const { return data_[index]; }
    std::size_t size() const { return size_; }
private:
    void grow() {
        std::size_t next = capacity_ == 0 ? 1 : capacity_ * 2;
        std::unique_ptr<int[]> fresh(new int[next]);
        for (std::size_t i = 0; i < size_; ++i) {
            fresh[i] = data_[i];
        }
        data_ = std::move(fresh);
        capacity_ = next;
        std::cout << "grew to capacity " << capacity_ << "\\n";
    }
    std::unique_ptr<int[]> data_;
    std::size_t size_ = 0;
    std::size_t capacity_ = 0;
};

struct Node {
    int value;
    Node* next;
};

int main() {
    DynamicArray array;
    for (int value = 1; value <= 10; ++value) {
        array.push_back(value);
    }
    std::cout << "array holds " << array.size() << " values, last is " << array[9] << "\\n";

    Node* head = nullptr;
    for (int value = 3; value >= 1; --value) {
        head = new Node{value, head};
    }
    std::cout << "list:";
    for (Node* node = head; node != nullptr; node = node->next) {
        std::cout << " " << node->value;
    }
    std::cout << "\\n";
    while (head != nullptr) {
        Node* next = head->next;
        delete head;
        head = next;
    }
    return 0;
}
''', '''grew to capacity 1
grew to capacity 2
grew to capacity 4
grew to capacity 8
grew to capacity 16
array holds 10 values, last is 10
list: 1 2 3'''),
            exp("The habit that matters\n\n"
                "In real code this is std::vector and std::list, and the rule is the same: "
                "reach for the vector first. It is smaller, it is friendlier to the cache, "
                "and it is what the standard library itself uses by default.\n\n"
                "A list earns its place only when you keep a pointer to the middle and "
                "insert there constantly - and even then, measure before believing it."),
            CHALLENGE,
            code('''#include <iostream>

struct Node {
    int value;
    Node* next;
};

void print(const char* label, Node* head) {
    std::cout << label << ":";
    for (Node* node = head; node != nullptr; node = node->next) {
        std::cout << " " << node->value;
    }
    std::cout << "\\n";
}

int main() {
    Node first{1, nullptr};
    Node second{2, nullptr};
    first.next = &second;
    print("original", &first);

    Node front{0, &first};
    print("prepended", &front);

    first.next = nullptr;
    print("after truncation", &front);
    return 0;
}
''', '''original: 1 2
prepended: 0 1 2
after truncation: 0 1'''),
            quiz("Why does a dynamic array double its capacity instead of growing by one?",
                 ["To use less memory", "So the average cost of appending stays constant",
                  "Because pointers need powers of two", "To keep the list sorted"],
                 1, "Doubling makes reallocation rare enough that its cost amortises to a "
                    "constant per append."),
           ]),

    lesson("93002", 93, "Linear Structures", "Stacks, Queues and a Ring Buffer",
           "Last in first out, first in first out, and the fixed buffer that wraps around.",
           ["Use std::stack and std::queue.",
            "Write a ring buffer whose head and tail wrap.",
            "Say why a ring buffer has no shifting."],
           [exp("Three shapes of the same idea\n\n"
                "A stack pushes and pops at one end: the last thing in is the first thing "
                "out. Undo history, expression parsing and depth-first search are all "
                "stacks.\n\n"
                "A queue adds at one end and removes at the other: first in, first out. "
                "Breadth-first search, print jobs and message handling are queues.\n\n"
                "A ring buffer is a queue in a fixed array where the read and write "
                "positions wrap around to the start. Nothing is ever shifted, so pushing "
                "costs the same whether the buffer is empty or full."),
            dfn("Ring buffer", "A fixed-size queue stored in an array, with head and tail "
                               "indices that wrap modulo the capacity, so no element is "
                               "ever moved."),
            exp("Wrapping, with no shifting\n\n"
                "Capacity is four. The buffer fills, drains two, and fills again - and the "
                "indices wrap past the end while the values come out in the order they went "
                "in.\n\n"
                "The reset case is the trap: an empty buffer and a full one can look the "
                "same, so this one tracks the count separately."),
            code('''#include <iostream>
#include <queue>
#include <stack>
#include <vector>

class RingBuffer {
public:
    explicit RingBuffer(std::size_t capacity) : data_(capacity), tail_(0), count_(0) {}

    bool push(int value) {
        if (count_ == data_.size()) {
            return false;
        }
        data_[tail_] = value;
        tail_ = (tail_ + 1) % data_.size();
        ++count_;
        return true;
    }
    bool pop(int& out) {
        if (count_ == 0) {
            return false;
        }
        std::size_t head = (tail_ + data_.size() - count_) % data_.size();
        out = data_[head];
        --count_;
        return true;
    }
    std::size_t count() const { return count_; }
private:
    std::vector<int> data_;
    std::size_t tail_;
    std::size_t count_;
};

int main() {
    std::stack<int> stack;
    stack.push(1);
    stack.push(2);
    stack.push(3);
    std::cout << "stack top " << stack.top() << " then " << (stack.pop(), stack.top()) << "\\n";

    std::queue<int> queue;
    queue.push(1);
    queue.push(2);
    queue.push(3);
    std::cout << "queue front " << queue.front() << " then " << (queue.pop(), queue.front())
              << "\\n";

    RingBuffer ring(4);
    for (int value = 1; value <= 4; ++value) {
        ring.push(value);
    }
    std::cout << "ring full, count " << ring.count() << " push 5 accepted: "
              << (ring.push(5) ? "yes" : "no") << "\\n";
    for (int i = 0; i < 2; ++i) {
        int value = 0;
        ring.pop(value);
        std::cout << "popped " << value << "\\n";
    }
    ring.push(5);
    ring.push(6);
    int value = 0;
    while (ring.pop(value)) {
        std::cout << "left " << value << "\\n";
    }
    return 0;
}
''', '''stack top 3 then 2
queue front 1 then 2
ring full, count 4 push 5 accepted: no
popped 1
popped 2
left 3
left 4
left 5
left 6'''),
            exp("Where the ring buffer actually lives\n\n"
                "Audio buffers, network receive queues and log rotation all use it. The "
                "reason is the same every time: the producer and consumer run at different "
                "speeds, and the buffer must never allocate in the middle.\n\n"
                "Once the indices are the only state, making it safe for two threads needs "
                "only atomics on head, tail and count - which is why this shape appears in "
                "every lock-free queue you will read."),
            CHALLENGE,
            code('''#include <iostream>
#include <stack>
#include <string>

bool balanced(const std::string& text) {
    std::stack<char> open;
    for (char letter : text) {
        if (letter == '(' || letter == '[') {
            open.push(letter);
        } else if (letter == ')' || letter == ']') {
            if (open.empty()) {
                return false;
            }
            char expected = letter == ')' ? '(' : '[';
            if (open.top() != expected) {
                return false;
            }
            open.pop();
        }
    }
    return open.empty();
}

int main() {
    std::cout << std::boolalpha;
    std::cout << "((2 + 3) * 4): " << balanced("((2 + 3) * 4)") << "\\n";
    std::cout << "([2 + 3): " << balanced("([2 + 3)") << "\\n";
    std::cout << "2 + 3): " << balanced("2 + 3)") << "\\n";
    return 0;
}
''', '''((2 + 3) * 4): true
([2 + 3): false
2 + 3): false'''),
            quiz("What makes a ring buffer worth using instead of a std::queue?",
                 ["It sorts the elements", "A fixed array with wrapping indices, so it never "
                  "shifts or allocates while running", "It allows duplicate values",
                  "It is the only way to get first-in-first-out"],
                 1, "No shifting and no allocation in the middle of operation - which is "
                    "exactly what real-time producers need."),
           ]),

    lesson("93003", 93, "Trees", "Binary Search Trees",
           "Order on the left, larger on the right, and the traversal that proves it.",
           ["Insert and search in a binary search tree.",
            "Print the values in order with an in-order traversal.",
            "Say what makes a binary search tree slow."],
           [exp("The rule that makes searching cheap\n\n"
                "Every node holds a value; everything in its left subtree is smaller and "
                "everything in its right subtree is larger. Searching compares once per "
                "level, so the work is the height of the tree, not the number of values.\n\n"
                "In-order traversal - left, node, right - visits the values in sorted order, "
                "which is the cheapest way to prove the tree is built correctly.\n\n"
                "The catch is the shape. Insert already-sorted values and every node goes to "
                "the right, which makes a linked list with extra steps and searching linear."),
            dfn("Binary search tree", "A binary tree where every value in the left subtree is "
                                      "smaller than the node and every value in the right "
                                      "subtree is larger, so searching follows one path."),
            exp("Building one, and walking it in order\n\n"
                "Seven values are inserted out of order, and the in-order traversal returns "
                "them sorted. The height is printed too: three levels for seven values is "
                "the balanced case.\n\n"
                "Then the same values are inserted in order and the height becomes seven, "
                "which is the worst case and the reason AVL and red-black trees exist."),
            code('''#include <iostream>

struct Node {
    int value;
    Node* left = nullptr;
    Node* right = nullptr;
};

Node* insert(Node* root, int value) {
    if (root == nullptr) {
        return new Node{value};
    }
    if (value < root->value) {
        root->left = insert(root->left, value);
    } else if (value > root->value) {
        root->right = insert(root->right, value);
    }
    return root;
}

bool contains(const Node* root, int value) {
    const Node* node = root;
    while (node != nullptr) {
        if (value == node->value) {
            return true;
        }
        node = value < node->value ? node->left : node->right;
    }
    return false;
}

void in_order(const Node* node) {
    if (node == nullptr) {
        return;
    }
    in_order(node->left);
    std::cout << node->value << " ";
    in_order(node->right);
}

int height(const Node* node) {
    if (node == nullptr) {
        return 0;
    }
    int left = height(node->left);
    int right = height(node->right);
    return 1 + (left > right ? left : right);
}

void destroy(Node* node) {
    if (node == nullptr) {
        return;
    }
    destroy(node->left);
    destroy(node->right);
    delete node;
}

int main() {
    Node* root = nullptr;
    for (int value : {4, 2, 6, 1, 3, 5, 7}) {
        root = insert(root, value);
    }
    in_order(root);
    std::cout << "\\nheight " << height(root) << ", contains 5: "
              << (contains(root, 5) ? "yes" : "no") << ", contains 9: "
              << (contains(root, 9) ? "yes" : "no") << "\\n";
    destroy(root);

    Node* chain = nullptr;
    for (int value = 1; value <= 7; ++value) {
        chain = insert(chain, value);
    }
    std::cout << "sorted inserts give height " << height(chain) << "\\n";
    destroy(chain);
    return 0;
}
''', '''1 2 3 4 5 6 7 
height 3, contains 5: yes, contains 9: no
sorted inserts give height 7'''),
            exp("What to remember when you use std::map\n\n"
                "std::map and std::set are balanced search trees, so they keep the good "
                "shape no matter what order the keys arrive in. That is what you are paying "
                "for over a sorted vector.\n\n"
                "The trade is cache behaviour: a vector's elements sit next to each other, "
                "and a tree's nodes are scattered wherever the allocator put them. For small "
                "collections a sorted vector with binary search is often faster."),
            CHALLENGE,
            code('''#include <iostream>

struct Node {
    int value;
    Node* left;
    Node* right;
};

Node* make(int value, Node* left = nullptr, Node* right = nullptr) {
    return new Node{value, left, right};
}

int smallest(const Node* node) {
    while (node->left != nullptr) {
        node = node->left;
    }
    return node->value;
}

int largest(const Node* node) {
    while (node->right != nullptr) {
        node = node->right;
    }
    return node->value;
}

int main() {
    Node* leaf1 = make(1);
    Node* leaf3 = make(3);
    Node* two = make(2, leaf1, leaf3);
    Node* leaf7 = make(7);
    Node* six = make(6, nullptr, leaf7);
    Node* root = make(5, two, six);

    std::cout << "smallest " << smallest(root) << " largest " << largest(root) << "\\n";
    std::cout << "left of root is " << root->left->value << ", right is "
              << root->right->value << "\\n";
    return 0;
}
''', '''smallest 1 largest 7
left of root is 2, right is 6'''),
            quiz("What turns a binary search tree into a linked list in effect?",
                 ["Storing strings", "Inserting values in sorted order, so every node goes "
                  "to one side", "Deleting the root", "Using recursion"],
                 1, "Sorted input makes the tree degenerate into a chain, and search becomes "
                    "linear - which is what balancing fixes."),
           ]),

    lesson("93004", 93, "Trees", "AVL Rotations",
           "When one side grows too tall, rotate - and the tree stays logarithmic.",
           ["Compute the balance factor of a node.",
            "Apply a single rotation and say what it fixes.",
            "Explain why a double rotation exists."],
           [exp("A tree that heals itself\n\n"
                "An AVL tree is a binary search tree that, after every insert, checks the "
                "heights of its two subtrees. If they differ by more than one, it rotates: "
                "one node changes parent, the ordering is preserved, and the height comes "
                "back down.\n\n"
                "The balance factor is the height of the left subtree minus the height of "
                "the right. Values of -1, 0 and 1 are fine; 2 or -2 means a rotation.\n\n"
                "One rotation fixes an outside case: a node too deep on the left of a "
                "left-heavy node. A double rotation fixes the inside case: a node that is "
                "on the right of a left child."),
            dfn("Rotation", "A local rearrangement of three nodes and their subtrees that "
                            "preserves binary-search ordering while changing the tree's "
                            "shape and reducing its height."),
            exp("A left rotation, counted\n\n"
                "The tree is 3 - 2 - 1 down the left side: balanced factors of 2 and 1, so it "
                "needs a right rotation about 3. After rotating, 2 is the root with 1 and 3 "
                "as children, and the height drops from three to two.\n\n"
                "Nothing was re-sorted: the in-order traversal is the same before and after, "
                "which is the property that makes rotations legal."),
            code('''#include <iostream>

struct Node {
    int value;
    Node* left = nullptr;
    Node* right = nullptr;
};

int height(const Node* node) {
    if (node == nullptr) {
        return 0;
    }
    int left = height(node->left);
    int right = height(node->right);
    return 1 + (left > right ? left : right);
}

int balance(const Node* node) {
    return height(node->left) - height(node->right);
}

Node* rotate_left(Node* node) {
    Node* new_root = node->right;
    node->right = new_root->left;
    new_root->left = node;
    return new_root;
}

void in_order(const Node* node) {
    if (node == nullptr) {
        return;
    }
    in_order(node->left);
    std::cout << node->value << " ";
    in_order(node->right);
}

int main() {
    Node one{1};
    Node three{3};
    Node two{2};
    one.right = &two;
    two.right = &three;

    std::cout << "before: root " << one.value << " height " << height(&one)
              << " balance " << balance(&one) << "\\n";
    Node* root = rotate_left(&one);
    std::cout << "after:  root " << root->value << " height " << height(root)
              << " balance " << balance(root) << "\\n";
    std::cout << "in order: ";
    in_order(root);
    std::cout << "\\n";
    return 0;
}
''', '''before: root 1 height 3 balance -2
after:  root 2 height 2 balance 0
in order: 1 2 3'''),
            exp("Why a single rotation is not always enough\n\n"
                "Insert 1, 3, 2 in that order. The root 1 is left-heavy by two, but the "
                "trouble is on the right of its left child - the inside case. A single "
                "rotation moves the problem rather than fixing it, so the fix is two "
                "rotations: rotate the child left, then the root right.\n\n"
                "That is the whole rule: outside cases take one rotation, inside cases take "
                "two. Red-black trees avoid the bookkeeping with a colour bit instead, at "
                "the cost of a slightly taller tree."),
            CHALLENGE,
            code('''#include <iostream>

struct Node {
    int value;
    Node* left = nullptr;
    Node* right = nullptr;
};

int height(const Node* node) {
    if (node == nullptr) {
        return 0;
    }
    int left = height(node->left);
    int right = height(node->right);
    return 1 + (left > right ? left : right);
}

int balance(const Node* node) {
    return height(node->left) - height(node->right);
}

int main() {
    Node c{3}, b{2}, a{1};
    a.right = &b;
    b.right = &c;
    std::cout << "chain of three: height " << height(&a) << " balance " << balance(&a)
              << "\\n";

    Node x{1}, y{3}, top{2, &x, &y};
    std::cout << "same three values balanced: height " << height(&top) << " balance "
              << balance(&top) << "\\n";
    return 0;
}
''', '''chain of three: height 3 balance -2
same three values balanced: height 2 balance 0'''),
            quiz("An AVL node shows a balance factor of -2. What must happen?",
                 ["Nothing, -2 is allowed", "A rotation, because the right side is two "
                  "levels deeper than the left", "The node must be deleted",
                  "The values must be re-sorted"],
                 1, "Only -1, 0 and 1 are balanced; a magnitude of two is repaired by a "
                    "rotation - one for an outside case, two for an inside case."),
           ]),

    lesson("93005", 93, "Trees", "What Red-Black Trees Guarantee",
           "The colours are bookkeeping; the promise is a height bound.",
           ["State the height bound a red-black tree guarantees.",
            "Say what that bound means for search, insert and erase.",
            "Choose between std::map, a sorted vector and a hash container."],
           [exp("The only number that matters\n\n"
                "A red-black tree guarantees that its height is at most twice the base-2 "
                "logarithm of the number of nodes plus one. For a thousand nodes that is "
                "under twenty levels; for a million, under forty.\n\n"
                "Twice the ideal height means every search, insert and erase is O(log n) in "
                "the worst case - not on average, not usually, but always.\n\n"
                "That guarantee is the entire reason std::map and std::set are specified as "
                "red-black trees in practice."),
            dfn("Worst case", "The slowest the operation can be, over every possible input "
                              "of that size - as opposed to the average over random inputs."),
            exp("The bound, with nothing hidden\n\n"
                "For fifteen values, the bound is twice log2(16), which is eight levels. A "
                "balanced tree of fifteen values is four levels, so the guarantee leaves "
                "room.\n\n"
                "The unbalanced case is unbounded: insert fifteen sorted values into a plain "
                "binary search tree and the height is fifteen. That is the difference "
                "between a guarantee and a hope."),
            code('''#include <cmath>
#include <iostream>
#include <map>
#include <string>

int main() {
    for (int count : {15, 1000, 1000000}) {
        double bound = 2.0 * std::log2(static_cast<double>(count) + 1.0);
        std::cout << count << " nodes: red-black height at most "
                  << static_cast<int>(std::ceil(bound)) << "\\n";
    }

    std::map<std::string, int> ages;
    ages["ada"] = 36;
    ages["bo"] = 41;
    ages["cy"] = 29;
    ages["ada"] = 37;
    std::cout << "map size " << ages.size() << " first " << ages.begin()->first
              << " last " << ages.rbegin()->first << " ada is " << ages["ada"] << "\\n";
    std::cout << "lookup of missing key found: " << (ages.count("dee") != 0 ? "yes" : "no")
              << "\\n";
    return 0;
}
''', '''15 nodes: red-black height at most 8
1000 nodes: red-black height at most 20
1000000 nodes: red-black height at most 40
map size 3 first ada last cy ada is 37
lookup of missing key found: no'''),
            exp("Choosing, honestly\n\n"
                "std::map when you need ordered traversal, range queries or the smallest "
                "and largest key quickly. std::unordered_map when you only ever look up by "
                "key and the keys hash well - it is O(1) on average, but the worst case is "
                "linear.\n\n"
                "A sorted std::vector beats both for small collections that are built once "
                "and searched many times: binary search over contiguous memory is very hard "
                "to beat below a few hundred elements."),
            CHALLENGE,
            code('''#include <algorithm>
#include <cmath>
#include <iostream>
#include <string>
#include <vector>

int main() {
    std::vector<std::string> names{"cy", "ada", "bo"};
    std::sort(names.begin(), names.end());
    bool found = std::binary_search(names.begin(), names.end(), std::string("bo"));
    std::cout << "sorted vector finds bo: " << (found ? "yes" : "no") << "\\n";
    std::cout << "steps needed at most: "
              << static_cast<int>(std::ceil(std::log2(static_cast<double>(names.size()))))
              << "\\n";
    return 0;
}
''', '''sorted vector finds bo: yes
steps needed at most: 2'''),
            quiz("What does a red-black tree actually guarantee?",
                 ["That every search is one step", "That the height stays within twice "
                  "log2(n+1), so operations are O(log n) in the worst case",
                  "That inserts never move a node", "That keys stay sorted in memory"],
                 1, "The colour rules exist only to enforce the height bound."),
           ]),

    lesson("93006", 93, "Trees", "Heaps and priority_queue",
           "The container that always hands you the largest thing first.",
           ["Use std::priority_queue for a maximum heap.",
            "Turn it into a minimum heap with a comparator.",
            "Store items with their own priority order."],
           [exp("Not sorted, but always on top\n\n"
                "A heap keeps one promise: the top element is the largest (or the smallest) "
                "of everything in it. It does not keep the rest in order, which is why "
                "push and pop cost O(log n) while sorting would cost more.\n\n"
                "std::priority_queue is that heap with the plumbing done. By default it is a "
                "maximum heap on operator<. To get a minimum heap you supply "
                "std::greater<int> - and note the third template argument, not a runtime "
                "flag.\n\n"
                "It is the standard answer to 'process the most urgent item next'."),
            dfn("Priority queue", "An adaptor over a heap that returns the greatest element "
                                  "first, at O(log n) per insertion and removal."),
            exp("Max, min, and your own order\n\n"
                "The first queue hands back the largest number, the second the smallest. "
                "The third stores a struct and compares by priority, breaking ties by "
                "arrival order.\n\n"
                "That tie-break matters in schedulers: two jobs of equal priority should "
                "run in the order they arrived, which means the comparator has to look at "
                "both fields."),
            code('''#include <functional>
#include <iostream>
#include <queue>
#include <string>
#include <vector>

struct Task {
    int priority;
    int arrival;
    std::string name;
};

struct Later {
    bool operator()(const Task& a, const Task& b) const {
        if (a.priority != b.priority) {
            return a.priority < b.priority;
        }
        return a.arrival > b.arrival;
    }
};

int main() {
    std::priority_queue<int> max_heap;
    for (int value : {3, 1, 4, 1, 5}) {
        max_heap.push(value);
    }
    std::cout << "max first: " << max_heap.top() << "\\n";

    std::priority_queue<int, std::vector<int>, std::greater<int>> min_heap;
    for (int value : {3, 1, 4, 1, 5}) {
        min_heap.push(value);
    }
    std::cout << "min first: " << min_heap.top() << "\\n";

    std::priority_queue<Task, std::vector<Task>, Later> tasks;
    tasks.push(Task{2, 1, "report"});
    tasks.push(Task{5, 2, "outage"});
    tasks.push(Task{5, 3, "backup"});
    tasks.push(Task{1, 4, "tidy"});
    while (!tasks.empty()) {
        std::cout << tasks.top().name << " (" << tasks.top().priority << ")\\n";
        tasks.pop();
    }
    return 0;
}
''', '''max first: 5
min first: 1
outage (5)
backup (5)
report (2)
tidy (1)'''),
            exp("What a heap cannot do\n\n"
                "There is no way to remove an arbitrary element, and no way to iterate in "
                "order. If you need either, the container is wrong: use std::multiset or a "
                "sorted vector.\n\n"
                "What a heap is unbeatable at is the top-k problem: push everything, pop k "
                "times. That is O(n log k) and needs no full sort."),
            CHALLENGE,
            code('''#include <functional>
#include <iostream>
#include <queue>
#include <vector>

int main() {
    std::vector<int> scores{72, 91, 64, 88, 95, 70};
    std::priority_queue<int, std::vector<int>, std::greater<int>> best;
    for (int score : scores) {
        best.push(score);
        if (best.size() > 3) {
            best.pop();
        }
    }
    std::cout << "best " << best.size() << " scores, top is " << best.top() << "\\n";
    while (!best.empty()) {
        std::cout << best.top() << " ";
        best.pop();
    }
    std::cout << "\\n";
    return 0;
}
''', '''best 3 scores, top is 88
88 91 95 ''')
            ,
            quiz("How do you make std::priority_queue return the smallest element first?",
                 ["Push negative numbers only", "Supply std::greater as the third template "
                  "argument", "Call sort() first", "Use a std::stack"],
                 1, "The comparator is a compile-time type parameter; greater reverses the "
                    "default ordering."),
           ]),

    lesson("93007", 93, "Trees", "A Binary Heap by Hand",
           "Sift up, sift down, and the array that pretends to be a tree.",
           ["Store a heap in an array and find a node's children by arithmetic.",
            "Restore the heap property with sift up and sift down.",
            "Build a heap in place from an unsorted array."],
           [exp("A tree with no pointers\n\n"
                "A complete binary tree fits exactly into an array: node i has children at "
                "2i+1 and 2i+2, and its parent at (i-1)/2. There is no allocation per node "
                "and no pointer chasing, which is why heaps are so fast.\n\n"
                "Two operations keep the promise. Sift up moves a new element toward the "
                "root while it is larger than its parent. Sift down moves an element toward "
                "the leaves while a child is larger than it.\n\n"
                "Heapifying an arbitrary array means sifting down from the middle to the "
                "start - and that costs O(n), not O(n log n)."),
            dfn("Heap property", "Every parent is at least as large as each of its children. "
                                 "The largest element is therefore at index 0, and no other "
                                 "order is implied."),
            exp("Push, pop and the arithmetic\n\n"
                "The class below stores ints in a vector, pushes with sift up and pops by "
                "swapping the root with the last element and sifting down.\n\n"
                "After all the pushes and pops the values come out in descending order, "
                "which is a heap sort done through the public interface."),
            code('''#include <iostream>
#include <utility>
#include <vector>

class BinaryHeap {
public:
    void push(int value) {
        data_.push_back(value);
        std::size_t index = data_.size() - 1;
        while (index > 0) {
            std::size_t parent = (index - 1) / 2;
            if (data_[parent] >= data_[index]) {
                break;
            }
            std::swap(data_[parent], data_[index]);
            index = parent;
        }
    }

    int pop() {
        int top = data_.front();
        data_.front() = data_.back();
        data_.pop_back();
        std::size_t index = 0;
        while (true) {
            std::size_t left = 2 * index + 1;
            std::size_t right = left + 1;
            std::size_t largest = index;
            if (left < data_.size() && data_[left] > data_[largest]) {
                largest = left;
            }
            if (right < data_.size() && data_[right] > data_[largest]) {
                largest = right;
            }
            if (largest == index) {
                break;
            }
            std::swap(data_[index], data_[largest]);
            index = largest;
        }
        return top;
    }

    bool empty() const { return data_.empty(); }
    std::size_t size() const { return data_.size(); }
private:
    std::vector<int> data_;
};

int main() {
    BinaryHeap heap;
    for (int value : {9, 4, 7, 1, 8, 2}) {
        heap.push(value);
    }
    std::cout << "size " << heap.size() << " popping:";
    while (!heap.empty()) {
        std::cout << " " << heap.pop();
    }
    std::cout << "\\n";
    return 0;
}
''', '''size 6 popping: 9 8 7 4 2 1'''),
            exp("Heapify in place\n\n"
                "Given an unsorted array, sift down from the last parent to the root. Every "
                "subtree below the current index is already a heap by the time you get to "
                "it, so one pass is enough.\n\n"
                "This is what std::make_heap does, and it is why building a heap from n "
                "values is a linear operation rather than n insertions."),
            CHALLENGE,
            code('''#include <iostream>
#include <utility>
#include <vector>

void sift_down(std::vector<int>& data, std::size_t index) {
    while (true) {
        std::size_t left = 2 * index + 1;
        std::size_t right = left + 1;
        std::size_t largest = index;
        if (left < data.size() && data[left] > data[largest]) {
            largest = left;
        }
        if (right < data.size() && data[right] > data[largest]) {
            largest = right;
        }
        if (largest == index) {
            return;
        }
        std::swap(data[index], data[largest]);
        index = largest;
    }
}

bool is_heap(const std::vector<int>& data) {
    for (std::size_t i = 1; i < data.size(); ++i) {
        if (data[(i - 1) / 2] < data[i]) {
            return false;
        }
    }
    return true;
}

int main() {
    std::vector<int> data{4, 10, 3, 5, 1, 8};
    std::cout << "before: heap property holds " << (is_heap(data) ? "yes" : "no") << "\\n";
    for (std::size_t i = data.size() / 2; i-- > 0;) {
        sift_down(data, i);
    }
    std::cout << "after:  heap property holds " << (is_heap(data) ? "yes" : "no")
              << ", root is " << data.front() << "\\n";
    return 0;
}
''', '''before: heap property holds no
after:  heap property holds yes, root is 10'''),
            quiz("Where are the children of the element at index i in an array-backed heap?",
                 ["i+1 and i+2", "2i+1 and 2i+2", "i/2 and i/2+1", "The end of the array"],
                 1, "That arithmetic is what removes the need for pointers entirely."),
           ]),

    lesson("93008", 93, "Trees", "Tries",
           "A tree keyed by characters, where the path is the string.",
           ["Insert and look up words in a trie.",
            "Count how many words share a prefix.",
            "Say when a trie beats a hash set."],
           [exp("The word is the path\n\n"
                "A trie stores characters on edges, not values in nodes. To insert 'cat' you "
                "walk c, a, t, creating nodes as needed, and mark the last one as the end of "
                "a word.\n\n"
                "Lookup walks the same path, so its cost depends on the length of the word - "
                "not on how many words are stored. A million words cost the same three "
                "steps as three words.\n\n"
                "The trade is memory: one node per distinct prefix, and a child map or array "
                "in each node."),
            dfn("Trie", "A tree whose edges are labelled with characters, so every path from "
                        "the root spells a prefix and marked nodes spell complete words."),
            exp("Insert, find, and count a prefix\n\n"
                "Four words go in, one duplicate, and a lookup for a word that is only a "
                "prefix ('do' when only 'dot' was inserted) correctly fails - the marker is "
                "what separates the two.\n\n"
                "Counting the words under a prefix is the question autocomplete asks, and it "
                "is a subtree walk from wherever the prefix ends."),
            code('''#include <iostream>
#include <map>
#include <memory>
#include <string>

struct TrieNode {
    std::map<char, std::unique_ptr<TrieNode>> children;
    bool ends_word = false;
};

class Trie {
public:
    void insert(const std::string& word) {
        TrieNode* node = &root_;
        for (char letter : word) {
            std::unique_ptr<TrieNode>& child = node->children[letter];
            if (!child) {
                child = std::make_unique<TrieNode>();
            }
            node = child.get();
        }
        node->ends_word = true;
    }

    bool contains(const std::string& word) const {
        const TrieNode* node = &root_;
        for (char letter : word) {
            auto found = node->children.find(letter);
            if (found == node->children.end()) {
                return false;
            }
            node = found->second.get();
        }
        return node->ends_word;
    }

    int count_prefix(const std::string& prefix) const {
        const TrieNode* node = &root_;
        for (char letter : prefix) {
            auto found = node->children.find(letter);
            if (found == node->children.end()) {
                return 0;
            }
            node = found->second.get();
        }
        return count_words(node);
    }
private:
    static int count_words(const TrieNode* node) {
        int total = node->ends_word ? 1 : 0;
        for (const auto& entry : node->children) {
            total += count_words(entry.second.get());
        }
        return total;
    }
    TrieNode root_;
};

int main() {
    Trie trie;
    for (const char* word : {"cat", "car", "card", "dog", "cat"}) {
        trie.insert(word);
    }
    std::cout << std::boolalpha;
    std::cout << "contains cat: " << trie.contains("cat") << "\\n";
    std::cout << "contains ca: " << trie.contains("ca") << "\\n";
    std::cout << "words under car: " << trie.count_prefix("car") << "\\n";
    std::cout << "words under c: " << trie.count_prefix("c") << "\\n";
    std::cout << "words under x: " << trie.count_prefix("x") << "\\n";
    return 0;
}
''', '''contains cat: true
contains ca: false
words under car: 2
words under c: 3
words under x: 0'''),
            exp("Trie or hash set?\n\n"
                "For plain membership a hash set is smaller and usually faster. A trie wins "
                "the moment the question involves a prefix: autocomplete, spell suggestions, "
                "IP routing tables and word games are all prefix questions.\n\n"
                "The memory cost is real. A trie over English can use twenty times what the "
                "words themselves need, which is why compressed variants exist."),
            CHALLENGE,
            code('''#include <iostream>
#include <map>
#include <memory>
#include <string>

struct Node {
    std::map<char, std::unique_ptr<Node>> children;
    bool ends_word = false;
};

int main() {
    Node root;
    const std::string words[] = {"go", "gone", "goal"};
    for (const std::string& word : words) {
        Node* node = &root;
        for (char letter : word) {
            auto& child = node->children[letter];
            if (!child) {
                child = std::make_unique<Node>();
            }
            node = child.get();
        }
        node->ends_word = true;
    }
    const Node* node = root.children.at('g').get();
    std::cout << "after g there are " << node->children.size() << " next letters\\n";
    node = node->children.at('o').get();
    std::cout << "go ends a word: " << (node->ends_word ? "yes" : "no") << "\\n";
    std::cout << "go has " << node->children.size() << " continuations\\n";
    return 0;
}
''', '''after g there are 1 next letters
go ends a word: yes
go has 2 continuations'''),
            quiz("What does a trie lookup cost depend on?",
                 ["The number of stored words", "The length of the word being looked up",
                  "The size of the alphabet only", "The order of insertion"],
                 1, "One step per character, regardless of how many words share the trie."),
           ]),
]
