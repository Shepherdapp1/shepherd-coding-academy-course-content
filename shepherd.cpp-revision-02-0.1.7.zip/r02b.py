"""Gap fill part 2, module 94 — graphs, hashing and complexity."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("94001", 94, "Graphs", "Representing a Graph",
           "An adjacency list, an adjacency matrix, and the cost of each choice.",
           ["Build an adjacency list and an adjacency matrix.",
            "Say what each representation costs in memory and time.",
            "Choose one for a sparse graph and one for a dense graph."],
           [exp("Two ways to write down a graph\n\n"
                "A graph is a set of vertices and a set of edges. The adjacency list stores, "
                "for each vertex, the list of its neighbours: memory is proportional to the "
                "number of edges, and asking for a vertex's neighbours is immediate.\n\n"
                "The adjacency matrix is a grid of n by n booleans or weights: asking whether "
                "two vertices are connected is one lookup, but memory is n squared whether "
                "the edges exist or not.\n\n"
                "Real graphs are usually sparse - road networks, social graphs, dependencies - "
                "so the list is the default. The matrix wins when the graph is dense or you "
                "need matrix operations."),
            dfn("Sparse graph", "A graph whose number of edges is far smaller than the "
                                "square of its vertex count, so most matrix cells would be "
                                "empty."),
            exp("The same graph, two ways\n\n"
                "Five vertices and six undirected edges are stored twice - once as lists, "
                "once as a matrix - and both report the same degree for vertex 0.\n\n"
                "Because the graph is undirected, every edge is written in both directions. "
                "Forget that and breadth-first search will explore a graph that only goes "
                "one way."),
            code('''#include <iostream>
#include <vector>

int main() {
    int vertices = 5;
    std::vector<std::vector<int>> list(static_cast<std::size_t>(vertices));
    auto add = [&list](int a, int b) {
        list[static_cast<std::size_t>(a)].push_back(b);
        list[static_cast<std::size_t>(b)].push_back(a);
    };
    add(0, 1);
    add(0, 2);
    add(1, 2);
    add(2, 3);
    add(3, 4);

    for (int v = 0; v < vertices; ++v) {
        std::cout << "vertex " << v << " has " << list[static_cast<std::size_t>(v)].size()
                  << " neighbours:";
        for (int neighbour : list[static_cast<std::size_t>(v)]) {
            std::cout << " " << neighbour;
        }
        std::cout << "\\n";
    }

    std::vector<std::vector<bool>> matrix(
        static_cast<std::size_t>(vertices), std::vector<bool>(static_cast<std::size_t>(vertices), false));
    for (int v = 0; v < vertices; ++v) {
        for (int neighbour : list[static_cast<std::size_t>(v)]) {
            matrix[static_cast<std::size_t>(v)][static_cast<std::size_t>(neighbour)] = true;
        }
    }
    std::cout << "matrix cell 0,2 is " << (matrix[0][2] ? "true" : "false")
              << " and 2,0 is " << (matrix[2][0] ? "true" : "false") << "\\n";
    std::cout << "matrix size " << matrix.size() << " x " << matrix[0].size() << "\\n";
    return 0;
}
''', '''vertex 0 has 2 neighbours: 1 2
vertex 1 has 2 neighbours: 0 2
vertex 2 has 3 neighbours: 0 1 3
vertex 3 has 2 neighbours: 2 4
vertex 4 has 1 neighbours: 3
matrix cell 0,2 is true and 2,0 is true
matrix size 5 x 5'''),
            exp("Directed and weighted\n\n"
                "A directed graph writes each edge only one way, and a weighted graph stores "
                "a number with every neighbour instead of just the vertex.\n\n"
                "Both fit the same list: instead of vector<int>, use vector<pair<int,int>> "
                "for (neighbour, weight), and skip the reverse insertion. Everything later in "
                "this module - search, shortest paths, topological order - is written against "
                "that shape."),
            CHALLENGE,
            code('''#include <iostream>
#include <utility>
#include <vector>

int main() {
    std::vector<std::vector<std::pair<int, int>>> weighted(4);
    weighted[0].push_back({1, 4});
    weighted[0].push_back({2, 1});
    weighted[1].push_back({3, 2});
    weighted[2].push_back({3, 7});

    for (std::size_t v = 0; v < weighted.size(); ++v) {
        std::cout << "from " << v << ":";
        for (const auto& edge : weighted[v]) {
            std::cout << " to " << edge.first << " costs " << edge.second;
        }
        std::cout << "\\n";
    }
    return 0;
}
''', '''from 0: to 1 costs 4 to 2 costs 1
from 1: to 3 costs 2
from 2: to 3 costs 7
from 3:'''),
            quiz("A graph has 10,000 vertices and 20,000 edges. Which representation fits better?",
                 ["Adjacency matrix, because lookup is one step", "Adjacency list, because "
                  "memory follows the edges rather than the square of the vertices",
                  "Both use the same memory", "Neither can hold it"],
                 1, "A 10,000 by 10,000 matrix is a hundred million cells to store twenty "
                    "thousand edges; the list stores only what exists."),
           ]),

    lesson("94002", 94, "Graphs", "Breadth-First Search",
           "Nearest first, one ring at a time - and the shortest path in an unweighted graph.",
           ["Run BFS from a start vertex with a queue.",
            "Read the distance array it produces.",
            "Say what BFS gives you that DFS does not."],
           [exp("Explore by distance\n\n"
                "Breadth-first search visits the start, then everything one edge away, then "
                "everything two edges away. A queue enforces that order: push the neighbours "
                "at the back, take the next vertex from the front.\n\n"
                "Because it never reaches a vertex by a longer path before a shorter one, the "
                "distance it records is the shortest path - counted in edges. That is the "
                "reason BFS is the answer to 'fewest moves' questions.\n\n"
                "It also finds everything reachable, which is how you check whether a graph "
                "is connected."),
            dfn("Breadth-first search", "A traversal that explores a graph in rings of equal "
                                        "distance from the start, using a queue, and yields "
                                        "shortest paths in unweighted graphs."),
            exp("Distances from vertex 0\n\n"
                "Seven vertices in a chain with a shortcut. BFS reports distance 0 for the "
                "start, 1 for its neighbours, 2 for theirs, and -1 for the one it cannot "
                "reach.\n\n"
                "The unreachable vertex is the point: without the visited array, BFS would "
                "loop forever, and with it, the -1 is information."),
            code('''#include <iostream>
#include <queue>
#include <vector>

int main() {
    std::vector<std::vector<int>> graph(7);
    auto add = [&graph](int a, int b) {
        graph[static_cast<std::size_t>(a)].push_back(b);
        graph[static_cast<std::size_t>(b)].push_back(a);
    };
    add(0, 1);
    add(0, 2);
    add(1, 3);
    add(2, 3);
    add(3, 4);
    add(4, 5);

    std::vector<int> distance(graph.size(), -1);
    std::queue<int> pending;
    distance[0] = 0;
    pending.push(0);
    std::vector<int> order;
    while (!pending.empty()) {
        int current = pending.front();
        pending.pop();
        order.push_back(current);
        for (int neighbour : graph[static_cast<std::size_t>(current)]) {
            if (distance[static_cast<std::size_t>(neighbour)] == -1) {
                distance[static_cast<std::size_t>(neighbour)] =
                    distance[static_cast<std::size_t>(current)] + 1;
                pending.push(neighbour);
            }
        }
    }

    std::cout << "visit order:";
    for (int v : order) {
        std::cout << " " << v;
    }
    std::cout << "\\n";
    for (std::size_t v = 0; v < distance.size(); ++v) {
        std::cout << "distance to " << v << " is " << distance[v] << "\\n";
    }
    return 0;
}
''', '''visit order: 0 1 2 3 4 5
distance to 0 is 0
distance to 1 is 1
distance to 2 is 1
distance to 3 is 2
distance to 4 is 3
distance to 5 is 4
distance to 6 is -1'''),
            exp("Levels, and the shortest path itself\n\n"
                "Recording the ring number is one line: every vertex discovered from a "
                "vertex at distance d is at distance d+1.\n\n"
                "To get the path rather than its length, store the vertex you came from and "
                "walk backwards from the target. That parent array is the only addition "
                "needed, and it costs one int per vertex."),
            CHALLENGE,
            code('''#include <iostream>
#include <queue>
#include <vector>

int main() {
    std::vector<std::vector<int>> graph{{1, 2}, {0, 3}, {0, 3}, {1, 2, 4}, {3}};
    std::vector<int> distance(graph.size(), -1);
    std::queue<int> pending;
    distance[0] = 0;
    pending.push(0);
    while (!pending.empty()) {
        int current = pending.front();
        pending.pop();
        for (int neighbour : graph[static_cast<std::size_t>(current)]) {
            if (distance[static_cast<std::size_t>(neighbour)] == -1) {
                distance[static_cast<std::size_t>(neighbour)] =
                    distance[static_cast<std::size_t>(current)] + 1;
                pending.push(neighbour);
            }
        }
    }
    std::cout << "far vertex is 4 at distance "
              << distance[4] << "\\n";
    int reached = 0;
    for (int d : distance) {
        reached += d >= 0 ? 1 : 0;
    }
    std::cout << "reached " << reached << " of " << distance.size() << " vertices\\n";
    return 0;
}
''', '''far vertex is 4 at distance 3
reached 5 of 5 vertices'''),
            quiz("Why does BFS give shortest paths while DFS does not?",
                 ["Because it uses a queue, so it reaches each vertex by the fewest edges "
                  "first", "Because it is recursive", "Because it sorts the neighbours",
                  "Because it ignores weights"],
                 1, "FIFO order means a vertex is first discovered at its minimum edge "
                    "distance; DFS can arrive by a long path first."),
           ]),

    lesson("94003", 94, "Graphs", "Depth-First Search and Cycle Detection",
           "Go as deep as you can, and use colour to spot the edge that closes a loop.",
           ["Run DFS with an explicit stack or recursion.",
            "Detect a cycle in a directed graph with three colours.",
            "Say what a back edge means."],
           [exp("Down one path, then back\n\n"
                "Depth-first search follows one edge as far as it goes, then backtracks. "
                "Recursion does it naturally; an explicit stack does the same thing without "
                "the call depth.\n\n"
                "The extra power comes from when you mark vertices. In a directed graph a "
                "cycle exists exactly when DFS meets a vertex that is still on the current "
                "path - a back edge. Marking vertices white (unseen), grey (on the path) and "
                "black (finished) is the standard way to see that.\n\n"
                "Two colours cannot distinguish 'already finished' from 'still on the path', "
                "which is why the third is needed."),
            dfn("Back edge", "An edge in a depth-first traversal that points to a vertex "
                             "still on the current path - proof that the graph contains a "
                             "cycle."),
            exp("A cycle, then no cycle\n\n"
                "The first graph has 0 to 1 to 2 to 0, and DFS finds the back edge and "
                "reports true. Removing that one edge makes the same graph acyclic.\n\n"
                "The state of each vertex is the whole algorithm: visiting a grey vertex is "
                "the discovery, and turning it black means no cycle through it."),
            code('''#include <iostream>
#include <vector>

bool visit(int node, const std::vector<std::vector<int>>& graph, std::vector<int>& colour) {
    colour[static_cast<std::size_t>(node)] = 1;
    for (int neighbour : graph[static_cast<std::size_t>(node)]) {
        std::size_t index = static_cast<std::size_t>(neighbour);
        if (colour[index] == 1) {
            return true;
        }
        if (colour[index] == 0 && visit(neighbour, graph, colour)) {
            return true;
        }
    }
    colour[static_cast<std::size_t>(node)] = 2;
    return false;
}

bool has_cycle(const std::vector<std::vector<int>>& graph) {
    std::vector<int> colour(graph.size(), 0);
    for (std::size_t node = 0; node < graph.size(); ++node) {
        if (colour[node] == 0 && visit(static_cast<int>(node), graph, colour)) {
            return true;
        }
    }
    return false;
}

int main() {
    std::vector<std::vector<int>> cyclic{{1}, {2}, {0, 3}, {}};
    std::vector<std::vector<int>> acyclic{{1}, {2}, {3}, {}};

    std::cout << std::boolalpha;
    std::cout << "cyclic graph has a cycle: " << has_cycle(cyclic) << "\\n";
    std::cout << "acyclic graph has a cycle: " << has_cycle(acyclic) << "\\n";

    std::vector<int> order;
    std::vector<int> colour(acyclic.size(), 0);
    std::vector<int> stack{0};
    while (!stack.empty()) {
        int node = stack.back();
        stack.pop_back();
        if (colour[static_cast<std::size_t>(node)] != 0) {
            continue;
        }
        colour[static_cast<std::size_t>(node)] = 2;
        order.push_back(node);
        for (auto it = acyclic[static_cast<std::size_t>(node)].rbegin();
             it != acyclic[static_cast<std::size_t>(node)].rend(); ++it) {
            stack.push_back(*it);
        }
    }
    std::cout << "dfs order:";
    for (int node : order) {
        std::cout << " " << node;
    }
    std::cout << "\\n";
    return 0;
}
''', '''cyclic graph has a cycle: true
acyclic graph has a cycle: false
dfs order: 0 1 2 3'''),
            exp("Why this matters outside graph theory\n\n"
                "Cycle detection is how a build system refuses a circular dependency, how a "
                "spreadsheet spots a formula that refers to itself, and how a package "
                "manager rejects an install loop.\n\n"
                "It is also the difference between a job that terminates and one that runs "
                "forever - which is why 'check for cycles first' is a rule in every "
                "scheduler."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

bool reaches(int from, int target, const std::vector<std::vector<int>>& graph,
             std::vector<bool>& seen) {
    if (from == target) {
        return true;
    }
    if (seen[static_cast<std::size_t>(from)]) {
        return false;
    }
    seen[static_cast<std::size_t>(from)] = true;
    for (int neighbour : graph[static_cast<std::size_t>(from)]) {
        if (reaches(neighbour, target, graph, seen)) {
            return true;
        }
    }
    return false;
}

int main() {
    std::vector<std::vector<int>> graph{{1, 2}, {3}, {3}, {4}, {}};
    std::vector<bool> seen(graph.size(), false);
    std::cout << std::boolalpha;
    std::cout << "0 reaches 4: " << reaches(0, 4, graph, seen) << "\\n";
    std::vector<bool> seen_again(graph.size(), false);
    std::cout << "4 reaches 0: " << reaches(4, 0, graph, seen_again) << "\\n";
    return 0;
}
''', '''0 reaches 4: true
4 reaches 0: false'''),
            quiz("Why does cycle detection need three states rather than two?",
                 ["To save memory", "Because 'already finished' and 'still on the current "
                  "path' must be told apart - only the second is a cycle",
                  "Because graphs have colours", "To make it faster"],
                 1, "A finished vertex is fine to meet again; one still on the path means you "
                    "have closed a loop."),
           ]),

    lesson("94004", 94, "Graphs", "Dijkstra's Shortest Path",
           "When edges have different lengths, nearest-first has to become cheapest-first.",
           ["Run Dijkstra with a minimum priority queue.",
            "Explain why a heap replaces the queue.",
            "Say what Dijkstra cannot handle."],
           [exp("BFS, but by total cost\n\n"
                "Breadth-first search assumes every edge costs the same. Give edges weights "
                "and the nearest vertex is no longer the cheapest: a two-edge path might "
                "cost less than a one-edge path.\n\n"
                "Dijkstra keeps a table of the best known cost to each vertex, and always "
                "expands the vertex with the smallest cost so far. A minimum priority queue "
                "is what makes that choice cheap.\n\n"
                "Once a vertex is taken out of the queue its cost is final - and that is only "
                "true because no weight is negative. With a negative edge, a longer path "
                "later could still undercut it, and the algorithm is simply wrong."),
            dfn("Relaxation", "Updating the best known cost to a neighbour when the path "
                              "through the current vertex is cheaper than what is recorded."),
            exp("Six vertices, nine weighted edges\n\n"
                "From vertex 0 the algorithm produces the cheapest cost to each vertex and "
                "the parent that got it there. Vertex 3 is reached for 3 through 1 rather "
                "than 7 directly through 2.\n\n"
                "The queue holds pairs of (cost, vertex) and, by using greater, hands back "
                "the smallest cost first - the same trick as the minimum heap lesson."),
            code('''#include <functional>
#include <iostream>
#include <limits>
#include <queue>
#include <utility>
#include <vector>

int main() {
    const int count = 6;
    std::vector<std::vector<std::pair<int, int>>> graph(static_cast<std::size_t>(count));
    auto add = [&graph](int a, int b, int weight) {
        graph[static_cast<std::size_t>(a)].push_back({b, weight});
        graph[static_cast<std::size_t>(b)].push_back({a, weight});
    };
    add(0, 1, 4);
    add(0, 2, 1);
    add(2, 1, 2);
    add(1, 3, 5);
    add(2, 3, 8);
    add(3, 4, 3);
    add(4, 5, 1);
    add(2, 5, 12);
    add(1, 4, 11);

    const int infinity = std::numeric_limits<int>::max();
    std::vector<int> best(static_cast<std::size_t>(count), infinity);
    std::vector<int> parent(static_cast<std::size_t>(count), -1);
    using Entry = std::pair<int, int>;
    std::priority_queue<Entry, std::vector<Entry>, std::greater<Entry>> pending;
    best[0] = 0;
    pending.push({0, 0});
    while (!pending.empty()) {
        int cost = pending.top().first;
        int node = pending.top().second;
        pending.pop();
        if (cost > best[static_cast<std::size_t>(node)]) {
            continue;
        }
        for (const auto& edge : graph[static_cast<std::size_t>(node)]) {
            int candidate = cost + edge.second;
            if (candidate < best[static_cast<std::size_t>(edge.first)]) {
                best[static_cast<std::size_t>(edge.first)] = candidate;
                parent[static_cast<std::size_t>(edge.first)] = node;
                pending.push({candidate, edge.first});
            }
        }
    }
    for (int v = 0; v < count; ++v) {
        std::cout << "0 to " << v << " costs " << best[static_cast<std::size_t>(v)]
                  << " via " << parent[static_cast<std::size_t>(v)] << "\\n";
    }
    return 0;
}
''', '''0 to 0 costs 0 via -1
0 to 1 costs 3 via 2
0 to 2 costs 1 via 0
0 to 3 costs 8 via 1
0 to 4 costs 11 via 3
0 to 5 costs 12 via 4'''),
            exp("What to reach for instead\n\n"
                "Negative weights: Bellman-Ford, which relaxes every edge n-1 times and can "
                "also report a negative cycle. All pairs at once: Floyd-Warshall, three "
                "nested loops over a matrix.\n\n"
                "Dijkstra is the one you will write most, because road networks, network "
                "routing and game pathfinding all have non-negative costs."),
            CHALLENGE,
            code('''#include <functional>
#include <iostream>
#include <limits>
#include <queue>
#include <utility>
#include <vector>

int main() {
    std::vector<std::vector<std::pair<int, int>>> graph{
        {{1, 1}, {2, 5}}, {{2, 1}, {3, 4}}, {{3, 1}}, {}};
    std::vector<int> best(graph.size(), std::numeric_limits<int>::max());
    using Entry = std::pair<int, int>;
    std::priority_queue<Entry, std::vector<Entry>, std::greater<Entry>> pending;
    best[0] = 0;
    pending.push({0, 0});
    while (!pending.empty()) {
        Entry top = pending.top();
        pending.pop();
        if (top.first > best[static_cast<std::size_t>(top.second)]) {
            continue;
        }
        for (const auto& edge : graph[static_cast<std::size_t>(top.second)]) {
            int candidate = top.first + edge.second;
            if (candidate < best[static_cast<std::size_t>(edge.first)]) {
                best[static_cast<std::size_t>(edge.first)] = candidate;
                pending.push({candidate, edge.first});
            }
        }
    }
    std::cout << "cheapest to 3 is " << best[3] << "\\n";
    std::cout << "cheapest to 2 is " << best[2] << "\\n";
    return 0;
}
''', '''cheapest to 3 is 3
cheapest to 2 is 2'''),
            quiz("Why does Dijkstra fail with a negative edge weight?",
                 ["It runs out of memory", "A vertex's cost is treated as final when it leaves "
                  "the queue, and a later negative edge could still improve it",
                  "The heap cannot hold negatives", "It needs an adjacency matrix"],
                 1, "The finality assumption is what makes it fast; negatives break that "
                    "assumption, so Bellman-Ford is used instead."),
           ]),

    lesson("94005", 94, "Graphs", "Topological Sort",
           "Put every job after the jobs it depends on.",
           ["Produce a topological order with Kahn's algorithm.",
            "Detect that a cycle makes such an order impossible.",
            "Say where topological order is used in real builds."],
           [exp("Dependencies as a directed graph\n\n"
                "If task A must finish before task B, draw an edge from A to B. A topological "
                "order lists every vertex so that each one appears after all the vertices "
                "pointing to it - a valid running order.\n\n"
                "Kahn's algorithm is the practical one: count the incoming edges of every "
                "vertex, start with those that have none, and as each one is emitted, "
                "decrease the count of its neighbours. A neighbour reaching zero becomes "
                "ready.\n\n"
                "If the emitted count is smaller than the number of vertices, the leftovers "
                "are in a cycle and no order exists."),
            dfn("In-degree", "The number of edges pointing into a vertex - for a dependency "
                             "graph, the number of tasks that must run before it."),
            exp("Build order, and a dependency loop\n\n"
                "Six tasks with six dependencies produce an order in which every task follows "
                "what it needs. The second graph is a single loop, so no task can start: the "
                "algorithm reports that none of the five could be ordered.\n\n"
                "That mismatch between 'emitted' and 'total' is the whole cycle test - no "
                "extra traversal needed."),
            code('''#include <iostream>
#include <queue>
#include <string>
#include <vector>

std::vector<int> topological_order(const std::vector<std::vector<int>>& graph, int& emitted) {
    std::vector<int> in_degree(graph.size(), 0);
    for (const auto& edges : graph) {
        for (int target : edges) {
            ++in_degree[static_cast<std::size_t>(target)];
        }
    }
    std::queue<int> ready;
    for (std::size_t v = 0; v < graph.size(); ++v) {
        if (in_degree[v] == 0) {
            ready.push(static_cast<int>(v));
        }
    }
    std::vector<int> order;
    while (!ready.empty()) {
        int node = ready.front();
        ready.pop();
        order.push_back(node);
        for (int target : graph[static_cast<std::size_t>(node)]) {
            if (--in_degree[static_cast<std::size_t>(target)] == 0) {
                ready.push(target);
            }
        }
    }
    emitted = static_cast<int>(order.size());
    return order;
}

int main() {
    std::vector<std::vector<int>> build{{1, 2}, {3}, {3}, {4}, {5}, {}};
    int emitted = 0;
    std::vector<int> order = topological_order(build, emitted);
    std::cout << "order:";
    for (int node : order) {
        std::cout << " " << node;
    }
    std::cout << " (" << emitted << " of " << build.size() << " tasks)\\n";

    std::vector<std::vector<int>> loop{{1}, {2}, {0, 3}, {4}, {}};
    int looped = 0;
    topological_order(loop, looped);
    std::cout << "with a cycle: " << looped << " of " << loop.size()
              << " tasks can be ordered\\n";
    return 0;
}
''', '''order: 0 1 2 3 4 5 (6 of 6 tasks)
with a cycle: 0 of 5 tasks can be ordered'''),
            exp("Where you meet it\n\n"
                "Every build system is a topological sort: make, CMake and npm all resolve "
                "dependencies this way before running anything.\n\n"
                "Package installation, spreadsheet recalculation, task runners and course "
                "prerequisite chains are the same problem. When a cycle appears, the useful "
                "answer is not 'no order exists' but the cycle itself - which is why "
                "production tools report the loop, not just the failure."),
            CHALLENGE,
            code('''#include <iostream>
#include <queue>
#include <vector>

int main() {
    std::vector<std::vector<int>> graph{{}, {0}, {0}, {1, 2}};
    std::vector<int> in_degree(graph.size(), 0);
    for (const auto& edges : graph) {
        for (int target : edges) {
            ++in_degree[static_cast<std::size_t>(target)];
        }
    }
    std::queue<int> ready;
    for (std::size_t v = 0; v < graph.size(); ++v) {
        if (in_degree[v] == 0) {
            ready.push(static_cast<int>(v));
        }
    }
    std::cout << "first task to run is " << ready.front() << "\\n";
    int ordered = 0;
    while (!ready.empty()) {
        int node = ready.front();
        ready.pop();
        ++ordered;
        for (int target : graph[static_cast<std::size_t>(node)]) {
            if (--in_degree[static_cast<std::size_t>(target)] == 0) {
                ready.push(target);
            }
        }
    }
    std::cout << "ordered " << ordered << " tasks, last is 3\\n";
    return 0;
}
''', '''first task to run is 3
ordered 4 tasks, last is 3'''),
            quiz("How does Kahn's algorithm detect a cycle?",
                 ["By counting edges", "When fewer vertices are emitted than exist, the rest "
                  "are in a cycle", "By running DFS first", "It cannot detect cycles"],
                 1, "Vertices inside a cycle never lose all their incoming edges, so they are "
                    "never queued."),
           ]),

    lesson("94006", 94, "Graphs", "Union-Find and Kruskal's Tree",
           "Which set is this in, and merging sets in almost constant time.",
           ["Find and unite sets with path compression.",
            "Build a minimum spanning tree with Kruskal.",
            "Say what a spanning tree is."],
           [exp("Grouping, cheaply\n\n"
                "Union-find answers one question fast: are these two things in the same "
                "group? Each set has a representative, find returns it by walking to the "
                "root, and unite points one root at the other.\n\n"
                "Two refinements make it almost constant time: union by size keeps the trees "
                "shallow, and path compression makes every node on a walk point straight at "
                "the root.\n\n"
                "Kruskal's algorithm uses exactly this. Sort the edges by weight, take each "
                "one if it joins two different sets, and skip it if it would make a cycle. "
                "What you get is a minimum spanning tree: the cheapest set of edges that "
                "connects every vertex."),
            dfn("Minimum spanning tree", "The subset of edges with the smallest total weight "
                                         "that still connects every vertex of a connected "
                                         "graph."),
            exp("Five vertices, seven edges\n\n"
                "The edges are sorted and offered one at a time. Four are taken, giving a total "
                "of 11, and three are rejected - each one because its endpoints are already "
                "connected through what has been taken so far.\n\n"
                "That rejection is the whole trick, and it needs union-find to be cheap."),
            code('''#include <algorithm>
#include <iostream>
#include <numeric>
#include <vector>

class DisjointSet {
public:
    explicit DisjointSet(int count) : parent_(static_cast<std::size_t>(count)),
                                      size_(static_cast<std::size_t>(count), 1) {
        std::iota(parent_.begin(), parent_.end(), 0);
    }

    int find(int node) {
        while (parent_[static_cast<std::size_t>(node)] != node) {
            parent_[static_cast<std::size_t>(node)] =
                parent_[static_cast<std::size_t>(parent_[static_cast<std::size_t>(node)])];
            node = parent_[static_cast<std::size_t>(node)];
        }
        return node;
    }

    bool unite(int a, int b) {
        int root_a = find(a);
        int root_b = find(b);
        if (root_a == root_b) {
            return false;
        }
        if (size_[static_cast<std::size_t>(root_a)] <
            size_[static_cast<std::size_t>(root_b)]) {
            std::swap(root_a, root_b);
        }
        parent_[static_cast<std::size_t>(root_b)] = root_a;
        size_[static_cast<std::size_t>(root_a)] += size_[static_cast<std::size_t>(root_b)];
        return true;
    }
private:
    std::vector<int> parent_;
    std::vector<int> size_;
};

struct Edge {
    int weight;
    int from;
    int to;
};

int main() {
    std::vector<Edge> edges{{1, 0, 1}, {2, 2, 3}, {3, 1, 2}, {4, 0, 3},
                            {5, 3, 4}, {6, 1, 4}, {9, 0, 4}};
    std::sort(edges.begin(), edges.end(), [](const Edge& a, const Edge& b) {
        return a.weight < b.weight;
    });

    DisjointSet sets(5);
    int total = 0;
    int chosen = 0;
    for (const Edge& edge : edges) {
        if (sets.unite(edge.from, edge.to)) {
            total += edge.weight;
            ++chosen;
            std::cout << "take " << edge.from << "-" << edge.to << " weight " << edge.weight
                      << "\\n";
        } else {
            std::cout << "skip " << edge.from << "-" << edge.to << " weight " << edge.weight
                      << " (would close a loop)\\n";
        }
    }
    std::cout << "spanning tree uses " << chosen << " edges, total weight " << total << "\\n";
    return 0;
}
''', '''take 0-1 weight 1
take 2-3 weight 2
take 1-2 weight 3
skip 0-3 weight 4 (would close a loop)
take 3-4 weight 5
skip 1-4 weight 6 (would close a loop)
skip 0-4 weight 9 (would close a loop)
spanning tree uses 4 edges, total weight 11'''),
            exp("Where union-find shows up alone\n\n"
                "Image processing uses it to label connected regions. Compilers use it to "
                "merge type equivalences. Network tools use it to decide whether two hosts "
                "are already connected.\n\n"
                "The structure is worth remembering on its own: a few lines, near-constant "
                "operations, and it replaces a lot of hand-written graph walking."),
            CHALLENGE,
            code('''#include <iostream>
#include <numeric>
#include <vector>

int main() {
    std::vector<int> parent(5);
    std::iota(parent.begin(), parent.end(), 0);
    auto find = [&parent](int node) {
        while (parent[static_cast<std::size_t>(node)] != node) {
            node = parent[static_cast<std::size_t>(node)];
        }
        return node;
    };
    auto unite = [&parent, &find](int a, int b) {
        int root_a = find(a);
        int root_b = find(b);
        if (root_a == root_b) {
            return false;
        }
        parent[static_cast<std::size_t>(root_b)] = root_a;
        return true;
    };

    std::cout << std::boolalpha;
    std::cout << "0 and 1 joined: " << unite(0, 1) << "\\n";
    std::cout << "1 and 2 joined: " << unite(1, 2) << "\\n";
    std::cout << "0 and 2 joined: " << unite(0, 2) << " (already together)\\n";
    std::cout << "same set: " << (find(0) == find(2)) << "\\n";
    std::cout << "3 in that set: " << (find(3) == find(0)) << "\\n";
    return 0;
}
''', '''0 and 1 joined: true
1 and 2 joined: true
0 and 2 joined: false (already together)
same set: true
3 in that set: false'''),
            quiz("Why does Kruskal skip an edge whose ends are already in the same set?",
                 ["Because it is too heavy", "Because adding it would close a cycle, and a "
                  "spanning tree cannot contain one", "Because the tree is full",
                  "Because it is already in the tree"],
                 1, "Union-find reports they are already connected, and a connected pair "
                    "cannot be joined again without making a loop."),
           ]),

    lesson("94007", 94, "Hashing", "Hash Tables and Collision Handling",
           "Turn a key into an index, then deal with the keys that land together.",
           ["Write the smallest hash table with separate chaining.",
            "Explain what a good hash function needs.",
            "Say what causes a hash table's worst case."],
           [exp("One arithmetic step to the value\n\n"
                "A hash table applies a hash function to a key to get a number, takes it "
                "modulo the number of buckets, and looks there. With a good function and a "
                "sensible bucket count, the average number of entries per bucket stays small, "
                "so lookup is effectively constant time.\n\n"
                "Two keys can still land in the same bucket - a collision. Separate chaining "
                "keeps a list per bucket; open addressing stores the entry in the next free "
                "slot instead.\n\n"
                "The worst case is not theoretical: feed every key the same bucket and the "
                "table becomes one list, and lookup becomes linear."),
            dfn("Collision", "Two different keys hashing to the same bucket index, which the "
                             "table must resolve without losing either entry."),
            exp("Chaining, and the bucket sizes\n\n"
                "Seven keys into five buckets, with the bucket sizes printed. The spread here is "
                "poor - four keys share one bucket - and lookup still only ever walks its own "
                "bucket, which is the point of chaining.\n\n"
                "Both std::unordered_map and this hand-written table behave the same way: "
                "the guarantee is average constant time, and the worst case is linear. That "
                "is why the standard requires the container to stay usable, not fast, under "
                "a hostile hash."),
            code('''#include <iostream>
#include <list>
#include <string>
#include <utility>
#include <vector>

class HashTable {
public:
    explicit HashTable(std::size_t buckets) : buckets_(buckets) {}

    void put(const std::string& key, int value) {
        for (auto& entry : buckets_[bucket_of(key)]) {
            if (entry.first == key) {
                entry.second = value;
                return;
            }
        }
        buckets_[bucket_of(key)].push_back({key, value});
    }

    bool get(const std::string& key, int& out) const {
        for (const auto& entry : buckets_[bucket_of(key)]) {
            if (entry.first == key) {
                out = entry.second;
                return true;
            }
        }
        return false;
    }

    void report() const {
        for (std::size_t i = 0; i < buckets_.size(); ++i) {
            std::cout << "bucket " << i << " holds " << buckets_[i].size() << "\\n";
        }
    }
private:
    std::size_t bucket_of(const std::string& key) const {
        std::size_t total = 0;
        for (char letter : key) {
            total = total * 31 + static_cast<unsigned char>(letter);
        }
        return total % buckets_.size();
    }
    std::vector<std::list<std::pair<std::string, int>>> buckets_;
};

int main() {
    HashTable table(5);
    for (const auto& entry : {std::pair<std::string, int>{"ada", 36},
                              {"bo", 41}, {"cy", 29}, {"dee", 33},
                              {"eve", 27}, {"fay", 45}, {"gus", 38}}) {
        table.put(entry.first, entry.second);
    }
    table.report();
    int age = 0;
    std::cout << "lookup bo found: " << (table.get("bo", age) ? "yes" : "no")
              << " age " << age << "\\n";
    std::cout << "lookup zed found: " << (table.get("zed", age) ? "yes" : "no") << "\\n";
    return 0;
}
''', '''bucket 0 holds 4
bucket 1 holds 0
bucket 2 holds 1
bucket 3 holds 0
bucket 4 holds 2
lookup bo found: yes age 41
lookup zed found: no'''),
            exp("What makes a hash function good\n\n"
                "It must be deterministic, spread keys evenly, and be fast. Multiplying by a "
                "prime (31 above) and mixing in every byte is the classic recipe; the "
                "standard library goes much further for strings and integers.\n\n"
                "It must also never depend on memory addresses for value types, or the same "
                "value would hash differently on two runs - a favourite source of "
                "'works in debug, fails in release'."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <unordered_map>

int main() {
    std::unordered_map<std::string, int> stock;
    stock["bolt"] = 40;
    stock["nut"] = 55;
    stock["washer"] = 12;
    stock["bolt"] = 45;

    std::cout << "entries " << stock.size() << "\\n";
    std::cout << "bolt count " << stock.at("bolt") << "\\n";
    std::cout << "screw present: " << (stock.count("screw") != 0 ? "yes" : "no") << "\\n";
    int total = 0;
    for (const auto& entry : stock) {
        total += entry.second;
    }
    std::cout << "total stock " << total << "\\n";
    return 0;
}
''', '''entries 3
bolt count 45
screw present: no
total stock 112'''),
            quiz("What is a hash table's worst-case lookup cost, and why?",
                 ["Constant, always", "Linear, when many keys land in the same bucket",
                  "Logarithmic", "It cannot be worse than constant"],
                 1, "The average is constant by design; an even distribution is an assumption, "
                    "not a guarantee."),
           ]),

    lesson("94008", 94, "Complexity", "Big O, Big Theta and What They Do Not Tell You",
           "Count the work instead of timing it, and read the result honestly.",
           ["Count operations and compare growth rates.",
            "Say the difference between O, Theta and Omega.",
            "Explain what Big O leaves out."],
           [exp("Comparing shapes, not seconds\n\n"
                "Big O describes how the work grows as the input grows, ignoring constants. "
                "Linear search touches every element, so its cost is proportional to n; "
                "binary search halves the range each step, so its cost is proportional to "
                "log2(n).\n\n"
                "The other two letters say different things: Omega is a lower bound on "
                "growth, Theta is both bounds at once - the tight description. In everyday "
                "speech people say Big O and mean Theta.\n\n"
                "What it hides matters: constants, cache behaviour and allocation. An O(n) "
                "loop over contiguous memory can beat an O(log n) tree lookup on real "
                "hardware, because the tree jumps all over memory."),
            dfn("Big O", "An upper bound on how an algorithm's cost grows with input size, "
                         "ignoring constant factors and smaller terms."),
            exp("Counting steps, not seconds\n\n"
                "The program counts comparisons for linear and binary search on the same "
                "sorted ranges. The numbers are deterministic, unlike a timer, and the "
                "difference in growth is visible: linear search's count rises with n, binary "
                "search's barely moves.\n\n"
                "That is exactly why Big O is worth learning, and exactly why a stopwatch is "
                "worth distrusting for small inputs."),
            code('''#include <iostream>
#include <vector>

int linear_steps(const std::vector<int>& data, int target) {
    int steps = 0;
    for (int value : data) {
        ++steps;
        if (value == target) {
            return steps;
        }
    }
    return steps;
}

int binary_steps(const std::vector<int>& data, int target) {
    std::size_t low = 0;
    std::size_t high = data.size();
    int steps = 0;
    while (low < high) {
        ++steps;
        std::size_t middle = low + (high - low) / 2;
        if (data[middle] == target) {
            return steps;
        }
        if (data[middle] < target) {
            low = middle + 1;
        } else {
            high = middle;
        }
    }
    return steps;
}

int main() {
    for (std::size_t count : {100u, 1000u, 100000u}) {
        std::vector<int> data(count);
        for (std::size_t i = 0; i < count; ++i) {
            data[i] = static_cast<int>(i * 2);
        }
        int target = static_cast<int>(count * 2) - 1;
        std::cout << count << " values: linear " << linear_steps(data, target)
                  << " steps, binary " << binary_steps(data, target) << " steps\\n";
    }
    return 0;
}
''', '''100 values: linear 100 steps, binary 6 steps
1000 values: linear 1000 steps, binary 9 steps
100000 values: linear 100000 steps, binary 16 steps'''),
            exp("Reading a complexity table with suspicion\n\n"
                "std::vector push_back is amortised constant, so a million pushes are "
                "roughly a million steps - except the few that copy everything, which is why "
                "'amortised' is in the sentence.\n\n"
                "std::map lookup is logarithmic in steps but each step may be a cache miss; "
                "a sorted vector's binary search is logarithmic in steps and each step is "
                "next to the previous one. The table describes the step count, not the time."),
            CHALLENGE,
            code('''#include <cmath>
#include <iostream>

int main() {
    std::cout << "n      n^2      n log2 n   log2 n\\n";
    for (int n : {10, 100, 1000}) {
        double logn = std::log2(static_cast<double>(n));
        std::cout << n << "    " << n * n << "    " << static_cast<long>(n * logn) << "      "
                  << static_cast<int>(logn) << "\\n";
    }
    return 0;
}
''', '''n      n^2      n log2 n   log2 n
10    100    33      3
100    10000    664      6
1000    1000000    9965      9'''),
            quiz("An algorithm is O(n) and another is O(log n). When can the O(n) one be faster?",
                 ["Never", "When the constant factor and memory access pattern favour it, "
                  "especially on small inputs", "When n is large", "Only on graphics cards"],
                 1, "Big O compares growth, not speed: a contiguous pass over a small array "
                    "beats pointer-chasing every time."),
           ]),

    lesson("94009", 94, "Recursion", "Recursion, Backtracking and Divide and Conquer",
           "Three uses of the same idea: trust the smaller problem.",
           ["Write a recursive function with a base case and a smaller call.",
            "Use backtracking to explore and undo.",
            "Split a problem in half and combine the answers."],
           [exp("Trust the smaller call\n\n"
                "A recursive function handles the smallest case directly and otherwise calls "
                "itself on something smaller. Every correct recursion has both parts; without "
                "a base case it does not stop, and without a smaller argument it does not "
                "progress.\n\n"
                "Backtracking is recursion with a choice and an undo: set the choice, recurse, "
                "then unset it so the next branch starts clean. That is how puzzles, "
                "permutations and path finding are written.\n\n"
                "Divide and conquer is recursion that splits the input in two and combines "
                "two answers, which is where merge sort and binary search come from."),
            dfn("Backtracking", "Recursion that makes a choice, explores it, and then undoes "
                                "it before trying the next - so every branch starts from the "
                                "same state."),
            exp("Counting solutions instead of printing them\n\n"
                "The first function counts ways to climb stairs taking one or two steps at a "
                "time - two recursive calls, and the count is the sum.\n\n"
                "The second places n queens on an n-by-4 board, tracking which columns are "
                "already taken, and counts the arrangements. The undo is the line that sets "
                "the column back to false, and without it the count collapses to zero."),
            code('''#include <iostream>
#include <vector>

long climb(int steps) {
    if (steps <= 0) {
        return steps == 0 ? 1 : 0;
    }
    return climb(steps - 1) + climb(steps - 2);
}

long queens(int row, int width, std::vector<bool>& used_column) {
    if (row == width) {
        return 1;
    }
    long total = 0;
    for (int column = 0; column < width; ++column) {
        if (used_column[static_cast<std::size_t>(column)]) {
            continue;
        }
        used_column[static_cast<std::size_t>(column)] = true;
        total += queens(row + 1, width, used_column);
        used_column[static_cast<std::size_t>(column)] = false;
    }
    return total;
}

int main() {
    std::cout << "5 stairs take " << climb(5) << " routes\\n";
    std::cout << "8 stairs take " << climb(8) << " routes\\n";

    std::vector<bool> used(4, false);
    std::cout << "rooks on a 4 by 4 board: " << queens(0, 4, used) << " arrangements\\n";
    std::vector<bool> used_five(5, false);
    std::cout << "rooks on a 5 by 5 board: " << queens(0, 5, used_five)
              << " arrangements\\n";
    return 0;
}
''', '''5 stairs take 8 routes
8 stairs take 34 routes
rooks on a 4 by 4 board: 24 arrangements
rooks on a 5 by 5 board: 120 arrangements'''),
            exp("Why the naive version is slow\n\n"
                "climb(30) calls itself about a million times to compute a number a loop "
                "could reach in thirty additions, because the same values are recomputed "
                "again and again.\n\n"
                "That repetition is exactly what the next lesson fixes: remember the answer "
                "and the call tree collapses. Recognising this shape is the difference "
                "between a program that finishes and one that hangs."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

int sum(const std::vector<int>& data, std::size_t from, std::size_t to) {
    if (to - from == 1) {
        return data[from];
    }
    std::size_t middle = from + (to - from) / 2;
    return sum(data, from, middle) + sum(data, middle, to);
}

int maximum(const std::vector<int>& data, std::size_t from, std::size_t to) {
    if (to - from == 1) {
        return data[from];
    }
    std::size_t middle = from + (to - from) / 2;
    int left = maximum(data, from, middle);
    int right = maximum(data, middle, to);
    return left > right ? left : right;
}

int main() {
    std::vector<int> data{3, 8, 1, 9, 4, 7};
    std::cout << "sum " << sum(data, 0, data.size()) << "\\n";
    std::cout << "maximum " << maximum(data, 0, data.size()) << "\\n";
    return 0;
}
''', '''sum 32
maximum 9'''),
            quiz("What is the role of the undo step in backtracking?",
                 ["It makes the code faster", "It restores the state so the next branch "
                  "starts clean", "It is optional decoration", "It frees memory"],
                 1, "Without undoing the choice, later branches inherit it and the search "
                    "explores the wrong space."),
           ]),
]
