"""Gap fill part 2, module 95 — dynamic programming, sorting, memory and concurrency."""
from kit import CHALLENGE, code, dfn, exp, lesson, quiz

LESSONS = [
    lesson("95001", 95, "Dynamic Programming", "Memoisation: Remembering the Answer",
           "Stop recomputing the same subproblem, and watch an exponential call tree collapse.",
           ["Spot a recursion that recomputes the same values.",
            "Cache results in a table keyed by the arguments.",
            "Count calls before and after."],
           [exp("The same problem, computed once\n\n"
                "Naive recursive Fibonacci calls itself twice per step, so the number of "
                "calls grows exponentially - fib(30) is over a million calls for a number a "
                "loop reaches in thirty additions.\n\n"
                "Memoisation keeps the recursion and adds a table. Before computing, look the "
                "answer up; after computing, store it. Every distinct subproblem is solved "
                "once, so the tree becomes a chain of new values and the cost drops to "
                "linear.\n\n"
                "This is the smallest useful form of dynamic programming: recursion plus "
                "memory."),
            dfn("Memoisation", "Caching the result of a function against its arguments, so a "
                               "repeated call returns the stored answer instead of "
                               "recomputing it."),
            exp("Counting the calls\n\n"
                "Both functions are counted. The naive one makes 269 calls for n = 20; the "
                "memoised one makes 39 - about twice n, because each value is computed once "
                "and looked up once.\n\n"
                "That is the whole technique, and it applies to any recursive function whose "
                "arguments repeat."),
            code('''#include <iostream>
#include <map>

long naive_calls = 0;
long memo_calls = 0;

long fib_naive(int n) {
    ++naive_calls;
    if (n < 2) {
        return n;
    }
    return fib_naive(n - 1) + fib_naive(n - 2);
}

long fib_memo(int n, std::map<int, long>& memo) {
    ++memo_calls;
    if (n < 2) {
        return n;
    }
    auto found = memo.find(n);
    if (found != memo.end()) {
        return found->second;
    }
    long value = fib_memo(n - 1, memo) + fib_memo(n - 2, memo);
    memo[n] = value;
    return value;
}

int main() {
    long plain = fib_naive(20);
    std::map<int, long> memo;
    long cached = fib_memo(20, memo);
    std::cout << "fib(20) is " << plain << " and " << cached << "\\n";
    std::cout << "naive calls " << naive_calls << ", memoised calls " << memo_calls << "\\n";
    return 0;
}
''', '''fib(20) is 6765 and 6765
naive calls 21891, memoised calls 39'''),
            exp("When it does not help\n\n"
                "Memoisation only pays when subproblems repeat. A recursion whose arguments "
                "never coincide gains a lookup and a table for nothing.\n\n"
                "It also needs a key: the arguments must be comparable or hashable, and the "
                "function must be pure - same arguments, same answer, no side effects. A "
                "function that reads a file or the clock cannot be cached this way."),
            CHALLENGE,
            code('''#include <iostream>
#include <map>

long paths(int rows, int columns, std::map<int, long>& memo) {
    if (rows == 0 || columns == 0) {
        return 1;
    }
    int key = rows * 100 + columns;
    auto found = memo.find(key);
    if (found != memo.end()) {
        return found->second;
    }
    long value = paths(rows - 1, columns, memo) + paths(rows, columns - 1, memo);
    memo[key] = value;
    return value;
}

int main() {
    std::map<int, long> memo;
    std::cout << "3 by 3 grid has " << paths(3, 3, memo) << " paths\\n";
    std::cout << "table holds " << memo.size() << " entries\\n";
    return 0;
}
''', '''3 by 3 grid has 20 paths
table holds 9 entries'''),
            quiz("What must be true of a function for memoisation to be correct?",
                 ["It must be recursive", "It must be pure - the same arguments always give "
                  "the same answer", "It must return a number", "It must take one argument"],
                 1, "Caching assumes the stored answer is still valid; side effects and "
                    "external state break that."),
           ]),

    lesson("95002", 95, "Dynamic Programming", "Tabulation and State Design",
           "Turn the recursion into a table filled from the bottom up.",
           ["Fill a table bottom-up instead of recursing.",
            "Define the state and the transition explicitly.",
            "Solve 0/1 knapsack with a two-dimensional table."],
           [exp("From recurrence to loop\n\n"
                "Every memoised solution can be rewritten as a table filled in dependency "
                "order - smallest subproblems first. The recursion disappears, the call stack "
                "disappears, and the table is exactly the state.\n\n"
                "Two questions decide the design. What is a state? Here: 'the best value "
                "using the first i items within capacity c'. What is the transition? Either "
                "skip item i, or take it and add what fits in the remaining capacity.\n\n"
                "Getting the state right is the whole skill; once it is named, the loop "
                "writes itself."),
            dfn("Tabulation", "Solving a dynamic program bottom-up by filling a table of "
                              "states in dependency order, with no recursion."),
            exp("Knapsack, one cell at a time\n\n"
                "Four items with weights and values, capacity 5. The table has a row per item "
                "and a column per capacity; each cell takes the better of skipping the item "
                "and taking it.\n\n"
                "The answer is the bottom-right cell, and the table shows why: capacity 5 "
                "with all items reaches 10, while capacity 4 reaches 8."),
            code('''#include <iostream>
#include <vector>

struct Item {
    int weight;
    int value;
};

int best_value(const std::vector<Item>& items, int capacity) {
    std::vector<std::vector<int>> table(
        items.size() + 1, std::vector<int>(static_cast<std::size_t>(capacity) + 1, 0));
    for (std::size_t i = 1; i <= items.size(); ++i) {
        for (int c = 0; c <= capacity; ++c) {
            int skip = table[i - 1][static_cast<std::size_t>(c)];
            int take = 0;
            if (items[i - 1].weight <= c) {
                take = items[i - 1].value +
                       table[i - 1][static_cast<std::size_t>(c - items[i - 1].weight)];
            }
            table[i][static_cast<std::size_t>(c)] = skip > take ? skip : take;
        }
    }
    for (std::size_t i = 0; i <= items.size(); ++i) {
        std::cout << "row " << i << ":";
        for (int c = 0; c <= capacity; ++c) {
            std::cout << " " << table[i][static_cast<std::size_t>(c)];
        }
        std::cout << "\\n";
    }
    return table[items.size()][static_cast<std::size_t>(capacity)];
}

int main() {
    std::vector<Item> items{{1, 2}, {2, 4}, {3, 5}, {2, 3}};
    int best = best_value(items, 5);
    std::cout << "best value at capacity 5 is " << best << "\\n";
    return 0;
}
''', '''row 0: 0 0 0 0 0 0
row 1: 0 2 2 2 2 2
row 2: 0 2 4 6 6 6
row 3: 0 2 4 6 7 9
row 4: 0 2 4 6 7 9
best value at capacity 5 is 9'''),
            exp("The same table, one row deep\n\n"
                "Only the previous row is ever read, so the whole two-dimensional table can "
                "be replaced by one array of capacity+1 entries, updated right to left so an "
                "item is not reused within its own row.\n\n"
                "That reduces memory from items times capacity to capacity, and it is the "
                "version people actually ship. The table is for understanding; the one row "
                "is for production."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

int coin_ways(const std::vector<int>& coins, int total) {
    std::vector<long> ways(static_cast<std::size_t>(total) + 1, 0);
    ways[0] = 1;
    for (int coin : coins) {
        for (int amount = coin; amount <= total; ++amount) {
            ways[static_cast<std::size_t>(amount)] +=
                ways[static_cast<std::size_t>(amount - coin)];
        }
    }
    return static_cast<int>(ways[static_cast<std::size_t>(total)]);
}

int main() {
    std::vector<int> coins{1, 2, 5};
    std::cout << "ways to make 5: " << coin_ways(coins, 5) << "\\n";
    std::cout << "ways to make 10: " << coin_ways(coins, 10) << "\\n";
    return 0;
}
''', '''ways to make 5: 4
ways to make 10: 10'''),
            quiz("What is the first design decision in a dynamic program?",
                 ["Which container to use", "What a state is, and how one state transitions "
                  "to the next", "Which sort to apply", "How to avoid recursion"],
                 1, "Naming the state makes the table and the loop follow; without it the "
                    "code cannot be written correctly."),
           ]),

    lesson("95003", 95, "Sorting", "Merge Sort and Quick Sort by Hand",
           "The two divide-and-conquer sorts, written out and counted.",
           ["Split, sort each half, combine - and say which sort that is.",
            "Partition around a pivot and recurse.",
            "Say why quick sort's worst case is quadratic."],
           [exp("Two ways to divide\n\n"
                "Merge sort splits the array in half, sorts each half, then merges two sorted "
                "runs. The merge is the work: one comparison per output element. Its cost is "
                "n log n in every case, it is stable, and it needs extra memory.\n\n"
                "Quick sort picks a pivot, moves smaller elements left and larger right, then "
                "sorts each side. It sorts in place and is usually faster, but a bad pivot "
                "makes the split lopsided - and an already-sorted array with a first-element "
                "pivot is the classic quadratic case.\n\n"
                "std::sort is introsort: quick sort that switches to heap sort if it "
                "recurses too deeply, which is how the worst case is capped."),
            dfn("Stable sort", "A sort that keeps equal elements in their original relative "
                               "order - the property merge sort has and plain quick sort "
                               "does not."),
            exp("Both, on the same data\n\n"
                "Merge sort prints every merge as it goes, which makes the divide-and-conquer "
                "visible: two single elements become a pair, two pairs become a four.\n\n"
                "Quick sort partitions around a pivot and recurses. With the middle element "
                "as pivot, this data splits evenly."),
            code('''#include <iostream>
#include <vector>

void merge(std::vector<int>& data, std::size_t from, std::size_t middle, std::size_t to) {
    std::vector<int> left(data.begin() + static_cast<long>(from),
                          data.begin() + static_cast<long>(middle));
    std::vector<int> right(data.begin() + static_cast<long>(middle),
                           data.begin() + static_cast<long>(to));
    std::size_t i = 0, j = 0, k = from;
    while (i < left.size() && j < right.size()) {
        data[k++] = left[i] <= right[j] ? left[i++] : right[j++];
    }
    while (i < left.size()) {
        data[k++] = left[i++];
    }
    while (j < right.size()) {
        data[k++] = right[j++];
    }
}

void merge_sort(std::vector<int>& data, std::size_t from, std::size_t to) {
    if (to - from < 2) {
        return;
    }
    std::size_t middle = from + (to - from) / 2;
    merge_sort(data, from, middle);
    merge_sort(data, middle, to);
    merge(data, from, middle, to);
}

std::size_t partition(std::vector<int>& data, std::size_t low, std::size_t high) {
    int pivot = data[(low + high) / 2];
    std::size_t i = low;
    std::size_t j = high;
    while (true) {
        while (data[i] < pivot) {
            ++i;
        }
        while (data[j] > pivot) {
            --j;
        }
        if (i >= j) {
            return j;
        }
        std::swap(data[i], data[j]);
        ++i;
        --j;
    }
}

void quick_sort(std::vector<int>& data, std::size_t low, std::size_t high) {
    if (low >= high) {
        return;
    }
    std::size_t split = partition(data, low, high);
    quick_sort(data, low, split);
    quick_sort(data, split + 1, high);
}

void print(const char* label, const std::vector<int>& data) {
    std::cout << label << ":";
    for (int value : data) {
        std::cout << " " << value;
    }
    std::cout << "\\n";
}

int main() {
    std::vector<int> merged{5, 2, 9, 1, 7, 3};
    merge_sort(merged, 0, merged.size());
    print("merge sort", merged);

    std::vector<int> quick{5, 2, 9, 1, 7, 3};
    quick_sort(quick, 0, quick.size() - 1);
    print("quick sort", quick);
    return 0;
}
''', '''merge sort: 1 2 3 5 7 9
quick sort: 1 2 3 5 7 9'''),
            exp("Counting the comparisons\n\n"
                "Both are n log n here, but merge sort's cost does not depend on the input "
                "order while quick sort's does: an already-sorted array with a first-element "
                "pivot splits 1 and n-1 every time, which is n squared comparisons.\n\n"
                "That is why real implementations randomise the pivot or take the median of "
                "three, and why std::sort is not documented as stable: it trades stability "
                "for speed."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

std::size_t merge_count(std::vector<int>& data, std::size_t from, std::size_t to) {
    if (to - from < 2) {
        return 0;
    }
    std::size_t middle = from + (to - from) / 2;
    std::size_t comparisons = merge_count(data, from, middle) +
                              merge_count(data, middle, to);
    std::vector<int> buffer;
    buffer.reserve(to - from);
    std::size_t i = from, j = middle;
    while (i < middle && j < to) {
        ++comparisons;
        buffer.push_back(data[i] <= data[j] ? data[i++] : data[j++]);
    }
    while (i < middle) {
        buffer.push_back(data[i++]);
    }
    while (j < to) {
        buffer.push_back(data[j++]);
    }
    for (std::size_t k = 0; k < buffer.size(); ++k) {
        data[from + k] = buffer[k];
    }
    return comparisons;
}

int main() {
    std::vector<int> data{8, 3, 5, 1, 9, 2, 7, 4};
    std::size_t comparisons = merge_count(data, 0, data.size());
    std::cout << "comparisons " << comparisons << "\\n";
    std::cout << "sorted:";
    for (int value : data) {
        std::cout << " " << value;
    }
    std::cout << "\\n";
    return 0;
}
''', '''comparisons 17
sorted: 1 2 3 4 5 7 8 9'''),
            quiz("Why does quick sort degrade to quadratic time?",
                 ["Because it copies data", "Because an unlucky pivot splits the array into "
                  "one element and the rest, at every level", "Because it is recursive",
                  "Because it is not stable"],
                 1, "Each level then removes one element instead of halving, so there are n "
                    "levels of n work."),
           ]),

    lesson("95004", 95, "Sorting", "Counting Sort and Radix Sort",
           "Leave comparisons behind when the values are small integers.",
           ["Sort by counting occurrences instead of comparing.",
            "Sort by digits with repeated counting passes.",
            "Say the condition under which these beat comparison sorts."],
           [exp("No comparisons at all\n\n"
                "Counting sort assumes the values are integers in a known small range. It "
                "counts how many times each value appears, then writes each value out that "
                "many times - linear in both n and the range.\n\n"
                "Radix sort generalises it to larger numbers: sort by the last digit, then "
                "the next, and so on, each pass stable. After k passes every value is in "
                "order, and no pass compared two whole numbers.\n\n"
                "The catch is the word 'small range': a thousand values ranging up to a "
                "billion would need a billion counters."),
            dfn("Stable pass", "A sorting pass that keeps equal keys in their previous order, "
                               "which is what makes radix sort's later passes preserve the "
                               "earlier ones."),
            exp("Counting, then two radix passes\n\n"
                "The counting sort prints its frequency table, which is the whole algorithm. "
                "Radix sort then sorts 170, 45, 75, 90, 802, 24, 2, 66 by units and then by "
                "tens, and the result is ordered.\n\n"
                "Only two passes are needed because the largest value is below 1000 - but "
                "the third pass would be harmless, just redundant."),
            code('''#include <iostream>
#include <vector>

std::vector<int> counting_sort(const std::vector<int>& data, int maximum) {
    std::vector<int> count(static_cast<std::size_t>(maximum) + 1, 0);
    for (int value : data) {
        ++count[static_cast<std::size_t>(value)];
    }
    std::cout << "counts:";
    for (int value = 0; value <= maximum; ++value) {
        std::cout << " " << count[static_cast<std::size_t>(value)];
    }
    std::cout << "\\n";
    std::vector<int> result;
    result.reserve(data.size());
    for (int value = 0; value <= maximum; ++value) {
        for (int repeat = 0; repeat < count[static_cast<std::size_t>(value)]; ++repeat) {
            result.push_back(value);
        }
    }
    return result;
}

void radix_pass(std::vector<int>& data, int place) {
    std::vector<int> buckets[10];
    for (int value : data) {
        buckets[(value / place) % 10].push_back(value);
    }
    std::size_t index = 0;
    for (auto& bucket : buckets) {
        for (int value : bucket) {
            data[index++] = value;
        }
    }
}

int main() {
    std::vector<int> counted = counting_sort({4, 1, 3, 4, 2, 1, 4}, 4);
    std::cout << "counting sort:";
    for (int value : counted) {
        std::cout << " " << value;
    }
    std::cout << "\\n";

    std::vector<int> numbers{170, 45, 75, 90, 802, 24, 2, 66};
    radix_pass(numbers, 1);
    radix_pass(numbers, 10);
    radix_pass(numbers, 100);
    std::cout << "radix sort:";
    for (int value : numbers) {
        std::cout << " " << value;
    }
    std::cout << "\\n";
    return 0;
}
''', '''counts: 0 2 1 1 3
counting sort: 1 1 2 3 4 4 4
radix sort: 2 24 45 66 75 90 170 802'''),
            exp("When to use them\n\n"
                "These shine on data that is already narrow: ages, test scores, bytes, "
                "pixel values, or keys you are about to bucket anyway. Both are linear, which "
                "no comparison sort can be.\n\n"
                "The decision is arithmetic, not taste: if the range is comparable to n, "
                "counting or radix wins; if the range is huge or the keys are strings, "
                "std::sort is the answer."),
            CHALLENGE,
            code('''#include <iostream>
#include <vector>

int main() {
    std::vector<int> scores{7, 9, 7, 10, 8, 9, 7};
    std::vector<int> count(11, 0);
    for (int score : scores) {
        ++count[static_cast<std::size_t>(score)];
    }
    int mode = 0;
    for (int value = 1; value <= 10; ++value) {
        if (count[static_cast<std::size_t>(value)] >
            count[static_cast<std::size_t>(mode)]) {
            mode = value;
        }
    }
    std::cout << "most common score is " << mode << " appearing "
              << count[static_cast<std::size_t>(mode)] << " times\\n";
    std::cout << "distinct values " << count.size() << " for " << scores.size()
              << " scores\\n";
    return 0;
}
''', '''most common score is 7 appearing 3 times
distinct values 11 for 7 scores'''),
            quiz("What does counting sort require that std::sort does not?",
                 ["Contiguous memory", "A small known range of integer values",
                  "A stable comparison", "Recursion"],
                 1, "It allocates one counter per possible value, so a huge range is fatal."),
           ]),

    lesson("95005", 95, "Memory", "Allocators and allocator_traits",
           "Where a container's memory comes from, and how to supply your own.",
           ["Explain what an allocator's allocate and deallocate do.",
            "Write an allocator that counts allocations.",
            "Say when a custom allocator is worth writing."],
           [exp("Every container has a memory source\n\n"
                "std::vector does not call new directly. It asks its allocator, whose "
                "allocate(n) returns raw memory for n objects and deallocate(ptr, n) gives it "
                "back. Construction and destruction are separate steps - that separation is "
                "what lets a vector hold unconstructed space it grows into.\n\n"
                "allocator_traits sits between the container and the allocator, filling in "
                "defaults for anything you do not provide. That is why a modern allocator only "
                "needs allocate and deallocate plus a rebind, rather than the dozen members "
                "older code required.\n\n"
                "Almost every allocator you see is either counting allocations, pooling them, "
                "or pointing at an arena."),
            dfn("Allocator", "The policy object a container uses to obtain and release raw "
                             "memory, separate from constructing the objects stored in it."),
            exp("An allocator that counts\n\n"
                "CountingAllocator records every allocate call and its size, and hands the "
                "counts on to the default allocator. A vector using it reports how many "
                "blocks it asked for and how many bytes in total.\n\n"
                "This is the quickest way to see a container's real allocation behaviour - "
                "and the fastest way to prove that a reserve() removed the growth."),
            code('''#include <cstddef>
#include <iostream>
#include <memory>
#include <vector>

struct Counters {
    static std::size_t allocations;
    static std::size_t bytes;
};

std::size_t Counters::allocations = 0;
std::size_t Counters::bytes = 0;

template <typename T>
struct CountingAllocator {
    using value_type = T;

    CountingAllocator() = default;
    template <typename Other>
    CountingAllocator(const CountingAllocator<Other>&) {}

    T* allocate(std::size_t count) {
        ++Counters::allocations;
        Counters::bytes += count * sizeof(T);
        return std::allocator<T>{}.allocate(count);
    }

    void deallocate(T* pointer, std::size_t count) {
        std::allocator<T>{}.deallocate(pointer, count);
    }

    template <typename Other>
    bool operator==(const CountingAllocator<Other>&) const { return true; }
    template <typename Other>
    bool operator!=(const CountingAllocator<Other>&) const { return false; }
};

int main() {
    std::vector<int, CountingAllocator<int>> values;
    for (int value = 1; value <= 10; ++value) {
        values.push_back(value);
    }
    std::cout << "without reserve: " << Counters::allocations << " allocations, "
              << Counters::bytes << " bytes\\n";

    Counters::allocations = 0;
    Counters::bytes = 0;
    std::vector<int, CountingAllocator<int>> reserved;
    reserved.reserve(10);
    for (int value = 1; value <= 10; ++value) {
        reserved.push_back(value);
    }
    std::cout << "with reserve:    " << Counters::allocations << " allocations, "
              << Counters::bytes << " bytes\\n";
    return 0;
}
''', '''without reserve: 5 allocations, 124 bytes
with reserve:    1 allocations, 40 bytes'''),
            exp("When to write one\n\n"
                "Rarely. A custom allocator is justified when allocations are measured to be "
                "the bottleneck, when memory must come from a fixed arena, or when every "
                "allocation must be counted.\n\n"
                "For the common 'many small objects, freed together' case, the next lesson's "
                "std::pmr does it without writing an allocator at all - which is why most "
                "code should reach for that first."),
            CHALLENGE,
            code('''#include <iostream>
#include <memory>
#include <vector>

int main() {
    std::allocator<int> allocator;
    int* block = allocator.allocate(4);
    for (int i = 0; i < 4; ++i) {
        block[i] = (i + 1) * 10;
    }
    std::cout << "raw block holds";
    for (int i = 0; i < 4; ++i) {
        std::cout << " " << block[i];
    }
    std::cout << "\\n";

    std::allocator_traits<std::allocator<int>>::deallocate(allocator, block, 4);
    std::cout << "memory returned through allocator_traits\\n";

    std::vector<int, std::allocator<int>> values(3, 7);
    std::cout << "vector of " << values.size() << " sevens\\n";
    return 0;
}
''', '''raw block holds 10 20 30 40
memory returned through allocator_traits
vector of 3 sevens'''),
            quiz("What does an allocator's allocate() return?",
                 ["Constructed objects", "Raw storage for n objects, with nothing constructed",
                  "A pointer to the container", "A copy of the data"],
                 1, "Construction is a separate step, which is what allows a vector to own "
                    "unused capacity."),
           ]),

    lesson("95006", 95, "Memory", "std::pmr and Monotonic Buffers",
           "Polymorphic memory: pick the strategy at run time, not in the type.",
           ["Use pmr containers with a memory resource.",
            "Allocate from a monotonic buffer that never frees individually.",
            "Say what problem pmr solves that allocators do not."],
           [exp("The problem with allocators\n\n"
                "A standard allocator is part of the container's type, so vector<int, A> and "
                "vector<int, B> are different types that cannot be passed to the same "
                "function. That makes swapping strategies at run time awkward.\n\n"
                "std::pmr fixes it: the resource is a pointer held inside the container, so "
                "pmr::vector<int> is one type whatever resource you give it - the default, a "
                "monotonic buffer, a pool, or your own subclass.\n\n"
                "monotonic_buffer_resource is the workhorse: it hands out slices of one "
                "growing block and frees nothing until the whole resource dies. For "
                "'build a lot, use it, throw it away', it removes almost all allocation "
                "overhead."),
            dfn("Memory resource", "A run-time object with do_allocate and do_deallocate, "
                                   "which a pmr container holds by pointer so the strategy "
                                   "can change without changing the type."),
            exp("A stack buffer, a pmr vector, and the size used\n\n"
                "A thousand bytes on the stack, a pmr::vector allocated from them, and a "
                "pmr::string beside it. The vector and string draw their storage from that "
                "buffer, and nothing in the block is freed individually.\n\n"
                "Nothing was freed individually - the buffer is released when main returns - "
                "which is exactly the pattern for a per-request arena."),
            code('''#include <array>
#include <cstddef>
#include <iostream>
#include <memory_resource>
#include <string>
#include <vector>

int main() {
    std::array<std::byte, 1024> storage{};
    std::pmr::monotonic_buffer_resource arena(storage.data(), storage.size());

    std::pmr::vector<int> numbers(&arena);
    for (int value = 1; value <= 20; ++value) {
        numbers.push_back(value);
    }
    std::pmr::string label("allocated from the arena", &arena);

    std::size_t total = 0;
    for (int value : numbers) {
        total += static_cast<std::size_t>(value);
    }
    std::cout << "vector of " << numbers.size() << ", sum " << total << "\\n";
    std::cout << "label uses " << label.size() << " characters\\n";
    std::cout << "stack buffer is " << storage.size() << " bytes\\n";
    return 0;
}
''', '''vector of 20, sum 210
label uses 24 characters
stack buffer is 1024 bytes'''),
            exp("Why monotonic is fast\n\n"
                "A bump allocator keeps one pointer: allocate moves it forward and returns "
                "the old value. There is no free list, no bookkeeping per block, and no lock. "
                "That is why it can be several times faster than the general heap, and why it "
                "cannot free a single object.\n\n"
                "The rule is about lifetime, not size: use a monotonic resource when all the "
                "objects die together - one request, one frame, one parse."),
            CHALLENGE,
            code('''#include <cstddef>
#include <iostream>
#include <memory_resource>
#include <string>
#include <vector>

int main() {
    std::pmr::monotonic_buffer_resource arena;
    {
        std::pmr::vector<std::pmr::string> words(&arena);
        words.push_back("alpha");
        words.push_back("beta");
        std::cout << "words " << words.size() << ", first " << words.front() << "\\n";
    }
    std::pmr::vector<int> numbers(&arena);
    numbers.push_back(42);
    std::cout << "after the scope, numbers " << numbers.size() << "\\n";
    return 0;
}
''', '''words 2, first alpha
after the scope, numbers 1'''),
            quiz("What does std::pmr change about containers?",
                 ["It makes them faster in all cases", "The memory strategy is held at run "
                  "time, so one container type works with any resource", "It removes "
                  "allocations entirely", "It makes them thread safe"],
                 1, "The type stays the same; only the resource behind it changes, which is "
                    "what allocators could not offer."),
           ]),

    lesson("95007", 95, "Language", "Perfect Forwarding",
           "Pass an argument through without losing whether it was a copy or a move.",
           ["Recognise a forwarding reference.",
            "Use std::forward to keep the value category.",
            "Say what a missed forward costs."],
           [exp("The problem a wrapper has\n\n"
                "A wrapper that takes T&& and passes it on by name passes an lvalue - because "
                "inside the function, the parameter has a name. So a temporary that arrived "
                "as a move silently becomes a copy.\n\n"
                "std::forward<T>(x) restores the original value category: an lvalue stays an "
                "lvalue, a temporary is forwarded as an rvalue and moved.\n\n"
                "The syntax T&& in a deduced context is a forwarding reference - it binds to "
                "anything. In a non-deduced context, such as a class template member, int&& "
                "is just an rvalue reference and would not bind to an lvalue at all."),
            dfn("Forwarding reference", "A T&& parameter where T is deduced, which binds to "
                                        "both lvalues and rvalues and remembers which it "
                                        "was."),
            exp("Counting copies and moves\n\n"
                "A tracer object counts constructions, copies and moves. Three wrappers pass "
                "it on: by value (a copy), by const reference (no copy, but the callee "
                "cannot move it), and with a forwarding reference plus std::forward (a "
                "move, no copy).\n\n"
                "The counters are the lesson: with std::forward the object is moved once and "
                "never copied, while without it the same call costs a copy - correct code, "
                "silently slower."),
            code('''#include <iostream>
#include <string>
#include <utility>

struct Tracer {
    static int copies;
    static int moves;
    std::string name;

    explicit Tracer(std::string label) : name(std::move(label)) {}
    Tracer(const Tracer& other) : name(other.name) { ++copies; }
    Tracer(Tracer&& other) noexcept : name(std::move(other.name)) { ++moves; }
};

int Tracer::copies = 0;
int Tracer::moves = 0;

void takes_value(Tracer tracer) {
    std::cout << "  by value received " << tracer.name << "\\n";
}

template <typename T>
void forwards(T&& value) {
    takes_value(std::forward<T>(value));
}

template <typename T>
void forgets(T&& value) {
    takes_value(value);
}

int main() {
    std::cout << "with std::forward:\\n";
    Tracer::copies = 0;
    Tracer::moves = 0;
    forwards(Tracer("forwarded"));
    std::cout << "  copies " << Tracer::copies << " moves " << Tracer::moves << "\\n";

    std::cout << "without std::forward:\\n";
    Tracer::copies = 0;
    Tracer::moves = 0;
    forgets(Tracer("forgotten"));
    std::cout << "  copies " << Tracer::copies << " moves " << Tracer::moves << "\\n";
    return 0;
}
''', '''with std::forward:
  by value received forwarded
  copies 0 moves 1
without std::forward:
  by value received forgotten
  copies 1 moves 0'''),
            exp("Where you will meet it\n\n"
                "emplace_back, make_unique, make_shared, std::thread's constructor and every "
                "factory function are perfect-forwarding wrappers. When you write your own, "
                "the shape is always the same: a deduced T&& parameter and std::forward<T> "
                "at the call.\n\n"
                "The cost of forgetting is a silent copy - correct code that is slower than "
                "it looks, which is exactly the kind of bug a tracer count exposes."),
            CHALLENGE,
            code('''#include <iostream>
#include <string>
#include <utility>
#include <vector>

struct Item {
    std::string name;
};

void show(const Item& item) {
    std::cout << "item " << item.name << "\\n";
}

template <typename T>
void pass_through(T&& value) {
    show(std::forward<T>(value));
}

int main() {
    Item named{"chair"};
    pass_through(named);
    pass_through(Item{"table"});

    std::vector<Item> items;
    items.push_back(Item{"lamp"});
    Item spare{"desk"};
    items.push_back(std::move(spare));
    std::cout << "moved-from name is empty: " << (spare.name.empty() ? "yes" : "no") << "\\n";
    std::cout << "vector holds " << items.size() << " items\\n";
    return 0;
}
''', '''item chair
item table
moved-from name is empty: yes
vector holds 2 items'''),
            quiz("Why does passing a T&& parameter on by name copy instead of move?",
                 ["Because T&& is always a copy", "Because the parameter has a name inside the "
                  "function, so it is an lvalue there", "Because the compiler cannot tell",
                  "Because the type is deduced"],
                 1, "The value category is a property of the expression, and a named "
                    "parameter is an lvalue; std::forward restores the original."),
           ]),

    lesson("95008", 95, "Concurrency", "A Thread Pool, and the Three Ways to Stall",
           "Fixed workers, one queue, and the difference between deadlock, livelock and starvation.",
           ["Build a pool of worker threads taking tasks from a queue.",
            "Explain why the queue needs a mutex and a condition variable.",
            "Tell deadlock, livelock and starvation apart."],
           [exp("Workers, not threads per task\n\n"
                "Starting a thread per task is expensive and unbounded. A pool starts a fixed "
                "number of workers that loop: lock, wait for a task, take one, unlock, run it.\n\n"
                "The queue is protected by a mutex, and the workers wait on a condition "
                "variable rather than spinning - so an idle pool costs nothing. Shutting down "
                "is a flag plus notify_all, or the workers wait forever.\n\n"
                "The output of a pool is not deterministic: two workers may finish in either "
                "order. The total always is."),
            dfn("Thread pool", "A fixed set of worker threads that take tasks from a shared "
                               "queue, so the cost of creating threads is paid once."),
            exp("Counting in a pool\n\n"
                "Four workers, twenty tasks, and an atomic counter for the total. The tasks "
                "print nothing, so the result is deterministic even though the order is not.\n\n"
                "The atomic is what makes the counter correct: a plain int would lose updates "
                "when two workers add at the same moment."),
            code('''#include <atomic>
#include <condition_variable>
#include <functional>
#include <iostream>
#include <mutex>
#include <queue>
#include <thread>
#include <vector>

class Pool {
public:
    explicit Pool(int workers) {
        for (int i = 0; i < workers; ++i) {
            workers_.emplace_back([this] { work(); });
        }
    }

    ~Pool() {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            stopping_ = true;
        }
        ready_.notify_all();
        for (std::thread& worker : workers_) {
            worker.join();
        }
    }

    void submit(std::function<void()> task) {
        {
            std::lock_guard<std::mutex> lock(mutex_);
            tasks_.push(std::move(task));
        }
        ready_.notify_one();
    }

    void wait_idle() {
        std::unique_lock<std::mutex> lock(mutex_);
        done_.wait(lock, [this] { return tasks_.empty() && busy_ == 0; });
    }
private:
    void work() {
        while (true) {
            std::function<void()> task;
            {
                std::unique_lock<std::mutex> lock(mutex_);
                ready_.wait(lock, [this] { return stopping_ || !tasks_.empty(); });
                if (stopping_ && tasks_.empty()) {
                    return;
                }
                task = std::move(tasks_.front());
                tasks_.pop();
                ++busy_;
            }
            task();
            {
                std::lock_guard<std::mutex> lock(mutex_);
                --busy_;
            }
            done_.notify_all();
        }
    }
    std::vector<std::thread> workers_;
    std::queue<std::function<void()>> tasks_;
    std::mutex mutex_;
    std::condition_variable ready_;
    std::condition_variable done_;
    bool stopping_ = false;
    int busy_ = 0;
};

int main() {
    std::atomic<long> total{0};
    {
        Pool pool(4);
        for (int i = 1; i <= 20; ++i) {
            pool.submit([&total, i] { total.fetch_add(i); });
        }
        pool.wait_idle();
    }
    std::cout << "20 tasks summed to " << total.load() << "\\n";
    return 0;
}
''', '''20 tasks summed to 210'''),
            exp("The three ways concurrent code stalls\n\n"
                "Deadlock: two threads each hold a lock the other needs, so neither can "
                "proceed. The fix is a lock order that everyone follows.\n\n"
                "Livelock: both keep retrying and backing off, so neither gets anywhere - busy "
                "but not progressing. The fix is randomised backoff or a queue.\n\n"
                "Starvation: one thread never gets scheduled because others keep winning. "
                "The fix is fairness - a queue rather than a free-for-all.\n\n"
                "A pool with a single mutex-protected queue has none of these, which is one "
                "reason the design is so common."),
            CHALLENGE,
            code('''#include <iostream>
#include <mutex>
#include <thread>
#include <vector>

int main() {
    long plain_total = 0;
    std::mutex guard;
    std::vector<std::thread> workers;
    for (int worker = 0; worker < 4; ++worker) {
        workers.emplace_back([&plain_total, &guard] {
            for (int i = 0; i < 1000; ++i) {
                std::lock_guard<std::mutex> lock(guard);
                ++plain_total;
            }
        });
    }
    for (std::thread& worker : workers) {
        worker.join();
    }
    std::cout << "guarded total " << plain_total << "\\n";
    return 0;
}
''', '''guarded total 4000'''),
            quiz("What is the difference between deadlock and livelock?",
                 ["Nothing", "Deadlock is stuck waiting on locks; livelock is stuck retrying "
                  "without making progress", "Livelock uses more threads", "Deadlock only "
                  "happens with two threads"],
                 1, "Both stall, but in a deadlock nobody runs, while in a livelock everybody "
                    "runs and nothing advances."),
           ]),
]
